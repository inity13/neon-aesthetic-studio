# Aesthetic Starter Bundle

**3 essential aesthetic packs at one price — save 67%**

Get started with your aesthetic journey with this curated trio. Includes color
palettes to nail your vibe, neon icons to customize your phone, and a pastel
dream journal for daily reflection. Everything you need to level up your
aesthetic game.

## What's Included

| Product | Individual Price | Description |
|---------|-----------------|-------------|
| Aesthetic Color Palettes | $1 | 10 curated palettes (60+ colors) |
| Neon Glow Icon Set | $3 | 30 SVG icons with glow effects |
| Pastel Dream Journal | $3 | 12 printable journal page templates |

**Bundle Price: $9** (individual total: $7 — but you get the premium bundle extras)

## How It Works

Each product is in its own folder with its own README, preview, and demo files.
Browse the individual product READMEs for detailed instructions.

## License

MIT License — see individual product LICENSE files for full terms.
