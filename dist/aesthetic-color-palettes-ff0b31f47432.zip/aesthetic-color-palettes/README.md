# Aesthetic Color Palettes

**10 curated color palettes for every aesthetic vibe**

Whether you're designing wallpapers, editing photos, or theming your social media,
these palettes give you the exact hex codes to nail every aesthetic from cottagecore
to Y2K. Each palette has 6-8 colors that just *work* together.

## What's Inside

| # | Palette | Vibe | Colors |
|---|---------|------|--------|
| 1 | Cottagecore | Warm earth tones, dried flowers, linen | 8 colors |
| 2 | Dark Academia | Leather, mahogany, candlelight, old books | 7 colors |
| 3 | Y2K | Chrome silver, hot pink, electric blue | 7 colors |
| 4 | Pastel Dream | Soft lavender, baby pink, mint, cream | 8 colors |
| 5 | Neon Glow | Electric purple, hot magenta, cyan | 6 colors |
| 6 | Grunge | Muted olive, rust, charcoal, faded denim | 7 colors |
| 7 | Soft Girl | Blush pink, peach, cloud white, baby blue | 7 colors |
| 8 | Vintage | Sepia, burnt orange, dusty rose, olive | 8 colors |
| 9 | Ocean Wave | Deep navy, seafoam, coral, sand | 7 colors |
| 10 | Sunset | Golden hour amber, coral pink, dusky purple | 6 colors |

## File Structure

```
src/
├── palettes.json           # All 10 palettes with hex codes & metadata
└── generate_swatches.py    # Generate SVG swatch cards

preview/
└── index.html              # Visual gallery of all palettes

demo/
└── index.html              # Interactive palette explorer
```

## How to Use

1. **Browse palettes**: Open `preview/index.html` to see all 10 palettes at a glance
2. **Explore interactively**: Open `demo/index.html` to click colors and copy hex codes
3. **Get hex codes**: Open `src/palettes.json` for all colors in a developer-friendly format
4. **Generate swatches**: Run `python3 src/generate_swatches.py` to create SVG swatch cards

## Tips

- Click any color swatch in the demo to copy its hex code to clipboard
- Use these palettes in Canva, Figma, Procreate, or any design tool
- Mix and match palettes for unique color combos
- Colors are tested for contrast and harmony

## License

MIT License — use these palettes however you want. See LICENSE file for full terms.
