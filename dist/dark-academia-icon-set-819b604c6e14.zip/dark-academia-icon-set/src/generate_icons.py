#!/usr/bin/env python3
"""
Dark Academia Icon Set Generator
Generates 30 SVG icons at 120x120 in the dark academia aesthetic.
Uses Python stdlib only — no external dependencies.

Each icon uses the palette: Espresso #3C2415, Mahogany #6B3A2A,
Parchment #E8D5B7, Ivy #4A6741, Gold #C5A55A, Charcoal #2C2C2C.
"""

import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

BASE = Path(__file__).parent
ICON_DATA = BASE / "icon_data.json"
OUTPUT_DIR = BASE / "icons"

# Palette
ESPRESSO = "#3C2415"
MAHOGANY = "#6B3A2A"
PARCHMENT = "#E8D5B7"
IVY = "#4A6741"
GOLD = "#C5A55A"
CHARCOAL = "#2C2C2C"

S = 120  # icon size


def svg_root():
    svg = ET.Element("svg", xmlns="http://www.w3.org/2000/svg",
                     viewBox=f"0 0 {S} {S}", width=str(S), height=str(S))
    return svg


def add_bg(svg, fill=CHARCOAL):
    ET.SubElement(svg, "rect", width=str(S), height=str(S), rx="16", fill=fill)


def to_string(svg):
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(svg, encoding="unicode")


# ---------------------------------------------------------------------------
# Icon generators
# ---------------------------------------------------------------------------

def gen_open_book():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(20, 30)")
    # Left page
    ET.SubElement(g, "path", d="M40,0 L0,5 L0,60 L40,55 Z", fill=PARCHMENT, opacity="0.9")
    # Right page
    ET.SubElement(g, "path", d="M40,0 L80,5 L80,60 L40,55 Z", fill=PARCHMENT, opacity="0.85")
    # Spine
    ET.SubElement(g, "line", x1="40", y1="0", x2="40", y2="55", stroke=MAHOGANY)
    ET.SubElement(g, "line", **{"x1": "40", "y1": "0", "x2": "40", "y2": "55", "stroke": MAHOGANY, "stroke-width": "2"})
    # Text lines left
    for i in range(5):
        ET.SubElement(g, "line", x1="8", y1=str(12 + i * 9), x2="35", y2=str(12 + i * 9),
                      stroke=MAHOGANY, opacity="0.3")
    # Text lines right
    for i in range(5):
        ET.SubElement(g, "line", x1="45", y1=str(12 + i * 9), x2="72", y2=str(12 + i * 9),
                      stroke=MAHOGANY, opacity="0.3")
    return to_string(svg)


def gen_closed_book():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(30, 20)")
    # Book body
    ET.SubElement(g, "rect", x="0", y="0", width="60", height="80", rx="3", fill=MAHOGANY)
    # Pages
    ET.SubElement(g, "rect", x="5", y="3", width="52", height="74", fill=PARCHMENT)
    # Cover flap
    ET.SubElement(g, "rect", x="0", y="0", width="8", height="80", rx="3", fill=ESPRESSO)
    # Title line
    ET.SubElement(g, "line", x1="18", y1="35", x2="48", y2="35", stroke=GOLD)
    ET.SubElement(g, "line", **{"x1": "18", "y1": "35", "x2": "48", "y2": "35", "stroke": GOLD, "stroke-width": "2"})
    ET.SubElement(g, "line", x1="22", y1="42", x2="44", y2="42", stroke=GOLD, opacity="0.6")
    return to_string(svg)


def gen_book_stack():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(25, 20)")
    colors = [MAHOGANY, IVY, ESPRESSO]
    for i, c in enumerate(colors):
        y = 55 - i * 22
        ET.SubElement(g, "rect", x="0", y=str(y), width="70", height="18", rx="2", fill=c)
        ET.SubElement(g, "rect", x="3", y=str(y + 2), width="64", height="14", rx="1", fill=PARCHMENT, opacity="0.15")
        ET.SubElement(g, "line", x1="15", y1=str(y + 9), x2="55", y2=str(y + 9), stroke=GOLD, opacity="0.5")
    return to_string(svg)


def gen_fountain_pen():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(60, 100) rotate(-45)")
    # Barrel
    ET.SubElement(g, "rect", x="-5", y="-80", width="10", height="55", rx="2", fill=ESPRESSO)
    # Grip
    ET.SubElement(g, "rect", x="-4", y="-25", width="8", height="15", fill=MAHOGANY)
    # Nib
    ET.SubElement(g, "path", d="M-3,-10 L0,-0 L3,-10 Z", fill=GOLD)
    # Clip
    ET.SubElement(g, "rect", x="5", y="-75", width="2", height="30", rx="1", fill=GOLD)
    return to_string(svg)


def gen_ink_bottle():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(30, 20)")
    # Bottle body
    ET.SubElement(g, "path", d="M10,35 L5,80 L55,80 L50,35 Z", fill=ESPRESSO, opacity="0.8")
    # Neck
    ET.SubElement(g, "rect", x="20", y="20", width="20", height="18", rx="2", fill=ESPRESSO)
    # Stopper
    ET.SubElement(g, "rect", x="18", y="10", width="24", height="12", rx="4", fill=MAHOGANY)
    # Label
    ET.SubElement(g, "rect", x="15", y="48", width="30", height="18", rx="2", fill=PARCHMENT, opacity="0.6")
    # Ink level
    ET.SubElement(g, "rect", x="8", y="55", width="44", height="25", fill=ESPRESSO, opacity="0.3")
    return to_string(svg)


def gen_quill():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(60, 95) rotate(-40)")
    # Feather
    ET.SubElement(g, "path", d="M0,0 Q-15,-40 -8,-80 Q0,-60 8,-80 Q15,-40 0,0 Z", fill=PARCHMENT, opacity="0.9")
    # Shaft
    ET.SubElement(g, "line", x1="0", y1="0", x2="0", y2="-80", stroke=MAHOGANY)
    ET.SubElement(g, "line", **{"x1": "0", "y1": "0", "x2": "0", "y2": "-80", "stroke": MAHOGANY, "stroke-width": "1.5"})
    # Nib
    ET.SubElement(g, "path", d="M-2,0 L0,10 L2,0 Z", fill=GOLD)
    return to_string(svg)


def gen_journal():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(25, 15)")
    # Cover
    ET.SubElement(g, "rect", x="0", y="0", width="70", height="90", rx="4", fill=MAHOGANY)
    # Leather texture lines
    for i in range(3):
        ET.SubElement(g, "line", x1="5", y1=str(20 + i * 20), x2="65", y2=str(20 + i * 20),
                      stroke=ESPRESSO, opacity="0.3")
    # Clasp
    ET.SubElement(g, "rect", x="62", y="38", width="12", height="14", rx="3", fill=GOLD)
    ET.SubElement(g, "circle", cx="68", cy="45", r="3", fill=ESPRESSO)
    # Title emboss
    ET.SubElement(g, "rect", x="15", y="30", width="40", height="2", fill=GOLD, opacity="0.6")
    ET.SubElement(g, "rect", x="20", y="36", width="30", height="2", fill=GOLD, opacity="0.4")
    return to_string(svg)


def gen_bookmark():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(40, 15)")
    # Ribbon
    ET.SubElement(g, "path", d="M-10,0 L-10,75 L0,60 L10,75 L10,0 Z", fill=MAHOGANY)
    # Pattern
    ET.SubElement(g, "line", x1="-6", y1="15", x2="6", y2="15", stroke=GOLD, opacity="0.5")
    ET.SubElement(g, "line", x1="-6", y1="25", x2="6", y2="25", stroke=GOLD, opacity="0.5")
    ET.SubElement(g, "circle", cx="0", cy="40", r="5", fill="none", stroke=GOLD, opacity="0.6")
    # Tassel
    ET.SubElement(g, "line", x1="0", y1="60", x2="-5", y2="85", stroke=GOLD, opacity="0.7")
    ET.SubElement(g, "line", x1="0", y1="60", x2="5", y2="85", stroke=GOLD, opacity="0.7")
    return to_string(svg)


def gen_column():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(30, 10)")
    # Capital
    ET.SubElement(g, "path", d="M10,10 Q15,0 30,0 Q45,0 50,10 Z", fill=PARCHMENT)
    ET.SubElement(g, "rect", x="8", y="10", width="44", height="6", fill=PARCHMENT, opacity="0.8")
    # Shaft with flutes
    ET.SubElement(g, "rect", x="15", y="16", width="30", height="70", fill=PARCHMENT, opacity="0.7")
    for i in range(4):
        x = 20 + i * 7
        ET.SubElement(g, "line", x1=str(x), y1="16", x2=str(x), y2="86",
                      stroke=CHARCOAL, opacity="0.15")
    # Base
    ET.SubElement(g, "rect", x="8", y="86", width="44", height="6", fill=PARCHMENT, opacity="0.8")
    ET.SubElement(g, "rect", x="5", y="92", width="50", height="4", fill=PARCHMENT)
    return to_string(svg)


def gen_archway():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(15, 10)")
    # Arch
    ET.SubElement(g, "path", d="M0,100 L0,40 Q0,0 45,0 Q90,0 90,40 L90,100 Z",
                  fill="none", stroke=PARCHMENT, **{"stroke-width": "6"})
    # Keystone
    ET.SubElement(g, "path", d="M38,3 L45,-5 L52,3 Z", fill=GOLD)
    # Inner shadow
    ET.SubElement(g, "path", d="M8,100 L8,42 Q8,8 45,8 Q82,8 82,42 L82,100 Z",
                  fill=ESPRESSO, opacity="0.5")
    return to_string(svg)


def gen_window():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(20, 10)")
    # Window frame
    ET.SubElement(g, "path", d="M0,100 L0,30 Q0,0 40,0 Q80,0 80,30 L80,100 Z",
                  fill="none", stroke=MAHOGANY, **{"stroke-width": "5"})
    # Glass panes
    ET.SubElement(g, "path", d="M5,95 L5,32 Q5,5 40,5 Q75,5 75,32 L75,95 Z",
                  fill="#1A2A3A", opacity="0.6")
    # Cross bar
    ET.SubElement(g, "line", x1="5", y1="55", x2="75", y2="55", stroke=MAHOGANY, **{"stroke-width": "3"})
    ET.SubElement(g, "line", x1="40", y1="5", x2="40", y2="95", stroke=MAHOGANY, **{"stroke-width": "3"})
    return to_string(svg)


def gen_dome():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(10, 15)")
    # Dome
    ET.SubElement(g, "path", d="M0,60 Q0,0 50,0 Q100,0 100,60 Z", fill=PARCHMENT, opacity="0.8")
    # Ribs
    for angle in [25, 50, 75]:
        ET.SubElement(g, "path", d=f"M{angle},60 Q{angle},{60-angle*0.5} 50,2",
                      fill="none", stroke=MAHOGANY, opacity="0.3")
    # Base
    ET.SubElement(g, "rect", x="0", y="58", width="100", height="8", fill=MAHOGANY)
    # Columns
    ET.SubElement(g, "rect", x="5", y="66", width="8", height="25", fill=PARCHMENT, opacity="0.5")
    ET.SubElement(g, "rect", x="87", y="66", width="8", height="25", fill=PARCHMENT, opacity="0.5")
    # Lantern on top
    ET.SubElement(g, "circle", cx="50", cy="5", r="5", fill=GOLD, opacity="0.7")
    return to_string(svg)


def gen_staircase():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(15, 15)")
    # Spiral stairs
    steps = 8
    for i in range(steps):
        y = 10 + i * 11
        w = 50 + i * 5
        x = 45 - w // 2
        ET.SubElement(g, "rect", x=str(x), y=str(y), width=str(w), height="8",
                      rx="2", fill=PARCHMENT, opacity=str(0.4 + i * 0.07))
    # Railing
    ET.SubElement(g, "line", x1="15", y1="10", x2="15", y2="98", stroke=MAHOGANY, **{"stroke-width": "3"})
    ET.SubElement(g, "circle", cx="15", cy="8", r="4", fill=GOLD)
    return to_string(svg)


def gen_door():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(20, 10)")
    # Door frame
    ET.SubElement(g, "rect", x="0", y="0", width="80", height="100", rx="3", fill=MAHOGANY)
    # Door panels
    ET.SubElement(g, "rect", x="8", y="8", width="28", height="35", rx="2", fill=ESPRESSO)
    ET.SubElement(g, "rect", x="44", y="8", width="28", height="35", rx="2", fill=ESPRESSO)
    ET.SubElement(g, "rect", x="8", y="50", width="28", height="42", rx="2", fill=ESPRESSO)
    ET.SubElement(g, "rect", x="44", y="50", width="28", height="42", rx="2", fill=ESPRESSO)
    # Handle
    ET.SubElement(g, "circle", cx="65", cy="55", r="5", fill=GOLD)
    ET.SubElement(g, "circle", cx="65", cy="55", r="2", fill=ESPRESSO)
    return to_string(svg)


def gen_candelabra():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(20, 10)")
    # Base
    ET.SubElement(g, "ellipse", cx="40", cy="95", rx="25", ry="6", fill=GOLD, opacity="0.8")
    # Center stem
    ET.SubElement(g, "rect", x="37", y="30", width="6", height="65", fill=GOLD, opacity="0.7")
    # Left arm
    ET.SubElement(g, "path", d="M40,50 Q20,45 15,35", fill="none", stroke=GOLD, **{"stroke-width": "3"})
    # Right arm
    ET.SubElement(g, "path", d="M40,50 Q60,45 65,35", fill="none", stroke=GOLD, **{"stroke-width": "3"})
    # Candles
    for cx in [15, 40, 65]:
        ET.SubElement(g, "rect", x=str(cx - 3), y=str(15), width="6", height="20", fill=PARCHMENT)
        # Flame
        ET.SubElement(g, "ellipse", cx=str(cx), cy="12", rx="4", ry="6", fill="#FFD700", opacity="0.8")
        ET.SubElement(g, "ellipse", cx=str(cx), cy="12", rx="2", ry="4", fill="#FFF8DC")
    return to_string(svg)


def gen_globe():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(20, 10)")
    # Stand
    ET.SubElement(g, "line", x1="40", y1="60", x2="40", y2="90", stroke=MAHOGANY, **{"stroke-width": "3"})
    ET.SubElement(g, "ellipse", cx="40", cy="92", rx="20", ry="5", fill=MAHOGANY)
    # Globe
    ET.SubElement(g, "circle", cx="40", cy="38", r="30", fill=IVY, opacity="0.6")
    ET.SubElement(g, "circle", cx="40", cy="38", r="30", fill="none", stroke=GOLD, **{"stroke-width": "2"})
    # Meridian
    ET.SubElement(g, "ellipse", cx="40", cy="38", rx="15", ry="30", fill="none",
                  stroke=GOLD, opacity="0.4")
    # Equator
    ET.SubElement(g, "ellipse", cx="40", cy="38", rx="30", ry="10", fill="none",
                  stroke=GOLD, opacity="0.4")
    # Land masses (simple)
    ET.SubElement(g, "ellipse", cx="32", cy="30", rx="10", ry="8", fill=IVY, opacity="0.4")
    ET.SubElement(g, "ellipse", cx="52", cy="42", rx="8", ry="6", fill=IVY, opacity="0.4")
    return to_string(svg)


def gen_compass():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(60, 60)")
    # Outer ring
    ET.SubElement(g, "circle", cx="0", cy="0", r="42", fill="none", stroke=GOLD, **{"stroke-width": "3"})
    ET.SubElement(g, "circle", cx="0", cy="0", r="38", fill=ESPRESSO, opacity="0.3")
    # Cardinal directions
    ET.SubElement(g, "path", d="M0,-35 L5,0 L-5,0 Z", fill=GOLD)  # N
    ET.SubElement(g, "path", d="M0,35 L5,0 L-5,0 Z", fill=PARCHMENT, opacity="0.5")  # S
    ET.SubElement(g, "path", d="M-35,0 L0,5 L0,-5 Z", fill=PARCHMENT, opacity="0.5")  # W
    ET.SubElement(g, "path", d="M35,0 L0,5 L0,-5 Z", fill=PARCHMENT, opacity="0.5")  # E
    # Center
    ET.SubElement(g, "circle", cx="0", cy="0", r="4", fill=GOLD)
    return to_string(svg)


def gen_hourglass():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(30, 10)")
    # Top frame
    ET.SubElement(g, "rect", x="5", y="0", width="50", height="5", rx="2", fill=GOLD)
    # Bottom frame
    ET.SubElement(g, "rect", x="5", y="95", width="50", height="5", rx="2", fill=GOLD)
    # Glass shape
    ET.SubElement(g, "path", d="M10,5 Q10,45 30,50 Q10,55 10,95 L50,95 Q50,55 30,50 Q50,45 50,5 Z",
                  fill=PARCHMENT, opacity="0.2", stroke=GOLD, **{"stroke-width": "1"})
    # Sand top
    ET.SubElement(g, "path", d="M15,10 L45,10 L35,40 L25,40 Z", fill="#C5A55A", opacity="0.5")
    # Sand bottom
    ET.SubElement(g, "path", d="M15,90 L45,90 L35,65 L25,65 Z", fill="#C5A55A", opacity="0.7")
    # Stream
    ET.SubElement(g, "line", x1="30", y1="42", x2="30", y2="63", stroke=GOLD, opacity="0.6")
    return to_string(svg)


def gen_magnifying_glass():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(55, 50)")
    # Lens
    ET.SubElement(g, "circle", cx="0", cy="0", r="30", fill=PARCHMENT, opacity="0.1",
                  stroke=GOLD, **{"stroke-width": "4"})
    # Glare
    ET.SubElement(g, "path", d="M-15,-15 Q-10,-20 -5,-15", fill="none", stroke=PARCHMENT,
                  opacity="0.4", **{"stroke-width": "2"})
    # Handle
    ET.SubElement(g, "line", x1="22", y1="22", x2="42", y2="42", stroke=MAHOGANY, **{"stroke-width": "6"})
    ET.SubElement(g, "line", x1="22", y1="22", x2="42", y2="42", stroke=GOLD, **{"stroke-width": "2"})
    return to_string(svg)


def gen_key():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(35, 15)")
    # Bow (handle)
    ET.SubElement(g, "circle", cx="25", cy="20", r="18", fill="none", stroke=GOLD, **{"stroke-width": "4"})
    ET.SubElement(g, "circle", cx="25", cy="20", r="8", fill=CHARCOAL)
    # Shaft
    ET.SubElement(g, "rect", x="23", y="38", width="4", height="45", fill=GOLD)
    # Teeth
    ET.SubElement(g, "rect", x="15", y="70", width="12", height="4", fill=GOLD)
    ET.SubElement(g, "rect", x="15", y="78", width="8", height="4", fill=GOLD)
    return to_string(svg)


def gen_clock():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(60, 60)")
    # Face
    ET.SubElement(g, "circle", cx="0", cy="0", r="42", fill=PARCHMENT, opacity="0.15",
                  stroke=GOLD, **{"stroke-width": "3"})
    # Hour markers
    import math
    for i in range(12):
        angle = math.radians(i * 30 - 90)
        x1, y1 = 35 * math.cos(angle), 35 * math.sin(angle)
        x2, y2 = 40 * math.cos(angle), 40 * math.sin(angle)
        ET.SubElement(g, "line", x1=f"{x1:.1f}", y1=f"{y1:.1f}",
                      x2=f"{x2:.1f}", y2=f"{y2:.1f}", stroke=GOLD, **{"stroke-width": "2"})
    # Hands (10:10)
    ET.SubElement(g, "line", x1="0", y1="0", x2="-18", y2="-18", stroke=MAHOGANY, **{"stroke-width": "3"})
    ET.SubElement(g, "line", x1="0", y1="0", x2="18", y2="-24", stroke=MAHOGANY, **{"stroke-width": "2"})
    # Center
    ET.SubElement(g, "circle", cx="0", cy="0", r="3", fill=GOLD)
    return to_string(svg)


def gen_chess_piece():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(35, 15)")
    # Knight head
    ET.SubElement(g, "path", d="M25,20 Q35,5 40,15 Q50,10 45,25 Q42,35 35,40 L15,40 Q10,35 15,20 Z",
                  fill=MAHOGANY)
    # Ear
    ET.SubElement(g, "path", d="M30,10 L35,2 L38,12 Z", fill=MAHOGANY)
    # Eye
    ET.SubElement(g, "circle", cx="35", cy="22", r="2", fill=PARCHMENT)
    # Neck
    ET.SubElement(g, "rect", x="18", y="40", width="15", height="20", fill=MAHOGANY)
    # Base
    ET.SubElement(g, "ellipse", cx="25", cy="65", rx="22", ry="8", fill=MAHOGANY)
    ET.SubElement(g, "rect", x="5", y="60", width="40", height="10", rx="3", fill=ESPRESSO)
    # Base trim
    ET.SubElement(g, "ellipse", cx="25", cy="72", rx="24", ry="6", fill=MAHOGANY, opacity="0.7")
    return to_string(svg)


def gen_ivy_vine():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g")
    # Main vine
    ET.SubElement(g, "path", d="M20,10 Q40,30 30,50 Q20,70 40,90 Q60,100 70,110",
                  fill="none", stroke=IVY, **{"stroke-width": "3"})
    # Leaves
    leaves = [(30, 25, 0), (25, 45, -20), (38, 60, 15), (30, 75, -10), (45, 90, 20)]
    for lx, ly, rot in leaves:
        leaf = ET.SubElement(g, "ellipse", cx=str(lx), cy=str(ly), rx="10", ry="6",
                            fill=IVY, opacity="0.8",
                            transform=f"rotate({rot},{lx},{ly})")
    return to_string(svg)


def gen_oak_leaf():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(25, 15)")
    # Leaf shape
    ET.SubElement(g, "path",
                  d="M35,80 Q30,60 20,50 Q10,45 15,35 Q8,30 15,22 Q10,15 20,10 Q25,0 35,5 Q45,0 50,10 Q60,15 55,22 Q62,30 55,35 Q60,45 50,50 Q40,60 35,80 Z",
                  fill=MAHOGANY, opacity="0.8")
    # Veins
    ET.SubElement(g, "line", x1="35", y1="80", x2="35", y2="10", stroke=GOLD, opacity="0.4")
    ET.SubElement(g, "line", x1="35", y1="35", x2="18", y2="25", stroke=GOLD, opacity="0.3")
    ET.SubElement(g, "line", x1="35", y1="35", x2="52", y2="25", stroke=GOLD, opacity="0.3")
    ET.SubElement(g, "line", x1="35", y1="50", x2="22", y2="45", stroke=GOLD, opacity="0.3")
    ET.SubElement(g, "line", x1="35", y1="50", x2="48", y2="45", stroke=GOLD, opacity="0.3")
    return to_string(svg)


def gen_raven():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(15, 15)")
    # Body
    ET.SubElement(g, "ellipse", cx="50", cy="60", rx="25", ry="20", fill=CHARCOAL)
    # Head
    ET.SubElement(g, "circle", cx="30", cy="40", r="14", fill=CHARCOAL)
    # Beak
    ET.SubElement(g, "path", d="M18,38 L10,42 L18,44 Z", fill=ESPRESSO)
    # Eye
    ET.SubElement(g, "circle", cx="26", cy="38", r="2", fill=GOLD)
    # Wing
    ET.SubElement(g, "path", d="M45,50 Q70,30 80,45 Q75,60 55,65 Z", fill="#1a1a1a")
    # Tail
    ET.SubElement(g, "path", d="M70,60 L85,55 L88,65 L75,70 Z", fill="#1a1a1a")
    # Perch
    ET.SubElement(g, "line", x1="10", y1="80", x2="80", y2="80", stroke=MAHOGANY, **{"stroke-width": "4"})
    # Feet
    ET.SubElement(g, "path", d="M40,75 L38,80 M45,75 L47,80", fill="none", stroke=CHARCOAL, **{"stroke-width": "2"})
    return to_string(svg)


def gen_moth():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(60, 55)")
    # Left wing
    ET.SubElement(g, "path", d="M0,0 Q-35,-30 -35,0 Q-35,20 0,10 Z", fill=PARCHMENT, opacity="0.7")
    # Right wing
    ET.SubElement(g, "path", d="M0,0 Q35,-30 35,0 Q35,20 0,10 Z", fill=PARCHMENT, opacity="0.7")
    # Wing patterns
    ET.SubElement(g, "circle", cx="-18", cy="-5", r="8", fill=MAHOGANY, opacity="0.4")
    ET.SubElement(g, "circle", cx="18", cy="-5", r="8", fill=MAHOGANY, opacity="0.4")
    ET.SubElement(g, "circle", cx="-18", cy="-5", r="4", fill=GOLD, opacity="0.3")
    ET.SubElement(g, "circle", cx="18", cy="-5", r="4", fill=GOLD, opacity="0.3")
    # Body
    ET.SubElement(g, "ellipse", cx="0", cy="5", rx="4", ry="12", fill=MAHOGANY)
    # Antennae
    ET.SubElement(g, "path", d="M-2,-5 Q-10,-20 -15,-25", fill="none", stroke=MAHOGANY, **{"stroke-width": "1"})
    ET.SubElement(g, "path", d="M2,-5 Q10,-20 15,-25", fill="none", stroke=MAHOGANY, **{"stroke-width": "1"})
    return to_string(svg)


def gen_laurel_wreath():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(60, 60)")
    import math
    # Left branch
    for i in range(7):
        angle = math.radians(180 + i * 25)
        cx = 32 * math.cos(angle)
        cy = 32 * math.sin(angle)
        rot = i * 25
        ET.SubElement(g, "ellipse", cx=f"{cx:.1f}", cy=f"{cy:.1f}", rx="8", ry="4",
                      fill=IVY, opacity="0.7", transform=f"rotate({rot},{cx:.1f},{cy:.1f})")
    # Right branch
    for i in range(7):
        angle = math.radians(-i * 25)
        cx = 32 * math.cos(angle)
        cy = 32 * math.sin(angle)
        rot = -i * 25
        ET.SubElement(g, "ellipse", cx=f"{cx:.1f}", cy=f"{cy:.1f}", rx="8", ry="4",
                      fill=IVY, opacity="0.7", transform=f"rotate({rot},{cx:.1f},{cy:.1f})")
    # Ribbon at bottom
    ET.SubElement(g, "path", d="M-5,38 L-10,48 M5,38 L10,48", fill="none", stroke=GOLD, **{"stroke-width": "2"})
    return to_string(svg)


def gen_constellation():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g")
    # Stars
    stars = [(30, 25), (55, 20), (75, 35), (65, 60), (40, 70), (25, 55), (50, 45)]
    for sx, sy in stars:
        ET.SubElement(g, "circle", cx=str(sx), cy=str(sy), r="3", fill=GOLD)
        ET.SubElement(g, "circle", cx=str(sx), cy=str(sy), r="6", fill=GOLD, opacity="0.2")
    # Lines
    connections = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 1)]
    for a, b in connections:
        ET.SubElement(g, "line", x1=str(stars[a][0]), y1=str(stars[a][1]),
                      x2=str(stars[b][0]), y2=str(stars[b][1]),
                      stroke=GOLD, opacity="0.3", **{"stroke-width": "1"})
    return to_string(svg)


def gen_crescent_moon():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(60, 60)")
    # Moon
    ET.SubElement(g, "circle", cx="0", cy="0", r="35", fill=PARCHMENT, opacity="0.9")
    ET.SubElement(g, "circle", cx="12", cy="-8", r="30", fill=CHARCOAL)  # shadow cutout
    # Small stars
    for sx, sy in [(-30, -20), (-25, 25), (20, -35), (30, 20)]:
        ET.SubElement(g, "circle", cx=str(sx), cy=str(sy), r="2", fill=GOLD, opacity="0.6")
    return to_string(svg)


def gen_skull():
    svg = svg_root()
    add_bg(svg)
    g = ET.SubElement(svg, "g", transform="translate(25, 15)")
    # Cranium
    ET.SubElement(g, "path", d="M10,50 Q0,25 10,10 Q20,0 35,0 Q50,0 60,10 Q70,25 60,50 Z",
                  fill=PARCHMENT, opacity="0.85")
    # Jaw
    ET.SubElement(g, "path", d="M15,50 Q20,70 35,72 Q50,70 55,50 Z", fill=PARCHMENT, opacity="0.75")
    # Eyes
    ET.SubElement(g, "ellipse", cx="25", cy="32", rx="8", ry="9", fill=CHARCOAL)
    ET.SubElement(g, "ellipse", cx="45", cy="32", rx="8", ry="9", fill=CHARCOAL)
    # Nose
    ET.SubElement(g, "path", d="M32,44 L35,50 L38,44 Z", fill=CHARCOAL)
    # Teeth
    for i in range(5):
        x = 22 + i * 7
        ET.SubElement(g, "rect", x=str(x), y="55", width="5", height="8", rx="1",
                      fill=PARCHMENT, stroke=CHARCOAL, opacity="0.6", **{"stroke-width": "0.5"})
    return to_string(svg)


# ---------------------------------------------------------------------------
# Generator registry
# ---------------------------------------------------------------------------
GENERATORS = {
    "open-book": gen_open_book,
    "closed-book": gen_closed_book,
    "book-stack": gen_book_stack,
    "fountain-pen": gen_fountain_pen,
    "ink-bottle": gen_ink_bottle,
    "quill": gen_quill,
    "journal": gen_journal,
    "bookmark": gen_bookmark,
    "column": gen_column,
    "archway": gen_archway,
    "window": gen_window,
    "dome": gen_dome,
    "staircase": gen_staircase,
    "door": gen_door,
    "candelabra": gen_candelabra,
    "globe": gen_globe,
    "compass": gen_compass,
    "hourglass": gen_hourglass,
    "magnifying-glass": gen_magnifying_glass,
    "key": gen_key,
    "clock": gen_clock,
    "chess-piece": gen_chess_piece,
    "ivy-vine": gen_ivy_vine,
    "oak-leaf": gen_oak_leaf,
    "raven": gen_raven,
    "moth": gen_moth,
    "laurel-wreath": gen_laurel_wreath,
    "constellation": gen_constellation,
    "crescent-moon": gen_crescent_moon,
    "skull": gen_skull,
}


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    with open(ICON_DATA, "r") as f:
        data = json.load(f)

    count = 0
    for category in data["categories"]:
        for icon in category["icons"]:
            slug = icon["slug"]
            gen_fn = GENERATORS.get(slug)
            if gen_fn is None:
                print(f"  SKIP: No generator for '{slug}'")
                continue

            filename = f"{icon['id']:02d}-{slug}.svg"
            filepath = OUTPUT_DIR / filename
            svg_content = gen_fn()

            with open(filepath, "w") as f:
                f.write(svg_content)

            count += 1
            print(f"  Generated: {filename} — {icon['name']}")

    print(f"\nDone! {count} icons saved to {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
