#!/usr/bin/env python3
"""
Cottagecore Wallpaper Generator
Generates remaining SVG wallpapers (06-20) for phone and desktop.
Uses Python stdlib only — no external dependencies.

Each wallpaper is a unique, carefully composed SVG with:
- Gradients and patterns for depth
- Cottagecore color palette (#8B7355, #C5A880, #E8D5B7, #97B07A, #D4956A, #F5E6CC)
- Proper viewBox for phone (1080x2340) and desktop (1920x1080)
"""

import os
import textwrap
from pathlib import Path

BASE = Path(__file__).parent
PHONE_DIR = BASE / "src" / "phone"
DESKTOP_DIR = BASE / "src" / "desktop"

# Cottagecore palette
WALNUT = "#8B7355"
WHEAT = "#C5A880"
CREAM = "#E8D5B7"
SAGE = "#97B07A"
TERRACOTTA = "#D4956A"
LINEN = "#F5E6CC"

WALLPAPERS = {
    6: ("forest-floor", "Forest Floor: Moss, ferns, and tiny wildflowers"),
    7: ("cottage-window", "Cottage Window: View through window with lace curtains"),
    8: ("herb-garden", "Herb Garden: Rosemary, lavender, sage in terracotta pots"),
    9: ("autumn-harvest", "Autumn Harvest: Pumpkins, wheat, and warm falling leaves"),
    10: ("pressed-flowers", "Pressed Flowers: Botanical specimens on aged paper"),
    11: ("honeybee-path", "Honeybee Path: Bees hovering over clover and wildflowers"),
    12: ("rainy-window", "Rainy Window: Raindrops on glass, garden blur beyond"),
    13: ("woven-basket", "Woven Basket: Wicker texture with dried flowers"),
    14: ("sunset-meadow", "Sunset Meadow: Pink-gold sunset over rolling green hills"),
    15: ("fairy-ring", "Fairy Ring: Circle of mushrooms in moonlit clearing"),
    16: ("lavender-fields", "Lavender Fields: Rows of purple stretching to horizon"),
    17: ("berry-picking", "Berry Picking: Blackberry brambles heavy with fruit"),
    18: ("morning-dew", "Morning Dew: Close-up dewdrops on petals and leaves"),
    19: ("cottage-door", "Cottage Door: Arched wooden door with climbing roses"),
    20: ("starlit-garden", "Starlit Garden: Night garden with fireflies and moonflowers"),
}


def svg_header(width: int, height: int, title: str) -> str:
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}">\n  <!-- {title} -->\n'


def svg_footer() -> str:
    return '</svg>\n'


def gen_forest_floor(w: int, h: int) -> str:
    """Moss, ferns, tiny wildflowers on dark earth."""
    return svg_header(w, h, WALLPAPERS[6][1]) + f'''  <defs>
    <linearGradient id="earth" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#3A4D2E"/>
      <stop offset="100%" stop-color="#2E3D22"/>
    </linearGradient>
    <radialGradient id="mossSpot" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#6B8E4E"/>
      <stop offset="100%" stop-color="#3A5C2A"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#earth)"/>
  <!-- Moss patches -->
  <g opacity="0.7">
    <circle cx="{w*0.2}" cy="{h*0.3}" r="{w*0.12}" fill="url(#mossSpot)"/>
    <circle cx="{w*0.7}" cy="{h*0.5}" r="{w*0.15}" fill="url(#mossSpot)"/>
    <circle cx="{w*0.4}" cy="{h*0.7}" r="{w*0.1}" fill="url(#mossSpot)"/>
    <circle cx="{w*0.85}" cy="{h*0.25}" r="{w*0.08}" fill="url(#mossSpot)"/>
    <circle cx="{w*0.15}" cy="{h*0.8}" r="{w*0.11}" fill="url(#mossSpot)"/>
  </g>
  <!-- Ferns -->
  <g fill="#5A7E3E" opacity="0.8">
    <path d="M{w*0.15},{h*0.45} Q{w*0.18},{h*0.35} {w*0.22},{h*0.28} Q{w*0.19},{h*0.32} {w*0.17},{h*0.38} Q{w*0.23},{h*0.30} {w*0.27},{h*0.24} Q{w*0.22},{h*0.30} {w*0.20},{h*0.37}Z"/>
    <path d="M{w*0.75},{h*0.6} Q{w*0.78},{h*0.5} {w*0.82},{h*0.43} Q{w*0.79},{h*0.47} {w*0.77},{h*0.53} Q{w*0.83},{h*0.45} {w*0.87},{h*0.39} Q{w*0.82},{h*0.45} {w*0.80},{h*0.52}Z"/>
    <path d="M{w*0.5},{h*0.85} Q{w*0.53},{h*0.75} {w*0.57},{h*0.68} Q{w*0.54},{h*0.72} {w*0.52},{h*0.78} Q{w*0.58},{h*0.70} {w*0.62},{h*0.64} Q{w*0.57},{h*0.70} {w*0.55},{h*0.77}Z"/>
  </g>
  <!-- Tiny wildflowers -->
  <g>
    <circle cx="{w*0.3}" cy="{h*0.4}" r="4" fill="#E8A0BF" opacity="0.8"/>
    <circle cx="{w*0.3}" cy="{h*0.4}" r="2" fill="{TERRACOTTA}"/>
    <circle cx="{w*0.6}" cy="{h*0.35}" r="3" fill="#F5E6CC" opacity="0.8"/>
    <circle cx="{w*0.6}" cy="{h*0.35}" r="1.5" fill="{WHEAT}"/>
    <circle cx="{w*0.45}" cy="{h*0.6}" r="4" fill="#FFD700" opacity="0.7"/>
    <circle cx="{w*0.45}" cy="{h*0.6}" r="2" fill="{WALNUT}"/>
    <circle cx="{w*0.8}" cy="{h*0.7}" r="3" fill="#E8A0BF" opacity="0.8"/>
    <circle cx="{w*0.8}" cy="{h*0.7}" r="1.5" fill="{TERRACOTTA}"/>
    <circle cx="{w*0.25}" cy="{h*0.75}" r="3.5" fill="#F5E6CC" opacity="0.8"/>
    <circle cx="{w*0.25}" cy="{h*0.75}" r="1.5" fill="{WHEAT}"/>
  </g>
  <!-- Fallen twigs -->
  <g stroke="{WALNUT}" stroke-width="2" opacity="0.4">
    <line x1="{w*0.35}" y1="{h*0.5}" x2="{w*0.5}" y2="{h*0.52}"/>
    <line x1="{w*0.6}" y1="{h*0.8}" x2="{w*0.72}" y2="{h*0.78}"/>
  </g>
  <!-- Light dapples -->
  <g fill="{LINEN}" opacity="0.08">
    <circle cx="{w*0.3}" cy="{h*0.2}" r="{w*0.08}"/>
    <circle cx="{w*0.65}" cy="{h*0.15}" r="{w*0.06}"/>
    <circle cx="{w*0.5}" cy="{h*0.45}" r="{w*0.07}"/>
  </g>
''' + svg_footer()


def gen_cottage_window(w: int, h: int) -> str:
    """View through a window with lace curtains."""
    return svg_header(w, h, WALLPAPERS[7][1]) + f'''  <defs>
    <linearGradient id="outsideSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#B8D4E3"/>
      <stop offset="60%" stop-color="{CREAM}"/>
      <stop offset="100%" stop-color="{SAGE}"/>
    </linearGradient>
    <linearGradient id="woodFrame" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#6B5B45"/>
      <stop offset="50%" stop-color="{WALNUT}"/>
      <stop offset="100%" stop-color="#6B5B45"/>
    </linearGradient>
  </defs>
  <!-- Room wall -->
  <rect width="{w}" height="{h}" fill="{LINEN}"/>
  <!-- Window opening -->
  <rect x="{w*0.12}" y="{h*0.1}" width="{w*0.76}" height="{h*0.7}" rx="10" fill="url(#outsideSky)"/>
  <!-- Garden view through window -->
  <rect x="{w*0.12}" y="{h*0.55}" width="{w*0.76}" height="{h*0.25}" fill="{SAGE}" opacity="0.6"/>
  <!-- Distant trees -->
  <g fill="#6B8E4E" opacity="0.5">
    <circle cx="{w*0.25}" cy="{h*0.48}" r="{w*0.06}"/>
    <circle cx="{w*0.5}" cy="{h*0.45}" r="{w*0.08}"/>
    <circle cx="{w*0.75}" cy="{h*0.47}" r="{w*0.07}"/>
  </g>
  <!-- Flower garden glimpse -->
  <g opacity="0.6">
    <circle cx="{w*0.3}" cy="{h*0.65}" r="6" fill="#E8A0BF"/>
    <circle cx="{w*0.4}" cy="{h*0.67}" r="5" fill="#FFD700"/>
    <circle cx="{w*0.55}" cy="{h*0.64}" r="7" fill="#E8A0BF"/>
    <circle cx="{w*0.65}" cy="{h*0.66}" r="5" fill="#F5E6CC"/>
    <circle cx="{w*0.75}" cy="{h*0.68}" r="6" fill="#FFD700"/>
  </g>
  <!-- Window frame -->
  <g fill="url(#woodFrame)">
    <rect x="{w*0.1}" y="{h*0.08}" width="{w*0.8}" height="{h*0.04}" rx="4"/>
    <rect x="{w*0.1}" y="{h*0.78}" width="{w*0.8}" height="{h*0.04}" rx="4"/>
    <rect x="{w*0.1}" y="{h*0.08}" width="{w*0.04}" height="{h*0.74}" rx="4"/>
    <rect x="{w*0.86}" y="{h*0.08}" width="{w*0.04}" height="{h*0.74}" rx="4"/>
    <rect x="{w*0.48}" y="{h*0.08}" width="{w*0.04}" height="{h*0.74}" rx="2"/>
    <rect x="{w*0.1}" y="{h*0.42}" width="{w*0.8}" height="{h*0.02}" rx="2"/>
  </g>
  <!-- Lace curtain (left) -->
  <g opacity="0.25" fill="white">
    <path d="M{w*0.14},{h*0.12} Q{w*0.05},{h*0.35} {w*0.18},{h*0.5} Q{w*0.08},{h*0.6} {w*0.16},{h*0.76} L{w*0.14},{h*0.76} L{w*0.14},{h*0.12}Z"/>
  </g>
  <!-- Lace curtain (right) -->
  <g opacity="0.25" fill="white">
    <path d="M{w*0.86},{h*0.12} Q{w*0.95},{h*0.35} {w*0.82},{h*0.5} Q{w*0.92},{h*0.6} {w*0.84},{h*0.76} L{w*0.86},{h*0.76} L{w*0.86},{h*0.12}Z"/>
  </g>
  <!-- Lace scallop pattern at top -->
  <g stroke="white" stroke-width="1" fill="none" opacity="0.3">
    <path d="M{w*0.14},{h*0.13} Q{w*0.2},{h*0.16} {w*0.26},{h*0.13} Q{w*0.32},{h*0.16} {w*0.38},{h*0.13} Q{w*0.44},{h*0.16} {w*0.5},{h*0.13} Q{w*0.56},{h*0.16} {w*0.62},{h*0.13} Q{w*0.68},{h*0.16} {w*0.74},{h*0.13} Q{w*0.80},{h*0.16} {w*0.86},{h*0.13}"/>
  </g>
  <!-- Windowsill with potted plant -->
  <rect x="{w*0.1}" y="{h*0.78}" width="{w*0.8}" height="{h*0.03}" fill="{WALNUT}" rx="2"/>
  <rect x="{w*0.42}" y="{h*0.73}" width="{w*0.08}" height="{h*0.06}" fill="{TERRACOTTA}" rx="2"/>
  <g fill="{SAGE}">
    <ellipse cx="{w*0.46}" cy="{h*0.72}" rx="12" ry="8"/>
    <ellipse cx="{w*0.44}" cy="{h*0.70}" rx="10" ry="7"/>
    <ellipse cx="{w*0.48}" cy="{h*0.71}" rx="11" ry="7"/>
  </g>
''' + svg_footer()


def gen_herb_garden(w: int, h: int) -> str:
    """Rosemary, lavender, sage in terracotta pots."""
    return svg_header(w, h, WALLPAPERS[8][1]) + f'''  <defs>
    <linearGradient id="sunBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="{LINEN}"/>
      <stop offset="100%" stop-color="{CREAM}"/>
    </linearGradient>
    <linearGradient id="pot" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#B5724A"/>
      <stop offset="50%" stop-color="{TERRACOTTA}"/>
      <stop offset="100%" stop-color="#B5724A"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#sunBg)"/>
  <!-- Wooden shelf -->
  <rect x="{w*0.05}" y="{h*0.45}" width="{w*0.9}" height="{h*0.015}" fill="{WALNUT}" rx="3"/>
  <rect x="{w*0.05}" y="{h*0.72}" width="{w*0.9}" height="{h*0.015}" fill="{WALNUT}" rx="3"/>
  <!-- Pot 1: Rosemary (top left) -->
  <g transform="translate({w*0.22},{h*0.45})">
    <path d="M-{w*0.05},0 L-{w*0.04},-{h*0.08} L{w*0.04},-{h*0.08} L{w*0.05},0Z" fill="url(#pot)"/>
    <rect x="-{w*0.055}" y="-{h*0.09}" width="{w*0.11}" height="{h*0.015}" fill="{TERRACOTTA}" rx="2"/>
    <!-- Rosemary sprigs -->
    <g stroke="#5A7E3E" stroke-width="2" fill="none">
      <path d="M0,-{h*0.08} Q-5,-{h*0.14} -10,-{h*0.2}"/>
      <path d="M0,-{h*0.08} Q5,-{h*0.15} 3,-{h*0.22}"/>
      <path d="M0,-{h*0.08} Q-10,-{h*0.12} -15,-{h*0.18}"/>
    </g>
    <g fill="{SAGE}" opacity="0.8">
      <ellipse cx="-6" cy="-{h*0.12}" rx="3" ry="6" transform="rotate(-20,-6,-{h*0.12})"/>
      <ellipse cx="-9" cy="-{h*0.15}" rx="3" ry="6" transform="rotate(-15,-9,-{h*0.15})"/>
      <ellipse cx="-12" cy="-{h*0.18}" rx="3" ry="5" transform="rotate(-25,-12,-{h*0.18})"/>
      <ellipse cx="4" cy="-{h*0.13}" rx="3" ry="6" transform="rotate(10,4,-{h*0.13})"/>
      <ellipse cx="3" cy="-{h*0.17}" rx="3" ry="6" transform="rotate(5,3,-{h*0.17})"/>
      <ellipse cx="2" cy="-{h*0.20}" rx="2" ry="5" transform="rotate(8,2,-{h*0.20})"/>
      <ellipse cx="-13" cy="-{h*0.13}" rx="3" ry="6" transform="rotate(-30,-13,-{h*0.13})"/>
      <ellipse cx="-16" cy="-{h*0.16}" rx="2" ry="5" transform="rotate(-20,-16,-{h*0.16})"/>
    </g>
  </g>
  <!-- Pot 2: Lavender (top right) -->
  <g transform="translate({w*0.7},{h*0.45})">
    <path d="M-{w*0.045},0 L-{w*0.035},-{h*0.07} L{w*0.035},-{h*0.07} L{w*0.045},0Z" fill="url(#pot)"/>
    <rect x="-{w*0.05}" y="-{h*0.08}" width="{w*0.1}" height="{h*0.012}" fill="{TERRACOTTA}" rx="2"/>
    <g stroke="#5A7E3E" stroke-width="1.5" fill="none">
      <line x1="-8" y1="-{h*0.07}" x2="-12" y2="-{h*0.18}"/>
      <line x1="0" y1="-{h*0.07}" x2="2" y2="-{h*0.19}"/>
      <line x1="8" y1="-{h*0.07}" x2="10" y2="-{h*0.17}"/>
      <line x1="-15" y1="-{h*0.07}" x2="-18" y2="-{h*0.16}"/>
      <line x1="15" y1="-{h*0.07}" x2="14" y2="-{h*0.16}"/>
    </g>
    <g fill="#9B7DB8">
      <ellipse cx="-12" cy="-{h*0.18}" rx="4" ry="3"/>
      <ellipse cx="-12" cy="-{h*0.19}" rx="3.5" ry="2.5"/>
      <ellipse cx="2" cy="-{h*0.19}" rx="4" ry="3"/>
      <ellipse cx="2" cy="-{h*0.20}" rx="3.5" ry="2.5"/>
      <ellipse cx="10" cy="-{h*0.17}" rx="3.5" ry="2.5"/>
      <ellipse cx="-18" cy="-{h*0.16}" rx="3.5" ry="2.5"/>
      <ellipse cx="14" cy="-{h*0.16}" rx="3" ry="2"/>
    </g>
  </g>
  <!-- Pot 3: Sage (bottom center) -->
  <g transform="translate({w*0.45},{h*0.72})">
    <path d="M-{w*0.06},0 L-{w*0.05},-{h*0.09} L{w*0.05},-{h*0.09} L{w*0.06},0Z" fill="url(#pot)"/>
    <rect x="-{w*0.065}" y="-{h*0.10}" width="{w*0.13}" height="{h*0.015}" fill="{TERRACOTTA}" rx="2"/>
    <g fill="#8BA86A" opacity="0.9">
      <ellipse cx="-20" cy="-{h*0.12}" rx="18" ry="12" transform="rotate(-15,-20,-{h*0.12})"/>
      <ellipse cx="5" cy="-{h*0.14}" rx="16" ry="11" transform="rotate(10,5,-{h*0.14})"/>
      <ellipse cx="25" cy="-{h*0.11}" rx="15" ry="10" transform="rotate(20,25,-{h*0.11})"/>
      <ellipse cx="-10" cy="-{h*0.16}" rx="14" ry="9" transform="rotate(-5,-10,-{h*0.16})"/>
      <ellipse cx="15" cy="-{h*0.17}" rx="13" ry="8" transform="rotate(8,15,-{h*0.17})"/>
    </g>
  </g>
  <!-- Label tags on pots -->
  <g fill="{LINEN}" stroke="{WALNUT}" stroke-width="0.5" font-family="serif" font-size="12" opacity="0.6">
    <rect x="{w*0.18}" y="{h*0.39}" width="40" height="18" rx="2"/>
    <text x="{w*0.185}" y="{h*0.40}" fill="{WALNUT}" font-size="8" opacity="0.8">rosemary</text>
    <rect x="{w*0.66}" y="{h*0.39}" width="40" height="18" rx="2"/>
    <text x="{w*0.665}" y="{h*0.40}" fill="{WALNUT}" font-size="8" opacity="0.8">lavender</text>
  </g>
  <!-- Scattered seeds / dirt -->
  <g fill="{WALNUT}" opacity="0.15">
    <circle cx="{w*0.3}" cy="{h*0.46}" r="1.5"/>
    <circle cx="{w*0.35}" cy="{h*0.465}" r="1"/>
    <circle cx="{w*0.6}" cy="{h*0.73}" r="1.5"/>
    <circle cx="{w*0.55}" cy="{h*0.735}" r="1"/>
  </g>
''' + svg_footer()


def gen_autumn_harvest(w: int, h: int) -> str:
    """Pumpkins, wheat, and warm falling leaves."""
    return svg_header(w, h, WALLPAPERS[9][1]) + f'''  <defs>
    <linearGradient id="autumnSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#E8C9A0"/>
      <stop offset="50%" stop-color="{CREAM}"/>
      <stop offset="100%" stop-color="{TERRACOTTA}" stop-opacity="0.3"/>
    </linearGradient>
    <radialGradient id="pumpkin" cx="45%" cy="40%" r="55%">
      <stop offset="0%" stop-color="#E8943A"/>
      <stop offset="100%" stop-color="#C5742A"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#autumnSky)"/>
  <!-- Ground -->
  <rect x="0" y="{h*0.7}" width="{w}" height="{h*0.3}" fill="#8B7355"/>
  <rect x="0" y="{h*0.72}" width="{w}" height="{h*0.28}" fill="#6B5B45"/>
  <!-- Wheat stalks -->
  <g stroke="#C5A880" stroke-width="2" fill="none">
    <line x1="{w*0.15}" y1="{h*0.7}" x2="{w*0.13}" y2="{h*0.35}"/>
    <line x1="{w*0.2}" y1="{h*0.7}" x2="{w*0.22}" y2="{h*0.32}"/>
    <line x1="{w*0.25}" y1="{h*0.7}" x2="{w*0.24}" y2="{h*0.38}"/>
    <line x1="{w*0.75}" y1="{h*0.7}" x2="{w*0.77}" y2="{h*0.33}"/>
    <line x1="{w*0.8}" y1="{h*0.7}" x2="{w*0.78}" y2="{h*0.36}"/>
    <line x1="{w*0.85}" y1="{h*0.7}" x2="{w*0.87}" y2="{h*0.34}"/>
  </g>
  <!-- Wheat heads -->
  <g fill="#D4B87A">
    <ellipse cx="{w*0.13}" cy="{h*0.34}" rx="6" ry="14" transform="rotate(-5)"/>
    <ellipse cx="{w*0.22}" cy="{h*0.31}" rx="6" ry="15" transform="rotate(3)"/>
    <ellipse cx="{w*0.24}" cy="{h*0.37}" rx="5" ry="13" transform="rotate(-2)"/>
    <ellipse cx="{w*0.77}" cy="{h*0.32}" rx="6" ry="14" transform="rotate(4)"/>
    <ellipse cx="{w*0.78}" cy="{h*0.35}" rx="5" ry="13" transform="rotate(-3)"/>
    <ellipse cx="{w*0.87}" cy="{h*0.33}" rx="6" ry="14" transform="rotate(2)"/>
  </g>
  <!-- Pumpkins -->
  <g transform="translate({w*0.35},{h*0.68})">
    <ellipse cx="0" cy="0" rx="{w*0.08}" ry="{h*0.04}" fill="url(#pumpkin)"/>
    <path d="M-5,-{h*0.04} Q0,-{h*0.055} 5,-{h*0.04}" stroke="#5A7E3E" stroke-width="2" fill="none"/>
    <line x1="0" y1="-{h*0.04}" x2="0" y2="-{h*0.05}" stroke="{WALNUT}" stroke-width="3"/>
    <!-- Ribs -->
    <path d="M0,-{h*0.035} L0,{h*0.035}" stroke="#C5742A" stroke-width="1" opacity="0.3"/>
    <path d="M-{w*0.04},0 Q0,-{h*0.01} {w*0.04},0" stroke="#C5742A" stroke-width="1" opacity="0.2" fill="none"/>
  </g>
  <g transform="translate({w*0.55},{h*0.7})">
    <ellipse cx="0" cy="0" rx="{w*0.06}" ry="{h*0.03}" fill="url(#pumpkin)"/>
    <line x1="0" y1="-{h*0.03}" x2="0" y2="-{h*0.04}" stroke="{WALNUT}" stroke-width="2.5"/>
  </g>
  <g transform="translate({w*0.65},{h*0.72})">
    <ellipse cx="0" cy="0" rx="{w*0.04}" ry="{h*0.02}" fill="#E8B050"/>
    <line x1="0" y1="-{h*0.02}" x2="0" y2="-{h*0.025}" stroke="{WALNUT}" stroke-width="2"/>
  </g>
  <!-- Falling leaves -->
  <g opacity="0.6">
    <ellipse cx="{w*0.3}" cy="{h*0.15}" rx="15" ry="8" fill="#C5742A" transform="rotate(45,{w*0.3},{h*0.15})"/>
    <ellipse cx="{w*0.6}" cy="{h*0.25}" rx="12" ry="6" fill="{TERRACOTTA}" transform="rotate(-35,{w*0.6},{h*0.25})"/>
    <ellipse cx="{w*0.45}" cy="{h*0.4}" rx="14" ry="7" fill="#8B7355" transform="rotate(60,{w*0.45},{h*0.4})"/>
    <ellipse cx="{w*0.7}" cy="{h*0.12}" rx="10" ry="5" fill="#C5A880" transform="rotate(-50,{w*0.7},{h*0.12})"/>
    <ellipse cx="{w*0.2}" cy="{h*0.5}" rx="13" ry="6" fill="#D4956A" transform="rotate(40,{w*0.2},{h*0.5})"/>
    <ellipse cx="{w*0.8}" cy="{h*0.45}" rx="11" ry="5" fill="#C5742A" transform="rotate(-55,{w*0.8},{h*0.45})"/>
    <ellipse cx="{w*0.5}" cy="{h*0.55}" rx="12" ry="6" fill="{WHEAT}" transform="rotate(30,{w*0.5},{h*0.55})"/>
  </g>
''' + svg_footer()


def gen_pressed_flowers(w: int, h: int) -> str:
    """Botanical specimens on aged paper background."""
    return svg_header(w, h, WALLPAPERS[10][1]) + f'''  <defs>
    <linearGradient id="parchment" x1="0" y1="0" x2="0.1" y2="0.1">
      <stop offset="0%" stop-color="{LINEN}"/>
      <stop offset="100%" stop-color="{CREAM}"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#parchment)"/>
  <!-- Aged paper texture lines -->
  <g stroke="{WHEAT}" stroke-width="0.5" opacity="0.15">
    <line x1="0" y1="{h*0.1}" x2="{w}" y2="{h*0.1}"/>
    <line x1="0" y1="{h*0.2}" x2="{w}" y2="{h*0.2}"/>
    <line x1="0" y1="{h*0.3}" x2="{w}" y2="{h*0.3}"/>
    <line x1="0" y1="{h*0.4}" x2="{w}" y2="{h*0.4}"/>
    <line x1="0" y1="{h*0.5}" x2="{w}" y2="{h*0.5}"/>
    <line x1="0" y1="{h*0.6}" x2="{w}" y2="{h*0.6}"/>
    <line x1="0" y1="{h*0.7}" x2="{w}" y2="{h*0.7}"/>
    <line x1="0" y1="{h*0.8}" x2="{w}" y2="{h*0.8}"/>
    <line x1="0" y1="{h*0.9}" x2="{w}" y2="{h*0.9}"/>
  </g>
  <!-- Specimen 1: Pressed daisy -->
  <g transform="translate({w*0.3},{h*0.18})" opacity="0.75">
    <line x1="0" y1="0" x2="0" y2="{h*0.12}" stroke="#7A9E5A" stroke-width="1.5"/>
    <ellipse cx="-12" cy="0" rx="14" ry="6" fill="#E8C9D0" transform="rotate(0)"/>
    <ellipse cx="-12" cy="0" rx="14" ry="6" fill="#E8C9D0" transform="rotate(45)"/>
    <ellipse cx="-12" cy="0" rx="14" ry="6" fill="#E8C9D0" transform="rotate(90)"/>
    <ellipse cx="-12" cy="0" rx="14" ry="6" fill="#E8C9D0" transform="rotate(135)"/>
    <circle cx="0" cy="0" r="6" fill="{WHEAT}"/>
    <ellipse cx="-15" cy="{h*0.06}" rx="12" ry="5" fill="#7A9E5A" transform="rotate(-30,-15,{h*0.06})"/>
    <ellipse cx="12" cy="{h*0.08}" rx="10" ry="4" fill="#7A9E5A" transform="rotate(25,12,{h*0.08})"/>
  </g>
  <!-- Specimen 2: Pressed fern -->
  <g transform="translate({w*0.65},{h*0.35})" opacity="0.7">
    <line x1="0" y1="-{h*0.08}" x2="0" y2="{h*0.08}" stroke="#5A7E3E" stroke-width="1.5"/>
    <g fill="#6B8E4E">
      <ellipse cx="-10" cy="-{h*0.06}" rx="8" ry="3" transform="rotate(-30,-10,-{h*0.06})"/>
      <ellipse cx="10" cy="-{h*0.04}" rx="8" ry="3" transform="rotate(30,10,-{h*0.04})"/>
      <ellipse cx="-10" cy="-{h*0.02}" rx="8" ry="3" transform="rotate(-30,-10,-{h*0.02})"/>
      <ellipse cx="10" cy="0" rx="8" ry="3" transform="rotate(30,10,0)"/>
      <ellipse cx="-10" cy="{h*0.02}" rx="7" ry="3" transform="rotate(-30,-10,{h*0.02})"/>
      <ellipse cx="10" cy="{h*0.04}" rx="7" ry="3" transform="rotate(30,10,{h*0.04})"/>
      <ellipse cx="-8" cy="{h*0.06}" rx="6" ry="2" transform="rotate(-30,-8,{h*0.06})"/>
    </g>
  </g>
  <!-- Specimen 3: Pressed wildflower -->
  <g transform="translate({w*0.35},{h*0.58})" opacity="0.7">
    <path d="M0,{h*0.1} Q-5,{h*0.05} 0,0" stroke="#7A9E5A" stroke-width="1.5" fill="none"/>
    <g fill="#B08FC7">
      <ellipse cx="-8" cy="0" rx="10" ry="4" transform="rotate(0)"/>
      <ellipse cx="-8" cy="0" rx="10" ry="4" transform="rotate(72)"/>
      <ellipse cx="-8" cy="0" rx="10" ry="4" transform="rotate(144)"/>
      <ellipse cx="-8" cy="0" rx="10" ry="4" transform="rotate(216)"/>
      <ellipse cx="-8" cy="0" rx="10" ry="4" transform="rotate(288)"/>
    </g>
    <circle cx="0" cy="0" r="4" fill="{WHEAT}"/>
  </g>
  <!-- Specimen 4: Small rose -->
  <g transform="translate({w*0.7},{h*0.72})" opacity="0.65">
    <line x1="0" y1="10" x2="0" y2="{h*0.08}" stroke="#5A7E3E" stroke-width="1.5"/>
    <circle cx="0" cy="0" r="18" fill="#D4A0A0" opacity="0.8"/>
    <path d="M0,-6 Q-5,0 0,6 Q5,0 0,-6Z" fill="#C08080" opacity="0.6"/>
    <circle cx="0" cy="0" r="5" fill="#B07070"/>
    <ellipse cx="-12" cy="{h*0.04}" rx="10" ry="4" fill="#5A7E3E" transform="rotate(-25,-12,{h*0.04})"/>
  </g>
  <!-- Handwritten-style labels -->
  <g fill="{WALNUT}" font-family="serif" font-style="italic" opacity="0.4">
    <text x="{w*0.25}" y="{h*0.32}" font-size="14">Bellis perennis</text>
    <text x="{w*0.58}" y="{h*0.52}" font-size="14">Dryopteris</text>
    <text x="{w*0.28}" y="{h*0.72}" font-size="14">Viola odorata</text>
    <text x="{w*0.62}" y="{h*0.85}" font-size="14">Rosa canina</text>
  </g>
  <!-- Tape effect holding specimens -->
  <g fill="{CREAM}" opacity="0.3">
    <rect x="{w*0.25}" y="{h*0.14}" width="40" height="12" rx="1" transform="rotate(-8,{w*0.25},{h*0.14})"/>
    <rect x="{w*0.6}" y="{h*0.30}" width="40" height="12" rx="1" transform="rotate(5,{w*0.6},{h*0.30})"/>
    <rect x="{w*0.3}" y="{h*0.54}" width="40" height="12" rx="1" transform="rotate(-3,{w*0.3},{h*0.54})"/>
    <rect x="{w*0.65}" y="{h*0.68}" width="40" height="12" rx="1" transform="rotate(7,{w*0.65},{h*0.68})"/>
  </g>
''' + svg_footer()


def gen_honeybee_path(w: int, h: int) -> str:
    """Bees hovering over clover and wildflowers."""
    return svg_header(w, h, WALLPAPERS[11][1]) + f'''  <defs>
    <linearGradient id="summerSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#C8DDE8"/>
      <stop offset="50%" stop-color="{CREAM}"/>
      <stop offset="100%" stop-color="{SAGE}"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#summerSky)"/>
  <!-- Meadow ground -->
  <rect x="0" y="{h*0.55}" width="{w}" height="{h*0.45}" fill="{SAGE}"/>
  <rect x="0" y="{h*0.58}" width="{w}" height="{h*0.42}" fill="#6B8E4E"/>
  <!-- Clover patches -->
  <g fill="#5A7E3E" opacity="0.7">
    <circle cx="{w*0.15}" cy="{h*0.62}" r="20"/><circle cx="{w*0.18}" cy="{h*0.64}" r="18"/>
    <circle cx="{w*0.5}" cy="{h*0.65}" r="22"/><circle cx="{w*0.53}" cy="{h*0.63}" r="19"/>
    <circle cx="{w*0.8}" cy="{h*0.6}" r="20"/><circle cx="{w*0.83}" cy="{h*0.62}" r="17"/>
  </g>
  <!-- Clover flowers (white pom-poms) -->
  <g fill="white" opacity="0.8">
    <circle cx="{w*0.16}" cy="{h*0.60}" r="8"/>
    <circle cx="{w*0.51}" cy="{h*0.62}" r="9"/>
    <circle cx="{w*0.81}" cy="{h*0.58}" r="7"/>
    <circle cx="{w*0.35}" cy="{h*0.64}" r="6"/>
    <circle cx="{w*0.68}" cy="{h*0.61}" r="8"/>
  </g>
  <!-- Wildflower stems and blooms -->
  <g stroke="#5A7E3E" stroke-width="2" fill="none">
    <line x1="{w*0.25}" y1="{h*0.58}" x2="{w*0.24}" y2="{h*0.38}"/>
    <line x1="{w*0.4}" y1="{h*0.58}" x2="{w*0.42}" y2="{h*0.35}"/>
    <line x1="{w*0.6}" y1="{h*0.58}" x2="{w*0.58}" y2="{h*0.4}"/>
    <line x1="{w*0.75}" y1="{h*0.58}" x2="{w*0.76}" y2="{h*0.37}"/>
  </g>
  <g>
    <circle cx="{w*0.24}" cy="{h*0.37}" r="10" fill="#FFD700" opacity="0.8"/>
    <circle cx="{w*0.24}" cy="{h*0.37}" r="4" fill="{WALNUT}"/>
    <circle cx="{w*0.42}" cy="{h*0.34}" r="8" fill="#E8A0BF" opacity="0.8"/>
    <circle cx="{w*0.42}" cy="{h*0.34}" r="3" fill="{TERRACOTTA}"/>
    <circle cx="{w*0.58}" cy="{h*0.39}" r="9" fill="{LINEN}" opacity="0.9"/>
    <circle cx="{w*0.58}" cy="{h*0.39}" r="3.5" fill="{WHEAT}"/>
    <circle cx="{w*0.76}" cy="{h*0.36}" r="10" fill="#FFD700" opacity="0.8"/>
    <circle cx="{w*0.76}" cy="{h*0.36}" r="4" fill="{WALNUT}"/>
  </g>
  <!-- Honeybees -->
  <g transform="translate({w*0.3},{h*0.28})">
    <ellipse cx="0" cy="0" rx="10" ry="7" fill="#E8B030"/>
    <line x1="-3" y1="-6" x2="-3" y2="6" stroke="#333" stroke-width="1.5"/>
    <line x1="3" y1="-6" x2="3" y2="6" stroke="#333" stroke-width="1.5"/>
    <ellipse cx="-8" cy="-6" rx="8" ry="4" fill="white" opacity="0.5" transform="rotate(-20,-8,-6)"/>
    <ellipse cx="8" cy="-6" rx="8" ry="4" fill="white" opacity="0.5" transform="rotate(20,8,-6)"/>
  </g>
  <g transform="translate({w*0.65},{h*0.3}) scale(0.8)">
    <ellipse cx="0" cy="0" rx="10" ry="7" fill="#E8B030"/>
    <line x1="-3" y1="-6" x2="-3" y2="6" stroke="#333" stroke-width="1.5"/>
    <line x1="3" y1="-6" x2="3" y2="6" stroke="#333" stroke-width="1.5"/>
    <ellipse cx="-8" cy="-6" rx="8" ry="4" fill="white" opacity="0.5" transform="rotate(-20,-8,-6)"/>
    <ellipse cx="8" cy="-6" rx="8" ry="4" fill="white" opacity="0.5" transform="rotate(20,8,-6)"/>
  </g>
  <g transform="translate({w*0.5},{h*0.2}) scale(0.6)" opacity="0.6">
    <ellipse cx="0" cy="0" rx="10" ry="7" fill="#E8B030"/>
    <line x1="-3" y1="-6" x2="-3" y2="6" stroke="#333" stroke-width="1.5"/>
    <line x1="3" y1="-6" x2="3" y2="6" stroke="#333" stroke-width="1.5"/>
    <ellipse cx="-8" cy="-6" rx="8" ry="4" fill="white" opacity="0.5"/>
    <ellipse cx="8" cy="-6" rx="8" ry="4" fill="white" opacity="0.5"/>
  </g>
  <!-- Bee flight paths (dotted) -->
  <g stroke="{WHEAT}" stroke-width="1" stroke-dasharray="3,5" fill="none" opacity="0.3">
    <path d="M{w*0.3},{h*0.28} Q{w*0.35},{h*0.22} {w*0.4},{h*0.25} Q{w*0.45},{h*0.28} {w*0.42},{h*0.34}"/>
    <path d="M{w*0.65},{h*0.3} Q{w*0.7},{h*0.25} {w*0.72},{h*0.3} Q{w*0.74},{h*0.35} {w*0.76},{h*0.36}"/>
  </g>
''' + svg_footer()


def gen_rainy_window(w: int, h: int) -> str:
    """Raindrops on glass, blurred garden beyond."""
    return svg_header(w, h, WALLPAPERS[12][1]) + f'''  <defs>
    <linearGradient id="rainyBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#8A9BA5"/>
      <stop offset="100%" stop-color="#6A7A6A"/>
    </linearGradient>
    <radialGradient id="drop" cx="40%" cy="30%" r="60%">
      <stop offset="0%" stop-color="white" stop-opacity="0.4"/>
      <stop offset="100%" stop-color="white" stop-opacity="0.1"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#rainyBg)"/>
  <!-- Blurred garden behind glass -->
  <g opacity="0.3" filter="none">
    <rect x="0" y="{h*0.6}" width="{w}" height="{h*0.4}" fill="{SAGE}"/>
    <circle cx="{w*0.3}" cy="{h*0.5}" r="{w*0.15}" fill="#5A7E3E"/>
    <circle cx="{w*0.7}" cy="{h*0.5}" r="{w*0.12}" fill="#4A7A34"/>
    <circle cx="{w*0.5}" cy="{h*0.55}" r="{w*0.1}" fill="#6B8E4E"/>
  </g>
  <!-- Raindrops on glass -->
  <g>
    <!-- Large drops with trails -->
    <g fill="url(#drop)">
      <ellipse cx="{w*0.15}" cy="{h*0.1}" rx="8" ry="10"/>
      <path d="M{w*0.15},{h*0.1} Q{w*0.14},{h*0.2} {w*0.155},{h*0.35}" stroke="white" stroke-opacity="0.15" stroke-width="2" fill="none"/>

      <ellipse cx="{w*0.4}" cy="{h*0.05}" rx="10" ry="12"/>
      <path d="M{w*0.4},{h*0.05} Q{w*0.39},{h*0.15} {w*0.41},{h*0.3} Q{w*0.405},{h*0.45} {w*0.42},{h*0.55}" stroke="white" stroke-opacity="0.12" stroke-width="2.5" fill="none"/>

      <ellipse cx="{w*0.7}" cy="{h*0.12}" rx="9" ry="11"/>
      <path d="M{w*0.7},{h*0.12} Q{w*0.69},{h*0.25} {w*0.71},{h*0.4}" stroke="white" stroke-opacity="0.15" stroke-width="2" fill="none"/>

      <ellipse cx="{w*0.85}" cy="{h*0.08}" rx="7" ry="9"/>
      <path d="M{w*0.85},{h*0.08} Q{w*0.84},{h*0.2} {w*0.86},{h*0.38} Q{w*0.855},{h*0.5} {w*0.87},{h*0.65}" stroke="white" stroke-opacity="0.1" stroke-width="2" fill="none"/>

      <ellipse cx="{w*0.25}" cy="{h*0.3}" rx="6" ry="8"/>
      <ellipse cx="{w*0.55}" cy="{h*0.25}" rx="7" ry="9"/>
      <path d="M{w*0.55},{h*0.25} Q{w*0.54},{h*0.4} {w*0.56},{h*0.6}" stroke="white" stroke-opacity="0.12" stroke-width="1.5" fill="none"/>

      <ellipse cx="{w*0.3}" cy="{h*0.5}" rx="8" ry="10"/>
      <ellipse cx="{w*0.65}" cy="{h*0.45}" rx="6" ry="8"/>
      <ellipse cx="{w*0.5}" cy="{h*0.6}" rx="9" ry="11"/>
      <ellipse cx="{w*0.8}" cy="{h*0.55}" rx="7" ry="9"/>
      <ellipse cx="{w*0.1}" cy="{h*0.65}" rx="8" ry="10"/>
      <ellipse cx="{w*0.45}" cy="{h*0.75}" rx="6" ry="8"/>
      <ellipse cx="{w*0.9}" cy="{h*0.7}" rx="7" ry="9"/>
    </g>
    <!-- Tiny drops scattered -->
    <g fill="white" opacity="0.2">
      <circle cx="{w*0.08}" cy="{h*0.15}" r="3"/>
      <circle cx="{w*0.22}" cy="{h*0.08}" r="2"/>
      <circle cx="{w*0.35}" cy="{h*0.22}" r="2.5"/>
      <circle cx="{w*0.48}" cy="{h*0.15}" r="2"/>
      <circle cx="{w*0.62}" cy="{h*0.08}" r="3"/>
      <circle cx="{w*0.78}" cy="{h*0.22}" r="2"/>
      <circle cx="{w*0.92}" cy="{h*0.18}" r="2.5"/>
      <circle cx="{w*0.12}" cy="{h*0.42}" r="2"/>
      <circle cx="{w*0.38}" cy="{h*0.38}" r="3"/>
      <circle cx="{w*0.58}" cy="{h*0.48}" r="2"/>
      <circle cx="{w*0.72}" cy="{h*0.35}" r="2.5"/>
      <circle cx="{w*0.88}" cy="{h*0.42}" r="2"/>
      <circle cx="{w*0.18}" cy="{h*0.58}" r="2.5"/>
      <circle cx="{w*0.42}" cy="{h*0.52}" r="2"/>
      <circle cx="{w*0.75}" cy="{h*0.62}" r="3"/>
      <circle cx="{w*0.95}" cy="{h*0.58}" r="2"/>
      <circle cx="{w*0.05}" cy="{h*0.78}" r="2"/>
      <circle cx="{w*0.32}" cy="{h*0.82}" r="2.5"/>
      <circle cx="{w*0.58}" cy="{h*0.85}" r="2"/>
      <circle cx="{w*0.82}" cy="{h*0.78}" r="3"/>
    </g>
  </g>
  <!-- Warm light glow from inside (bottom) -->
  <g opacity="0.1">
    <rect x="0" y="{h*0.85}" width="{w}" height="{h*0.15}" fill="{LINEN}"/>
  </g>
''' + svg_footer()


def gen_woven_basket(w: int, h: int) -> str:
    """Wicker texture with dried flowers overflowing."""
    return svg_header(w, h, WALLPAPERS[13][1]) + f'''  <rect width="{w}" height="{h}" fill="{CREAM}"/>
  <!-- Wicker basket body -->
  <g transform="translate({w*0.5},{h*0.55})">
    <!-- Basket shape -->
    <path d="M-{w*0.35},0 Q-{w*0.38},{h*0.2} -{w*0.25},{h*0.25} L{w*0.25},{h*0.25} Q{w*0.38},{h*0.2} {w*0.35},0Z" fill="{WHEAT}" stroke="{WALNUT}" stroke-width="2"/>
    <!-- Wicker horizontal weave lines -->
    <g stroke="{WALNUT}" stroke-width="1" opacity="0.3">
      <path d="M-{w*0.34},{h*0.04} Q0,{h*0.06} {w*0.34},{h*0.04}" fill="none"/>
      <path d="M-{w*0.33},{h*0.08} Q0,{h*0.10} {w*0.33},{h*0.08}" fill="none"/>
      <path d="M-{w*0.31},{h*0.12} Q0,{h*0.14} {w*0.31},{h*0.12}" fill="none"/>
      <path d="M-{w*0.29},{h*0.16} Q0,{h*0.18} {w*0.29},{h*0.16}" fill="none"/>
      <path d="M-{w*0.27},{h*0.20} Q0,{h*0.22} {w*0.27},{h*0.20}" fill="none"/>
    </g>
    <!-- Vertical weave -->
    <g stroke="{WALNUT}" stroke-width="0.8" opacity="0.2">
      <line x1="-{w*0.25}" y1="0" x2="-{w*0.2}" y2="{h*0.24}"/>
      <line x1="-{w*0.15}" y1="0" x2="-{w*0.12}" y2="{h*0.25}"/>
      <line x1="-{w*0.05}" y1="0" x2="-{w*0.03}" y2="{h*0.25}"/>
      <line x1="{w*0.05}" y1="0" x2="{w*0.03}" y2="{h*0.25}"/>
      <line x1="{w*0.15}" y1="0" x2="{w*0.12}" y2="{h*0.25}"/>
      <line x1="{w*0.25}" y1="0" x2="{w*0.2}" y2="{h*0.24}"/>
    </g>
    <!-- Basket rim -->
    <ellipse cx="0" cy="0" rx="{w*0.35}" ry="{h*0.025}" fill="{TERRACOTTA}" opacity="0.5"/>
  </g>
  <!-- Dried flowers overflowing from basket -->
  <g transform="translate({w*0.5},{h*0.52})">
    <!-- Stems -->
    <g stroke="#8BA86A" stroke-width="2" fill="none" opacity="0.7">
      <path d="M-{w*0.15},-{h*0.02} Q-{w*0.18},-{h*0.12} -{w*0.12},-{h*0.2}"/>
      <path d="M-{w*0.05},-{h*0.02} Q-{w*0.03},-{h*0.15} -{w*0.08},-{h*0.25}"/>
      <path d="M{w*0.05},-{h*0.02} Q{w*0.08},-{h*0.14} {w*0.03},-{h*0.22}"/>
      <path d="M{w*0.15},-{h*0.02} Q{w*0.18},-{h*0.10} {w*0.14},-{h*0.18}"/>
      <path d="M0,-{h*0.02} Q-{w*0.02},-{h*0.16} {w*0.02},-{h*0.28}"/>
    </g>
    <!-- Dried flower heads -->
    <circle cx="-{w*0.12}" cy="-{h*0.2}" r="12" fill="{TERRACOTTA}" opacity="0.7"/>
    <circle cx="-{w*0.08}" cy="-{h*0.25}" r="10" fill="#D4B87A" opacity="0.8"/>
    <circle cx="{w*0.03}" cy="-{h*0.22}" r="11" fill="#E8A0BF" opacity="0.6"/>
    <circle cx="{w*0.14}" cy="-{h*0.18}" r="9" fill="{WHEAT}" opacity="0.8"/>
    <circle cx="{w*0.02}" cy="-{h*0.28}" r="13" fill="{LINEN}" opacity="0.7"/>
    <!-- Dried lavender sprigs -->
    <g fill="#9B7DB8" opacity="0.6">
      <ellipse cx="-{w*0.2}" cy="-{h*0.15}" rx="3" ry="5"/>
      <ellipse cx="-{w*0.2}" cy="-{h*0.17}" rx="3" ry="4"/>
      <ellipse cx="{w*0.2}" cy="-{h*0.14}" rx="3" ry="5"/>
      <ellipse cx="{w*0.2}" cy="-{h*0.16}" rx="3" ry="4"/>
    </g>
  </g>
  <!-- Scattered petals on surface -->
  <g fill="{TERRACOTTA}" opacity="0.3">
    <ellipse cx="{w*0.2}" cy="{h*0.85}" rx="8" ry="5" transform="rotate(30,{w*0.2},{h*0.85})"/>
    <ellipse cx="{w*0.7}" cy="{h*0.88}" rx="7" ry="4" transform="rotate(-40,{w*0.7},{h*0.88})"/>
    <ellipse cx="{w*0.5}" cy="{h*0.9}" rx="6" ry="4" transform="rotate(50,{w*0.5},{h*0.9})"/>
  </g>
''' + svg_footer()


def gen_sunset_meadow(w: int, h: int) -> str:
    """Pink-gold sunset over rolling green hills."""
    return svg_header(w, h, WALLPAPERS[14][1]) + f'''  <defs>
    <linearGradient id="sunsetSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#D4A0C0"/>
      <stop offset="30%" stop-color="#E8B890"/>
      <stop offset="60%" stop-color="#F5D4A0"/>
      <stop offset="100%" stop-color="{LINEN}"/>
    </linearGradient>
    <radialGradient id="sun" cx="50%" cy="60%" r="40%">
      <stop offset="0%" stop-color="#FFE4B5" stop-opacity="0.9"/>
      <stop offset="50%" stop-color="#F5D4A0" stop-opacity="0.4"/>
      <stop offset="100%" stop-color="#F5D4A0" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#sunsetSky)"/>
  <!-- Sun -->
  <circle cx="{w*0.5}" cy="{h*0.35}" r="{w*0.3}" fill="url(#sun)"/>
  <circle cx="{w*0.5}" cy="{h*0.35}" r="{w*0.06}" fill="#FFE4B5" opacity="0.8"/>
  <!-- Rolling hills (back to front) -->
  <ellipse cx="{w*0.3}" cy="{h*0.55}" rx="{w*0.5}" ry="{h*0.08}" fill="#8BA86A" opacity="0.5"/>
  <ellipse cx="{w*0.7}" cy="{h*0.58}" rx="{w*0.45}" ry="{h*0.07}" fill="#7A9E5A" opacity="0.6"/>
  <ellipse cx="{w*0.4}" cy="{h*0.62}" rx="{w*0.55}" ry="{h*0.09}" fill="{SAGE}" opacity="0.7"/>
  <ellipse cx="{w*0.6}" cy="{h*0.67}" rx="{w*0.5}" ry="{h*0.08}" fill="#6B8E4E" opacity="0.8"/>
  <!-- Foreground meadow -->
  <rect x="0" y="{h*0.7}" width="{w}" height="{h*0.3}" fill="#5A7E3E"/>
  <!-- Wildflower dots in foreground -->
  <g opacity="0.6">
    <circle cx="{w*0.1}" cy="{h*0.75}" r="4" fill="#E8A0BF"/>
    <circle cx="{w*0.25}" cy="{h*0.78}" r="3" fill="#FFD700"/>
    <circle cx="{w*0.4}" cy="{h*0.76}" r="4" fill="white"/>
    <circle cx="{w*0.55}" cy="{h*0.8}" r="3" fill="#E8A0BF"/>
    <circle cx="{w*0.7}" cy="{h*0.77}" r="4" fill="#FFD700"/>
    <circle cx="{w*0.85}" cy="{h*0.79}" r="3" fill="white"/>
    <circle cx="{w*0.15}" cy="{h*0.82}" r="3" fill="#FFD700"/>
    <circle cx="{w*0.35}" cy="{h*0.84}" r="4" fill="#E8A0BF"/>
    <circle cx="{w*0.6}" cy="{h*0.83}" r="3" fill="white"/>
    <circle cx="{w*0.8}" cy="{h*0.85}" r="4" fill="#E8A0BF"/>
  </g>
  <!-- Soft clouds -->
  <g fill="white" opacity="0.15">
    <ellipse cx="{w*0.2}" cy="{h*0.12}" rx="{w*0.12}" ry="{h*0.02}"/>
    <ellipse cx="{w*0.75}" cy="{h*0.08}" rx="{w*0.15}" ry="{h*0.025}"/>
  </g>
''' + svg_footer()


def gen_fairy_ring(w: int, h: int) -> str:
    """Circle of mushrooms in moonlit clearing."""
    return svg_header(w, h, WALLPAPERS[15][1]) + f'''  <defs>
    <linearGradient id="nightBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1A2A2E"/>
      <stop offset="100%" stop-color="#2E3D22"/>
    </linearGradient>
    <radialGradient id="moonGlow" cx="50%" cy="20%" r="35%">
      <stop offset="0%" stop-color="{LINEN}" stop-opacity="0.3"/>
      <stop offset="100%" stop-color="{LINEN}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#nightBg)"/>
  <rect width="{w}" height="{h}" fill="url(#moonGlow)"/>
  <!-- Moon -->
  <circle cx="{w*0.5}" cy="{h*0.15}" r="{w*0.06}" fill="{LINEN}" opacity="0.8"/>
  <circle cx="{w*0.53}" cy="{h*0.14}" r="{w*0.05}" fill="#1A2A2E" opacity="0.3"/>
  <!-- Clearing floor -->
  <ellipse cx="{w*0.5}" cy="{h*0.65}" rx="{w*0.4}" ry="{h*0.12}" fill="#3A5C2A" opacity="0.5"/>
  <!-- Mushroom ring (8 mushrooms in a circle) -->
  <g>
    <!-- Mushroom positions arranged in ellipse -->
    <g transform="translate({w*0.5},{h*0.58})">
      <path d="M-6,2 Q-7,15 -5,30 L5,30 Q7,15 6,2Z" fill="{CREAM}"/>
      <ellipse cx="0" cy="2" rx="18" ry="10" fill="{TERRACOTTA}"/>
      <circle cx="-5" cy="0" r="2" fill="{LINEN}" opacity="0.6"/>
      <circle cx="6" cy="1" r="1.5" fill="{LINEN}" opacity="0.5"/>
    </g>
    <g transform="translate({w*0.35},{h*0.6})">
      <path d="M-5,2 Q-6,12 -4,25 L4,25 Q6,12 5,2Z" fill="{CREAM}"/>
      <ellipse cx="0" cy="2" rx="15" ry="8" fill="{TERRACOTTA}"/>
    </g>
    <g transform="translate({w*0.65},{h*0.6})">
      <path d="M-5,2 Q-6,12 -4,25 L4,25 Q6,12 5,2Z" fill="{CREAM}"/>
      <ellipse cx="0" cy="2" rx="15" ry="8" fill="{TERRACOTTA}"/>
    </g>
    <g transform="translate({w*0.28},{h*0.65})">
      <path d="M-4,2 Q-5,10 -3,20 L3,20 Q5,10 4,2Z" fill="{CREAM}"/>
      <ellipse cx="0" cy="2" rx="12" ry="7" fill="#C45A4A"/>
      <circle cx="-3" cy="0" r="1.5" fill="{LINEN}" opacity="0.5"/>
    </g>
    <g transform="translate({w*0.72},{h*0.65})">
      <path d="M-4,2 Q-5,10 -3,20 L3,20 Q5,10 4,2Z" fill="{CREAM}"/>
      <ellipse cx="0" cy="2" rx="12" ry="7" fill="#C45A4A"/>
      <circle cx="4" cy="0" r="1.5" fill="{LINEN}" opacity="0.5"/>
    </g>
    <g transform="translate({w*0.35},{h*0.72})">
      <path d="M-4,2 Q-5,10 -3,18 L3,18 Q5,10 4,2Z" fill="{CREAM}"/>
      <ellipse cx="0" cy="2" rx="13" ry="7" fill="{WALNUT}"/>
    </g>
    <g transform="translate({w*0.65},{h*0.72})">
      <path d="M-4,2 Q-5,10 -3,18 L3,18 Q5,10 4,2Z" fill="{CREAM}"/>
      <ellipse cx="0" cy="2" rx="13" ry="7" fill="{WALNUT}"/>
    </g>
    <g transform="translate({w*0.5},{h*0.74})">
      <path d="M-5,2 Q-6,12 -4,24 L4,24 Q6,12 5,2Z" fill="{CREAM}"/>
      <ellipse cx="0" cy="2" rx="16" ry="9" fill="{TERRACOTTA}"/>
    </g>
  </g>
  <!-- Fireflies / magical particles -->
  <g>
    <circle cx="{w*0.3}" cy="{h*0.4}" r="3" fill="#FFE4B5" opacity="0.6"/>
    <circle cx="{w*0.3}" cy="{h*0.4}" r="8" fill="#FFE4B5" opacity="0.1"/>
    <circle cx="{w*0.6}" cy="{h*0.35}" r="2.5" fill="#FFE4B5" opacity="0.5"/>
    <circle cx="{w*0.6}" cy="{h*0.35}" r="7" fill="#FFE4B5" opacity="0.08"/>
    <circle cx="{w*0.45}" cy="{h*0.45}" r="2" fill="#E0FFE0" opacity="0.6"/>
    <circle cx="{w*0.45}" cy="{h*0.45}" r="6" fill="#E0FFE0" opacity="0.1"/>
    <circle cx="{w*0.7}" cy="{h*0.5}" r="2.5" fill="#FFE4B5" opacity="0.5"/>
    <circle cx="{w*0.7}" cy="{h*0.5}" r="7" fill="#FFE4B5" opacity="0.08"/>
    <circle cx="{w*0.2}" cy="{h*0.55}" r="2" fill="#E0FFE0" opacity="0.4"/>
    <circle cx="{w*0.55}" cy="{h*0.3}" r="3" fill="#FFE4B5" opacity="0.4"/>
    <circle cx="{w*0.55}" cy="{h*0.3}" r="9" fill="#FFE4B5" opacity="0.06"/>
    <circle cx="{w*0.8}" cy="{h*0.42}" r="2" fill="#E0FFE0" opacity="0.5"/>
  </g>
  <!-- Stars -->
  <g fill="white" opacity="0.4">
    <circle cx="{w*0.1}" cy="{h*0.05}" r="1.5"/>
    <circle cx="{w*0.3}" cy="{h*0.08}" r="1"/>
    <circle cx="{w*0.7}" cy="{h*0.03}" r="1.5"/>
    <circle cx="{w*0.9}" cy="{h*0.07}" r="1"/>
    <circle cx="{w*0.15}" cy="{h*0.18}" r="1"/>
    <circle cx="{w*0.85}" cy="{h*0.2}" r="1.5"/>
    <circle cx="{w*0.4}" cy="{h*0.12}" r="1"/>
  </g>
  <!-- Dark trees around edges -->
  <g fill="#1A2A1E" opacity="0.6">
    <path d="M0,0 L0,{h*0.5} L{w*0.08},{h*0.5} Q{w*0.1},{h*0.3} {w*0.05},{h*0.1} Q{w*0.02},{h*0.05} 0,0Z"/>
    <path d="M{w},0 L{w},{h*0.5} L{w*0.92},{h*0.5} Q{w*0.9},{h*0.3} {w*0.95},{h*0.1} Q{w*0.98},{h*0.05} {w},0Z"/>
  </g>
''' + svg_footer()


def gen_lavender_fields(w: int, h: int) -> str:
    """Rows of purple lavender to horizon."""
    return svg_header(w, h, WALLPAPERS[16][1]) + f'''  <defs>
    <linearGradient id="fieldSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#D4C8E0"/>
      <stop offset="50%" stop-color="{CREAM}"/>
      <stop offset="100%" stop-color="#9B7DB8" stop-opacity="0.3"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#fieldSky)"/>
  <!-- Horizon line -->
  <line x1="0" y1="{h*0.4}" x2="{w}" y2="{h*0.4}" stroke="{SAGE}" stroke-width="1" opacity="0.3"/>
  <!-- Distant lavender rows (perspective) -->
  <g opacity="0.4">
    <rect x="0" y="{h*0.40}" width="{w}" height="{h*0.02}" fill="#9B7DB8"/>
    <rect x="0" y="{h*0.43}" width="{w}" height="{h*0.01}" fill="#5A7E3E"/>
    <rect x="0" y="{h*0.44}" width="{w}" height="{h*0.025}" fill="#8B6BA8"/>
    <rect x="0" y="{h*0.47}" width="{w}" height="{h*0.012}" fill="#5A7E3E"/>
  </g>
  <!-- Middle rows -->
  <g opacity="0.6">
    <rect x="0" y="{h*0.49}" width="{w}" height="{h*0.035}" fill="#9B7DB8"/>
    <rect x="0" y="{h*0.53}" width="{w}" height="{h*0.015}" fill="#5A7E3E"/>
    <rect x="0" y="{h*0.55}" width="{w}" height="{h*0.04}" fill="#8B6BA8"/>
    <rect x="0" y="{h*0.60}" width="{w}" height="{h*0.02}" fill="#5A7E3E"/>
  </g>
  <!-- Foreground rows (detailed) -->
  <g opacity="0.8">
    <rect x="0" y="{h*0.63}" width="{w}" height="{h*0.05}" fill="#9B7DB8"/>
    <rect x="0" y="{h*0.69}" width="{w}" height="{h*0.025}" fill="#5A7E3E"/>
    <rect x="0" y="{h*0.72}" width="{w}" height="{h*0.06}" fill="#7B5E8E"/>
    <rect x="0" y="{h*0.79}" width="{w}" height="{h*0.03}" fill="#5A7E3E"/>
    <rect x="0" y="{h*0.83}" width="{w}" height="{h*0.07}" fill="#9B7DB8"/>
    <rect x="0" y="{h*0.91}" width="{w}" height="{h*0.04}" fill="#4A7A34"/>
  </g>
  <!-- Individual lavender sprigs in close foreground -->
  <g>
    <g transform="translate({w*0.15},{h*0.95})">
      <line x1="0" y1="0" x2="-2" y2="-{h*0.08}" stroke="#5A7E3E" stroke-width="2"/>
      <g fill="#9B7DB8"><ellipse cx="-2" cy="-{h*0.08}" rx="4" ry="3"/><ellipse cx="-2" cy="-{h*0.085}" rx="3.5" ry="2.5"/><ellipse cx="-2" cy="-{h*0.09}" rx="3" ry="2"/></g>
    </g>
    <g transform="translate({w*0.35},{h*0.96})">
      <line x1="0" y1="0" x2="2" y2="-{h*0.09}" stroke="#5A7E3E" stroke-width="2"/>
      <g fill="#8B6BA8"><ellipse cx="2" cy="-{h*0.09}" rx="4" ry="3"/><ellipse cx="2" cy="-{h*0.095}" rx="3.5" ry="2.5"/></g>
    </g>
    <g transform="translate({w*0.55},{h*0.95})">
      <line x1="0" y1="0" x2="-1" y2="-{h*0.07}" stroke="#5A7E3E" stroke-width="2"/>
      <g fill="#9B7DB8"><ellipse cx="-1" cy="-{h*0.07}" rx="4" ry="3"/><ellipse cx="-1" cy="-{h*0.075}" rx="3" ry="2.5"/></g>
    </g>
    <g transform="translate({w*0.75},{h*0.96})">
      <line x1="0" y1="0" x2="1" y2="-{h*0.085}" stroke="#5A7E3E" stroke-width="2"/>
      <g fill="#7B5E8E"><ellipse cx="1" cy="-{h*0.085}" rx="4" ry="3"/><ellipse cx="1" cy="-{h*0.09}" rx="3.5" ry="2.5"/></g>
    </g>
    <g transform="translate({w*0.9},{h*0.95})">
      <line x1="0" y1="0" x2="-2" y2="-{h*0.075}" stroke="#5A7E3E" stroke-width="2"/>
      <g fill="#9B7DB8"><ellipse cx="-2" cy="-{h*0.075}" rx="3.5" ry="2.5"/></g>
    </g>
  </g>
  <!-- Butterfly -->
  <g transform="translate({w*0.6},{h*0.5}) scale(0.8)" opacity="0.5">
    <path d="M0,0 Q-15,-12 -18,-28 Q-10,-18 0,-5Z" fill="white"/>
    <path d="M0,0 Q15,-12 18,-28 Q10,-18 0,-5Z" fill="white"/>
  </g>
''' + svg_footer()


def gen_berry_picking(w: int, h: int) -> str:
    """Blackberry brambles heavy with fruit."""
    return svg_header(w, h, WALLPAPERS[17][1]) + f'''  <defs>
    <linearGradient id="berryBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="{CREAM}"/>
      <stop offset="100%" stop-color="{SAGE}"/>
    </linearGradient>
    <radialGradient id="berry" cx="35%" cy="35%" r="60%">
      <stop offset="0%" stop-color="#5A2040"/>
      <stop offset="100%" stop-color="#2A1020"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#berryBg)"/>
  <!-- Bramble branches -->
  <g stroke="#5A4030" stroke-width="4" fill="none">
    <path d="M0,{h*0.3} Q{w*0.3},{h*0.25} {w*0.5},{h*0.35} Q{w*0.7},{h*0.45} {w},{h*0.38}"/>
    <path d="M0,{h*0.55} Q{w*0.2},{h*0.5} {w*0.4},{h*0.6} Q{w*0.6},{h*0.7} {w*0.8},{h*0.58} Q{w*0.9},{h*0.52} {w},{h*0.6}"/>
    <path d="M{w*0.1},{h*0.8} Q{w*0.3},{h*0.75} {w*0.5},{h*0.82} Q{w*0.7},{h*0.9} {w*0.9},{h*0.78}"/>
  </g>
  <!-- Thorns -->
  <g stroke="#5A4030" stroke-width="1.5" opacity="0.5">
    <line x1="{w*0.2}" y1="{h*0.27}" x2="{w*0.21}" y2="{h*0.24}"/>
    <line x1="{w*0.4}" y1="{h*0.3}" x2="{w*0.41}" y2="{h*0.27}"/>
    <line x1="{w*0.6}" y1="{h*0.4}" x2="{w*0.61}" y2="{h*0.37}"/>
    <line x1="{w*0.3}" y1="{h*0.52}" x2="{w*0.31}" y2="{h*0.49}"/>
    <line x1="{w*0.5}" y1="{h*0.62}" x2="{w*0.51}" y2="{h*0.59}"/>
    <line x1="{w*0.7}" y1="{h*0.6}" x2="{w*0.71}" y2="{h*0.57}"/>
  </g>
  <!-- Leaves -->
  <g fill="#5A7E3E" opacity="0.8">
    <path d="M{w*0.15},{h*0.28} Q{w*0.12},{h*0.22} {w*0.18},{h*0.20} Q{w*0.22},{h*0.24} {w*0.15},{h*0.28}Z"/>
    <path d="M{w*0.35},{h*0.32} Q{w*0.32},{h*0.26} {w*0.38},{h*0.25} Q{w*0.40},{h*0.28} {w*0.35},{h*0.32}Z"/>
    <path d="M{w*0.55},{h*0.38} Q{w*0.52},{h*0.32} {w*0.58},{h*0.30} Q{w*0.60},{h*0.34} {w*0.55},{h*0.38}Z"/>
    <path d="M{w*0.75},{h*0.42} Q{w*0.72},{h*0.36} {w*0.78},{h*0.35} Q{w*0.80},{h*0.38} {w*0.75},{h*0.42}Z"/>
    <path d="M{w*0.25},{h*0.55} Q{w*0.22},{h*0.49} {w*0.28},{h*0.48} Q{w*0.30},{h*0.52} {w*0.25},{h*0.55}Z"/>
    <path d="M{w*0.45},{h*0.63} Q{w*0.42},{h*0.57} {w*0.48},{h*0.55} Q{w*0.50},{h*0.59} {w*0.45},{h*0.63}Z"/>
    <path d="M{w*0.65},{h*0.62} Q{w*0.62},{h*0.56} {w*0.68},{h*0.55} Q{w*0.70},{h*0.58} {w*0.65},{h*0.62}Z"/>
  </g>
  <!-- Blackberry clusters -->
  <g>
    <!-- Cluster 1 -->
    <g transform="translate({w*0.3},{h*0.3})">
      <circle cx="0" cy="0" r="7" fill="url(#berry)"/><circle cx="0" cy="0" r="7" fill="white" opacity="0.1"/>
      <circle cx="10" cy="3" r="7" fill="url(#berry)"/>
      <circle cx="5" cy="-8" r="6" fill="url(#berry)"/>
      <circle cx="-5" cy="8" r="5" fill="#8B3050"/>
    </g>
    <!-- Cluster 2 -->
    <g transform="translate({w*0.6},{h*0.4})">
      <circle cx="0" cy="0" r="8" fill="url(#berry)"/><circle cx="0" cy="0" r="8" fill="white" opacity="0.1"/>
      <circle cx="12" cy="2" r="7" fill="url(#berry)"/>
      <circle cx="6" cy="-10" r="7" fill="url(#berry)"/>
      <circle cx="-4" cy="10" r="6" fill="url(#berry)"/>
      <circle cx="15" cy="-6" r="5" fill="#8B3050"/>
    </g>
    <!-- Cluster 3 -->
    <g transform="translate({w*0.4},{h*0.6})">
      <circle cx="0" cy="0" r="7" fill="url(#berry)"/>
      <circle cx="10" cy="4" r="7" fill="url(#berry)"/>
      <circle cx="5" cy="-9" r="6" fill="url(#berry)"/>
    </g>
    <!-- Cluster 4 (red - not ripe yet) -->
    <g transform="translate({w*0.8},{h*0.55})">
      <circle cx="0" cy="0" r="6" fill="#C45A4A"/><circle cx="0" cy="0" r="6" fill="white" opacity="0.1"/>
      <circle cx="8" cy="3" r="6" fill="#C45A4A"/>
      <circle cx="4" cy="-7" r="5" fill="#D47A6A"/>
    </g>
    <!-- Cluster 5 -->
    <g transform="translate({w*0.5},{h*0.82})">
      <circle cx="0" cy="0" r="8" fill="url(#berry)"/><circle cx="0" cy="0" r="8" fill="white" opacity="0.1"/>
      <circle cx="12" cy="3" r="8" fill="url(#berry)"/>
      <circle cx="6" cy="-10" r="7" fill="url(#berry)"/>
      <circle cx="-6" cy="8" r="6" fill="url(#berry)"/>
    </g>
  </g>
''' + svg_footer()


def gen_morning_dew(w: int, h: int) -> str:
    """Close-up dewdrops on petals and leaves."""
    return svg_header(w, h, WALLPAPERS[18][1]) + f'''  <defs>
    <linearGradient id="leafBg" x1="0" y1="0" x2="0.3" y2="1">
      <stop offset="0%" stop-color="#6B8E4E"/>
      <stop offset="100%" stop-color="#4A7A34"/>
    </linearGradient>
    <radialGradient id="dewDrop" cx="35%" cy="30%" r="60%">
      <stop offset="0%" stop-color="white" stop-opacity="0.6"/>
      <stop offset="40%" stop-color="white" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="white" stop-opacity="0.05"/>
    </radialGradient>
    <radialGradient id="dewHighlight" cx="30%" cy="25%" r="30%">
      <stop offset="0%" stop-color="white" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="white" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <!-- Large leaf background -->
  <rect width="{w}" height="{h}" fill="url(#leafBg)"/>
  <!-- Leaf veins -->
  <g stroke="#5A7E3E" stroke-width="3" fill="none" opacity="0.4">
    <path d="M{w*0.1},{h*0.1} Q{w*0.3},{h*0.3} {w*0.5},{h*0.5} Q{w*0.7},{h*0.7} {w*0.9},{h*0.9}"/>
    <path d="M{w*0.5},{h*0.5} Q{w*0.3},{h*0.55} {w*0.1},{h*0.52}"/>
    <path d="M{w*0.5},{h*0.5} Q{w*0.7},{h*0.45} {w*0.9},{h*0.48}"/>
    <path d="M{w*0.3},{h*0.3} Q{w*0.15},{h*0.35} {w*0.05},{h*0.32}"/>
    <path d="M{w*0.3},{h*0.3} Q{w*0.45},{h*0.25} {w*0.55},{h*0.28}"/>
    <path d="M{w*0.7},{h*0.7} Q{w*0.55},{h*0.75} {w*0.45},{h*0.72}"/>
    <path d="M{w*0.7},{h*0.7} Q{w*0.85},{h*0.65} {w*0.95},{h*0.68}"/>
  </g>
  <!-- Dewdrops — various sizes -->
  <g>
    <!-- Large drop 1 -->
    <ellipse cx="{w*0.35}" cy="{h*0.25}" rx="25" ry="22" fill="url(#dewDrop)"/>
    <ellipse cx="{w*0.33}" cy="{h*0.23}" rx="8" ry="6" fill="url(#dewHighlight)"/>
    <!-- Large drop 2 -->
    <ellipse cx="{w*0.65}" cy="{h*0.55}" rx="30" ry="26" fill="url(#dewDrop)"/>
    <ellipse cx="{w*0.63}" cy="{h*0.53}" rx="10" ry="7" fill="url(#dewHighlight)"/>
    <!-- Large drop 3 -->
    <ellipse cx="{w*0.25}" cy="{h*0.7}" rx="22" ry="20" fill="url(#dewDrop)"/>
    <ellipse cx="{w*0.23}" cy="{h*0.68}" rx="7" ry="5" fill="url(#dewHighlight)"/>
    <!-- Medium drops -->
    <ellipse cx="{w*0.55}" cy="{h*0.15}" rx="15" ry="13" fill="url(#dewDrop)"/>
    <ellipse cx="{w*0.54}" cy="{h*0.14}" rx="5" ry="4" fill="url(#dewHighlight)"/>
    <ellipse cx="{w*0.8}" cy="{h*0.35}" rx="18" ry="16" fill="url(#dewDrop)"/>
    <ellipse cx="{w*0.79}" cy="{h*0.34}" rx="6" ry="4" fill="url(#dewHighlight)"/>
    <ellipse cx="{w*0.45}" cy="{h*0.8}" rx="16" ry="14" fill="url(#dewDrop)"/>
    <ellipse cx="{w*0.44}" cy="{h*0.79}" rx="5" ry="4" fill="url(#dewHighlight)"/>
    <ellipse cx="{w*0.15}" cy="{h*0.45}" rx="14" ry="12" fill="url(#dewDrop)"/>
    <ellipse cx="{w*0.14}" cy="{h*0.44}" rx="5" ry="3" fill="url(#dewHighlight)"/>
    <!-- Small drops -->
    <circle cx="{w*0.75}" cy="{h*0.2}" r="8" fill="url(#dewDrop)"/>
    <circle cx="{w*0.2}" cy="{h*0.55}" r="7" fill="url(#dewDrop)"/>
    <circle cx="{w*0.85}" cy="{h*0.65}" r="9" fill="url(#dewDrop)"/>
    <circle cx="{w*0.4}" cy="{h*0.4}" r="6" fill="url(#dewDrop)"/>
    <circle cx="{w*0.6}" cy="{h*0.85}" r="8" fill="url(#dewDrop)"/>
    <circle cx="{w*0.9}" cy="{h*0.8}" r="7" fill="url(#dewDrop)"/>
    <!-- Tiny drops -->
    <circle cx="{w*0.1}" cy="{h*0.2}" r="4" fill="url(#dewDrop)"/>
    <circle cx="{w*0.3}" cy="{h*0.5}" r="3" fill="url(#dewDrop)"/>
    <circle cx="{w*0.7}" cy="{h*0.75}" r="4" fill="url(#dewDrop)"/>
    <circle cx="{w*0.5}" cy="{h*0.35}" r="3.5" fill="url(#dewDrop)"/>
    <circle cx="{w*0.85}" cy="{h*0.5}" r="3" fill="url(#dewDrop)"/>
    <circle cx="{w*0.15}" cy="{h*0.85}" r="4" fill="url(#dewDrop)"/>
    <circle cx="{w*0.95}" cy="{h*0.15}" r="3" fill="url(#dewDrop)"/>
  </g>
''' + svg_footer()


def gen_cottage_door(w: int, h: int) -> str:
    """Arched wooden door with climbing roses."""
    return svg_header(w, h, WALLPAPERS[19][1]) + f'''  <defs>
    <linearGradient id="wallBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="{LINEN}"/>
      <stop offset="100%" stop-color="{CREAM}"/>
    </linearGradient>
    <linearGradient id="doorWood" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#6B5040"/>
      <stop offset="30%" stop-color="{WALNUT}"/>
      <stop offset="70%" stop-color="#7A6050"/>
      <stop offset="100%" stop-color="#6B5040"/>
    </linearGradient>
  </defs>
  <!-- Stone wall background -->
  <rect width="{w}" height="{h}" fill="url(#wallBg)"/>
  <!-- Stone texture -->
  <g stroke="{WHEAT}" stroke-width="1" fill="none" opacity="0.15">
    <rect x="{w*0.02}" y="{h*0.05}" width="{w*0.12}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.16}" y="{h*0.04}" width="{w*0.15}" height="{h*0.05}" rx="2"/>
    <rect x="{w*0.05}" y="{h*0.1}" width="{w*0.18}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.7}" y="{h*0.06}" width="{w*0.14}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.86}" y="{h*0.05}" width="{w*0.12}" height="{h*0.05}" rx="2"/>
    <rect x="{w*0.72}" y="{h*0.11}" width="{w*0.16}" height="{h*0.04}" rx="2"/>
  </g>
  <!-- Step / ground -->
  <rect x="0" y="{h*0.88}" width="{w}" height="{h*0.12}" fill="{WHEAT}" opacity="0.3"/>
  <rect x="{w*0.2}" y="{h*0.86}" width="{w*0.6}" height="{h*0.04}" fill="{WALNUT}" opacity="0.3" rx="2"/>
  <!-- Arched door -->
  <path d="M{w*0.25},{h*0.88} L{w*0.25},{h*0.3} Q{w*0.25},{h*0.12} {w*0.5},{h*0.12} Q{w*0.75},{h*0.12} {w*0.75},{h*0.3} L{w*0.75},{h*0.88}Z" fill="url(#doorWood)" stroke="#5A4030" stroke-width="3"/>
  <!-- Door planks -->
  <g stroke="#5A4030" stroke-width="1" opacity="0.3">
    <line x1="{w*0.35}" y1="{h*0.16}" x2="{w*0.35}" y2="{h*0.88}"/>
    <line x1="{w*0.5}" y1="{h*0.12}" x2="{w*0.5}" y2="{h*0.88}"/>
    <line x1="{w*0.65}" y1="{h*0.16}" x2="{w*0.65}" y2="{h*0.88}"/>
  </g>
  <!-- Door hardware -->
  <circle cx="{w*0.6}" cy="{h*0.55}" r="8" fill="#D4AF37" opacity="0.7" stroke="#A08030" stroke-width="2"/>
  <circle cx="{w*0.6}" cy="{h*0.55}" r="3" fill="#A08030"/>
  <!-- Door hinges -->
  <rect x="{w*0.25}" y="{h*0.3}" width="{w*0.04}" height="{h*0.015}" fill="#5A4030" rx="2"/>
  <rect x="{w*0.25}" y="{h*0.6}" width="{w*0.04}" height="{h*0.015}" fill="#5A4030" rx="2"/>
  <!-- Climbing roses around door -->
  <!-- Main vine -->
  <g stroke="#5A7E3E" stroke-width="3" fill="none">
    <path d="M{w*0.2},{h*0.88} Q{w*0.18},{h*0.6} {w*0.22},{h*0.35} Q{w*0.25},{h*0.2} {w*0.35},{h*0.13} Q{w*0.45},{h*0.08} {w*0.55},{h*0.08} Q{w*0.65},{h*0.08} {w*0.75},{h*0.13} Q{w*0.8},{h*0.2} {w*0.82},{h*0.35} Q{w*0.84},{h*0.55} {w*0.8},{h*0.88}"/>
  </g>
  <!-- Rose blooms -->
  <g>
    <circle cx="{w*0.2}" cy="{h*0.5}" r="18" fill="#E8A0BF" opacity="0.85"/>
    <circle cx="{w*0.2}" cy="{h*0.5}" r="6" fill="#D47A9A"/>
    <circle cx="{w*0.22}" cy="{h*0.3}" r="15" fill="#E8A0BF" opacity="0.85"/>
    <circle cx="{w*0.22}" cy="{h*0.3}" r="5" fill="#D47A9A"/>
    <circle cx="{w*0.35}" cy="{h*0.1}" r="16" fill="#F5D0E0" opacity="0.85"/>
    <circle cx="{w*0.35}" cy="{h*0.1}" r="5" fill="#D47A9A"/>
    <circle cx="{w*0.55}" cy="{h*0.06}" r="14" fill="#E8A0BF" opacity="0.85"/>
    <circle cx="{w*0.55}" cy="{h*0.06}" r="5" fill="#D47A9A"/>
    <circle cx="{w*0.75}" cy="{h*0.15}" r="16" fill="#F5D0E0" opacity="0.85"/>
    <circle cx="{w*0.75}" cy="{h*0.15}" r="5" fill="#D47A9A"/>
    <circle cx="{w*0.82}" cy="{h*0.4}" r="15" fill="#E8A0BF" opacity="0.85"/>
    <circle cx="{w*0.82}" cy="{h*0.4}" r="5" fill="#D47A9A"/>
    <circle cx="{w*0.8}" cy="{h*0.65}" r="17" fill="#F5D0E0" opacity="0.85"/>
    <circle cx="{w*0.8}" cy="{h*0.65}" r="6" fill="#D47A9A"/>
  </g>
  <!-- Rose leaves -->
  <g fill="{SAGE}" opacity="0.7">
    <ellipse cx="{w*0.17}" cy="{h*0.42}" rx="12" ry="6" transform="rotate(-30,{w*0.17},{h*0.42})"/>
    <ellipse cx="{w*0.25}" cy="{h*0.22}" rx="10" ry="5" transform="rotate(20,{w*0.25},{h*0.22})"/>
    <ellipse cx="{w*0.42}" cy="{h*0.08}" rx="11" ry="5" transform="rotate(-15,{w*0.42},{h*0.08})"/>
    <ellipse cx="{w*0.65}" cy="{h*0.07}" rx="10" ry="5" transform="rotate(15,{w*0.65},{h*0.07})"/>
    <ellipse cx="{w*0.78}" cy="{h*0.25}" rx="12" ry="5" transform="rotate(30,{w*0.78},{h*0.25})"/>
    <ellipse cx="{w*0.85}" cy="{h*0.52}" rx="11" ry="5" transform="rotate(-20,{w*0.85},{h*0.52})"/>
    <ellipse cx="{w*0.78}" cy="{h*0.75}" rx="12" ry="5" transform="rotate(25,{w*0.78},{h*0.75})"/>
  </g>
  <!-- Welcome mat -->
  <rect x="{w*0.35}" y="{h*0.87}" width="{w*0.3}" height="{h*0.02}" fill="{WALNUT}" opacity="0.3" rx="2"/>
''' + svg_footer()


def gen_starlit_garden(w: int, h: int) -> str:
    """Night garden with fireflies and moonflowers."""
    return svg_header(w, h, WALLPAPERS[20][1]) + f'''  <defs>
    <linearGradient id="nightSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#0A1628"/>
      <stop offset="40%" stop-color="#1A2A3E"/>
      <stop offset="100%" stop-color="#2E3D22"/>
    </linearGradient>
    <radialGradient id="moonLight" cx="70%" cy="15%" r="30%">
      <stop offset="0%" stop-color="{LINEN}" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="{LINEN}" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="firefly" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#FFE4A0" stop-opacity="0.8"/>
      <stop offset="50%" stop-color="#FFE4A0" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#FFE4A0" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="moonflower" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="white" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="{CREAM}" stop-opacity="0.6"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#nightSky)"/>
  <rect width="{w}" height="{h}" fill="url(#moonLight)"/>
  <!-- Stars -->
  <g fill="white">
    <circle cx="{w*0.1}" cy="{h*0.03}" r="1.5" opacity="0.7"/>
    <circle cx="{w*0.25}" cy="{h*0.06}" r="1" opacity="0.5"/>
    <circle cx="{w*0.4}" cy="{h*0.02}" r="2" opacity="0.8"/>
    <circle cx="{w*0.55}" cy="{h*0.07}" r="1" opacity="0.4"/>
    <circle cx="{w*0.7}" cy="{h*0.04}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.85}" cy="{h*0.08}" r="1" opacity="0.5"/>
    <circle cx="{w*0.95}" cy="{h*0.03}" r="1.5" opacity="0.7"/>
    <circle cx="{w*0.15}" cy="{h*0.12}" r="1" opacity="0.4"/>
    <circle cx="{w*0.35}" cy="{h*0.1}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.6}" cy="{h*0.13}" r="1" opacity="0.5"/>
    <circle cx="{w*0.8}" cy="{h*0.15}" r="2" opacity="0.7"/>
    <circle cx="{w*0.05}" cy="{h*0.18}" r="1" opacity="0.4"/>
    <circle cx="{w*0.45}" cy="{h*0.16}" r="1.5" opacity="0.5"/>
    <circle cx="{w*0.9}" cy="{h*0.2}" r="1" opacity="0.4"/>
  </g>
  <!-- Moon -->
  <circle cx="{w*0.75}" cy="{h*0.12}" r="{w*0.05}" fill="{LINEN}" opacity="0.85"/>
  <!-- Garden ground -->
  <rect x="0" y="{h*0.6}" width="{w}" height="{h*0.4}" fill="#1A2A18"/>
  <path d="M0,{h*0.6} Q{w*0.25},{h*0.57} {w*0.5},{h*0.6} Q{w*0.75},{h*0.63} {w},{h*0.58} L{w},{h} L0,{h}Z" fill="#1E2E1C"/>
  <!-- Garden plants (dark silhouettes with moonlit edges) -->
  <g opacity="0.6">
    <path d="M{w*0.05},{h*0.6} Q{w*0.08},{h*0.45} {w*0.15},{h*0.4} Q{w*0.12},{h*0.42} {w*0.1},{h*0.48} Q{w*0.18},{h*0.38} {w*0.22},{h*0.35} Q{w*0.15},{h*0.40} {w*0.12},{h*0.5}Z" fill="#1A2A18"/>
    <path d="M{w*0.85},{h*0.58} Q{w*0.88},{h*0.43} {w*0.92},{h*0.38} Q{w*0.89},{h*0.40} {w*0.87},{h*0.46} Q{w*0.94},{h*0.36} {w*0.97},{h*0.32} Q{w*0.92},{h*0.38} {w*0.90},{h*0.48}Z" fill="#1A2A18"/>
  </g>
  <!-- Moonflowers (white night-blooming flowers) -->
  <g>
    <g transform="translate({w*0.3},{h*0.5})">
      <line x1="0" y1="0" x2="0" y2="{h*0.12}" stroke="#2A4A28" stroke-width="2"/>
      <circle cx="0" cy="0" r="18" fill="url(#moonflower)"/>
      <circle cx="0" cy="0" r="6" fill="#FFE4A0" opacity="0.5"/>
    </g>
    <g transform="translate({w*0.5},{h*0.45})">
      <line x1="0" y1="0" x2="0" y2="{h*0.17}" stroke="#2A4A28" stroke-width="2"/>
      <circle cx="0" cy="0" r="22" fill="url(#moonflower)"/>
      <circle cx="0" cy="0" r="7" fill="#FFE4A0" opacity="0.5"/>
    </g>
    <g transform="translate({w*0.7},{h*0.48})">
      <line x1="0" y1="0" x2="0" y2="{h*0.14}" stroke="#2A4A28" stroke-width="2"/>
      <circle cx="0" cy="0" r="16" fill="url(#moonflower)"/>
      <circle cx="0" cy="0" r="5" fill="#FFE4A0" opacity="0.5"/>
    </g>
    <!-- Smaller buds -->
    <g transform="translate({w*0.2},{h*0.55})">
      <line x1="0" y1="0" x2="0" y2="{h*0.08}" stroke="#2A4A28" stroke-width="1.5"/>
      <ellipse cx="0" cy="-3" rx="6" ry="10" fill="#E0E8D0" opacity="0.6"/>
    </g>
    <g transform="translate({w*0.8},{h*0.53})">
      <line x1="0" y1="0" x2="0" y2="{h*0.1}" stroke="#2A4A28" stroke-width="1.5"/>
      <ellipse cx="0" cy="-3" rx="6" ry="10" fill="#E0E8D0" opacity="0.6"/>
    </g>
  </g>
  <!-- Fireflies -->
  <g>
    <circle cx="{w*0.2}" cy="{h*0.35}" r="12" fill="url(#firefly)"/><circle cx="{w*0.2}" cy="{h*0.35}" r="3" fill="#FFE4A0" opacity="0.9"/>
    <circle cx="{w*0.4}" cy="{h*0.3}" r="10" fill="url(#firefly)"/><circle cx="{w*0.4}" cy="{h*0.3}" r="2.5" fill="#FFE4A0" opacity="0.8"/>
    <circle cx="{w*0.6}" cy="{h*0.38}" r="11" fill="url(#firefly)"/><circle cx="{w*0.6}" cy="{h*0.38}" r="2.5" fill="#FFE4A0" opacity="0.8"/>
    <circle cx="{w*0.35}" cy="{h*0.42}" r="8" fill="url(#firefly)"/><circle cx="{w*0.35}" cy="{h*0.42}" r="2" fill="#FFE4A0" opacity="0.7"/>
    <circle cx="{w*0.75}" cy="{h*0.32}" r="9" fill="url(#firefly)"/><circle cx="{w*0.75}" cy="{h*0.32}" r="2" fill="#FFE4A0" opacity="0.7"/>
    <circle cx="{w*0.55}" cy="{h*0.25}" r="7" fill="url(#firefly)"/><circle cx="{w*0.55}" cy="{h*0.25}" r="1.5" fill="#FFE4A0" opacity="0.6"/>
    <circle cx="{w*0.15}" cy="{h*0.5}" r="8" fill="url(#firefly)"/><circle cx="{w*0.15}" cy="{h*0.5}" r="2" fill="#FFE4A0" opacity="0.6"/>
    <circle cx="{w*0.85}" cy="{h*0.45}" r="7" fill="url(#firefly)"/><circle cx="{w*0.85}" cy="{h*0.45}" r="1.5" fill="#FFE4A0" opacity="0.5"/>
    <circle cx="{w*0.45}" cy="{h*0.55}" r="6" fill="url(#firefly)"/><circle cx="{w*0.45}" cy="{h*0.55}" r="1.5" fill="#FFE4A0" opacity="0.5"/>
    <circle cx="{w*0.65}" cy="{h*0.52}" r="7" fill="url(#firefly)"/><circle cx="{w*0.65}" cy="{h*0.52}" r="1.5" fill="#FFE4A0" opacity="0.5"/>
  </g>
''' + svg_footer()


# Map number to generator function
GENERATORS = {
    6: gen_forest_floor,
    7: gen_cottage_window,
    8: gen_herb_garden,
    9: gen_autumn_harvest,
    10: gen_pressed_flowers,
    11: gen_honeybee_path,
    12: gen_rainy_window,
    13: gen_woven_basket,
    14: gen_sunset_meadow,
    15: gen_fairy_ring,
    16: gen_lavender_fields,
    17: gen_berry_picking,
    18: gen_morning_dew,
    19: gen_cottage_door,
    20: gen_starlit_garden,
}


def main() -> None:
    """Generate all remaining cottagecore wallpapers for phone and desktop."""
    PHONE_DIR.mkdir(parents=True, exist_ok=True)
    DESKTOP_DIR.mkdir(parents=True, exist_ok=True)

    for num, (slug, title) in WALLPAPERS.items():
        gen_func = GENERATORS[num]

        # Phone version (1080x2340)
        phone_svg = gen_func(1080, 2340)
        phone_path = PHONE_DIR / f"{num:02d}-{slug}.svg"
        phone_path.write_text(phone_svg)
        print(f"  Created: {phone_path.name}")

        # Desktop version (1920x1080)
        desktop_svg = gen_func(1920, 1080)
        desktop_path = DESKTOP_DIR / f"{num:02d}-{slug}.svg"
        desktop_path.write_text(desktop_svg)
        print(f"  Created: {desktop_path.name}")

    # Also create desktop versions of the first 5 (hand-crafted ones already have phone versions)
    for num in range(1, 6):
        slug = {
            1: "meadow-morning", 2: "mushroom-hollow", 3: "butterfly-garden",
            4: "vine-trellis", 5: "tea-and-roses"
        }[num]
        phone_path = PHONE_DIR / f"{num:02d}-{slug}.svg"
        if phone_path.exists():
            # Read phone SVG and change viewBox to desktop
            content = phone_path.read_text()
            desktop_content = content.replace('viewBox="0 0 1080 2340"', 'viewBox="0 0 1920 1080"')
            desktop_path = DESKTOP_DIR / f"{num:02d}-{slug}.svg"
            desktop_path.write_text(desktop_content)
            print(f"  Created desktop: {desktop_path.name}")

    print(f"\nDone! Generated {len(WALLPAPERS)} wallpaper pairs (phone + desktop)")
    total = len(WALLPAPERS) * 2 + 5  # 15 pairs + 5 desktop adaptations of hand-crafted
    print(f"Total files: {total}")


if __name__ == "__main__":
    main()
