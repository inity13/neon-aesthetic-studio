# Aesthetic Ultimate Bundle

**All 10 aesthetic products in one mega bundle — save 44%**

Every wallpaper, icon, sticker, texture, journal page, widget, color palette, and
mood board template from Aesthetic Studio. This is the complete aesthetic toolkit
for customizing your phone, journal, social media, and digital life.

## What's Included

| # | Product | Individual Price | Description |
|---|---------|-----------------|-------------|
| 1 | Cottagecore Wallpaper Pack | $3 | 20 SVG wallpapers (phone + desktop) |
| 2 | Anime Wallpaper Collection | $3 | 15 anime-inspired SVG wallpapers |
| 3 | Aesthetic Color Palettes | $1 | 10 curated palettes (60+ colors) |
| 4 | Dark Academia Icon Set | $3 | 30 scholarly SVG icons |
| 5 | Digital Sticker Mega Pack | $5 | 50+ kawaii stickers |
| 6 | Grunge Aesthetic Pack | $3 | 20 SVG textures and overlays |
| 7 | Mood Board Creator Kit | $5 | 3 interactive mood board templates |
| 8 | Neon Glow Icon Set | $3 | 30 neon-glow SVG icons |
| 9 | Pastel Dream Journal | $3 | 12 printable journal templates |
| 10 | Y2K Widget Theme | $3 | 15 retro-futuristic widget designs |

**Individual total: $32**
**Bundle price: $19** (save $13 / 41% off)

## How It Works

Each product is in its own folder with its own README, preview, demo, and source files.
Browse individual product READMEs for detailed instructions on each pack.

## License

MIT License — see individual product LICENSE files for full terms.
