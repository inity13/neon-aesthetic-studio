# Mood Board Creator Kit

**3 interactive mood board templates with drag-and-drop**

Build gorgeous mood boards right in your browser — no sign-ups, no apps, no
subscriptions. Includes Cottagecore, Dark Academia, and Y2K templates with
preset layouts, color palettes, and placeholder prompts. Just drag, drop, and vibe.

## What's Inside

| Template | Theme | Layout | Elements |
|----------|-------|--------|----------|
| Cottagecore | Warm earth tones, florals | 3x3 grid with header | 9 slots + title + palette |
| Dark Academia | Rich browns, scholarly | Asymmetric collage | 7 slots + quote + palette |
| Y2K | Bright pinks, metallics | Scattered polaroid style | 8 slots + stickers + palette |

## File Structure

```
src/
├── mood_board.html         # Main mood board app (standalone HTML)
└── templates/
    ├── cottagecore.json     # Cottagecore template data
    ├── dark_academia.json   # Dark Academia template data
    └── y2k.json            # Y2K template data

demo/
└── index.html              # Quick-start demo with sample content

preview/
└── index.html              # Template previews with screenshots
```

## How to Use

1. **Launch the app**: Open `src/mood_board.html` in any modern browser
2. **Pick a template**: Choose Cottagecore, Dark Academia, or Y2K
3. **Add content**: Drag images from your desktop into the slots
4. **Customize**: Change colors, add text, rearrange elements
5. **Save**: Right-click the board and save as image, or screenshot it

## Features

- Fully offline — works without internet after download
- Drag-and-drop image upload
- Editable text fields
- Color palette display for each aesthetic
- No external dependencies — just one HTML file

## Tips

- Use this for Pinterest-style planning, journal spreads, or room decor planning
- Export by screenshotting or using browser print-to-PDF
- Edit the JSON templates to create your own custom layouts
- Works on tablets too — great for iPad mood boarding

## License

MIT License — use these templates for personal projects, school work, or content creation.
See LICENSE file for full terms.
