# Dark Academia Icon Set

**30 SVG icons in the dark academia aesthetic**

Leather-bound books, fountain pens, classical columns, candelabras, and scholarly
motifs — all rendered as crisp 120x120 SVG icons in rich browns, deep greens, and
antique golds. Perfect for phone customization, journal decoration, or app theming.

## What's Inside

| Category | Icons | Examples |
|----------|-------|----------|
| Books & Writing | 8 | Open book, closed book, stack, fountain pen, ink bottle, quill, journal, bookmark |
| Architecture | 6 | Column, archway, window, dome, staircase, door |
| Objects | 8 | Candelabra, globe, compass, hourglass, magnifying glass, key, clock, chess piece |
| Nature | 4 | Ivy vine, oak leaf, raven, moth |
| Symbols | 4 | Laurel wreath, constellation, crescent moon, skull |

## Color Palette

```
+-----------+-----------+-----------+-----------+-----------+-----------+
| Espresso  | Mahogany  | Parchment | Ivy       | Gold      | Charcoal  |
| #3C2415   | #6B3A2A   | #E8D5B7   | #4A6741   | #C5A55A   | #2C2C2C   |
+-----------+-----------+-----------+-----------+-----------+-----------+
```

## File Structure

```
src/
├── icon_data.json          # Icon metadata (names, categories, descriptions)
└── generate_icons.py       # Generate all 30 SVG icons

demo/
└── index.html              # Interactive icon browser with search

preview/
└── index.html              # Grid gallery of all icons

docs/
└── installation_guide.md   # How to use icons on iOS, Android, desktop
```

## How to Use

1. **Preview all**: Open `preview/index.html` in your browser
2. **Browse & search**: Open `demo/index.html` for an interactive browser
3. **Generate SVGs**: Run `python3 src/generate_icons.py` to create individual SVG files
4. **Install on phone**: See `docs/installation_guide.md` for step-by-step guides

## License

MIT License — use these icons on your devices, in your projects, or as inspiration.
See LICENSE file for full terms.
