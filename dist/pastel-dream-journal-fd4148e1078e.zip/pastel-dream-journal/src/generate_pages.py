#!/usr/bin/env python3
"""Pastel Dream Journal — SVG Page Generator

Reads templates.json and generates one SVG file per journal page template.
Uses only stdlib (xml.etree.ElementTree). Output goes to src/templates/*.svg.

Pastel palette:
  Background  #FFF5F9
  Header      #FFB5C5 (pastel pink)
  Lines       #C5B5FF (pastel lavender)
  Accent      #B5FFC5 (pastel mint)
  Text dark   #4A3F55
  Text muted  #8A7F99
  Border deco #FFDDE5
"""

import json
import math
import os
import xml.etree.ElementTree as ET

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_FILE = os.path.join(SCRIPT_DIR, "templates.json")
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "templates")

W, H = 800, 1100
NS = "http://www.w3.org/2000/svg"
COLORS = {
    "bg": "#FFF5F9",
    "header": "#FFB5C5",
    "lines": "#C5B5FF",
    "accent": "#B5FFC5",
    "text": "#4A3F55",
    "muted": "#8A7F99",
    "deco": "#FFDDE5",
    "white": "#FFFFFF",
}
MARGIN = 50


# ── SVG helpers ──────────────────────────────────────────────────────────

def _svg_root():
    svg = ET.Element("svg", xmlns=NS, width=str(W), height=str(H),
                     viewBox=f"0 0 {W} {H}")
    # background
    ET.SubElement(svg, "rect", width=str(W), height=str(H), fill=COLORS["bg"])
    return svg


def _add_deco_border(svg):
    """Subtle flower/star doodle border along page edges."""
    g = ET.SubElement(svg, "g", opacity="0.25")
    spacing = 60
    for i in range(int(W // spacing) + 1):
        x = i * spacing
        # top
        _tiny_flower(g, x, 18, 6)
        # bottom
        _tiny_star(g, x, H - 18, 5)
    for i in range(int(H // spacing) + 1):
        y = i * spacing
        # left
        _tiny_star(g, 18, y, 5)
        # right
        _tiny_flower(g, W - 18, y, 6)


def _tiny_flower(parent, cx, cy, r):
    """Five-petal flower using circles."""
    for a in range(5):
        angle = math.radians(a * 72 - 90)
        px = cx + r * math.cos(angle)
        py = cy + r * math.sin(angle)
        ET.SubElement(parent, "circle", cx=f"{px:.1f}", cy=f"{py:.1f}",
                      r=str(r * 0.5), fill=COLORS["header"])
    ET.SubElement(parent, "circle", cx=str(cx), cy=str(cy),
                  r=str(r * 0.35), fill=COLORS["accent"])


def _tiny_star(parent, cx, cy, r):
    pts = []
    for i in range(10):
        a = math.radians(i * 36 - 90)
        cr = r if i % 2 == 0 else r * 0.45
        pts.append(f"{cx + cr * math.cos(a):.1f},{cy + cr * math.sin(a):.1f}")
    ET.SubElement(parent, "polygon", points=" ".join(pts), fill=COLORS["lines"])


def _text(parent, x, y, content, size=16, fill=None, weight="normal", anchor="start"):
    t = ET.SubElement(parent, "text", x=str(x), y=str(y))
    t.set("font-family", "'Segoe UI', system-ui, sans-serif")
    t.set("font-size", str(size))
    t.set("fill", fill or COLORS["text"])
    t.set("font-weight", weight)
    t.set("text-anchor", anchor)
    t.text = content


def _line(parent, x1, y1, x2, y2, color=None, width="1", dash=None):
    attrs = dict(x1=str(x1), y1=str(y1), x2=str(x2), y2=str(y2),
                 stroke=color or COLORS["lines"])
    attrs["stroke-width"] = width
    if dash:
        attrs["stroke-dasharray"] = dash
    ET.SubElement(parent, "line", **attrs)


def _rect(parent, x, y, w, h, fill="none", stroke=None, rx="8"):
    attrs = dict(x=str(x), y=str(y), width=str(w), height=str(h),
                 fill=fill, rx=rx)
    if stroke:
        attrs["stroke"] = stroke
        attrs["stroke-width"] = "1.5"
    ET.SubElement(parent, "rect", **attrs)


def _checkbox(parent, x, y, size=16):
    _rect(parent, x, y, size, size, fill=COLORS["white"],
          stroke=COLORS["lines"], rx="3")


# ── Section renderers ────────────────────────────────────────────────────

def _render_header(svg, sec):
    y = sec["y_start"]
    # pink header band
    _rect(svg, MARGIN, y, W - 2 * MARGIN, sec["height"],
          fill=COLORS["header"], rx="12")
    _text(svg, W // 2, y + sec["height"] * 0.65, sec["label"],
          size=26, fill=COLORS["white"], weight="bold", anchor="middle")


def _render_date_field(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 20, sec["label"], size=14, fill=COLORS["muted"])
    _line(svg, MARGIN + 80, y + 22, W - MARGIN, y + 22)


def _render_month_field(svg, sec):
    _render_date_field(svg, sec)


def _render_week_field(svg, sec):
    _render_date_field(svg, sec)


def _render_lines(svg, sec):
    y = sec["y_start"]
    if sec.get("label"):
        _text(svg, MARGIN, y + 16, sec["label"], size=14, fill=COLORS["header"],
              weight="bold")
        y += 28
    count = sec.get("line_count", 6)
    gap = (sec["height"] - 28) / max(count, 1)
    for i in range(count):
        ly = y + (i + 1) * gap
        _line(svg, MARGIN, ly, W - MARGIN, ly)


def _render_todo_list(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["header"],
          weight="bold")
    items = sec.get("items", 6)
    gap = (sec["height"] - 30) / max(items, 1)
    for i in range(items):
        iy = y + 32 + i * gap
        _checkbox(svg, MARGIN, iy)
        _line(svg, MARGIN + 26, iy + 14, W - MARGIN, iy + 14)


def _render_time_slots(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["header"],
          weight="bold")
    slots = sec.get("slots", [])
    gap = (sec["height"] - 30) / max(len(slots), 1)
    for i, slot in enumerate(slots):
        sy = y + 32 + i * gap
        _text(svg, MARGIN, sy + 14, slot, size=11, fill=COLORS["muted"])
        _line(svg, MARGIN + 70, sy + 16, W - MARGIN, sy + 16)


def _render_prompt(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=16, fill=COLORS["header"],
          weight="bold")
    prompts = sec.get("prompts", [])
    gap = (sec["height"] - 30) / max(len(prompts), 1)
    for i, p in enumerate(prompts):
        py_ = y + 38 + i * gap
        _text(svg, MARGIN + 10, py_, p, size=13, fill=COLORS["muted"])
        _line(svg, MARGIN + 10, py_ + 20, W - MARGIN, py_ + 20)


def _render_text_area(svg, sec):
    y = sec["y_start"]
    if sec.get("label"):
        _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["header"],
              weight="bold")
    count = sec.get("line_count", 4)
    start = y + 32
    gap = (sec["height"] - 32) / max(count, 1)
    for i in range(count):
        _line(svg, MARGIN, start + (i + 1) * gap, W - MARGIN, start + (i + 1) * gap)


def _render_text_field(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["header"],
          weight="bold")
    count = sec.get("line_count", 1)
    gap = 28
    for i in range(count):
        _line(svg, MARGIN + 120, y + 20 + i * gap, W - MARGIN, y + 20 + i * gap)


def _render_doodle_area(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["muted"])
    _rect(svg, MARGIN, y + 28, W - 2 * MARGIN, sec["height"] - 36,
          fill="none", stroke=COLORS["deco"], rx="12")


def _render_blank_area(svg, sec):
    _rect(svg, MARGIN, sec["y_start"], W - 2 * MARGIN, sec["height"],
          fill="none", stroke=COLORS["deco"], rx="12")


def _render_habit_grid(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["header"],
          weight="bold")
    habits = sec.get("habits", 8)
    days = sec.get("days", 30)
    cell = sec.get("cell_size", 20)
    grid_x = MARGIN + 140
    grid_y = y + 40

    # Day numbers header
    for d in range(days):
        _text(svg, grid_x + d * cell + cell // 2, grid_y - 4,
              str(d + 1), size=9, fill=COLORS["muted"], anchor="middle")

    # Rows
    for h in range(habits):
        ry = grid_y + h * (cell + 6) * 3
        # Habit label line
        _line(svg, MARGIN, ry + cell + 4, MARGIN + 130, ry + cell + 4,
              color=COLORS["lines"])
        # Checkboxes
        for d in range(days):
            _checkbox(svg, grid_x + d * cell, ry, cell - 2)


def _render_mood_legend(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 16, sec["label"], size=14, fill=COLORS["header"],
          weight="bold")
    levels = sec.get("levels", [])
    bw = 80
    for i, lev in enumerate(levels):
        lx = MARGIN + i * (bw + 10)
        ET.SubElement(svg, "circle", cx=str(lx + 10), cy=str(y + 42),
                      r="8", fill=lev["color"])
        _text(svg, lx + 24, y + 46, lev["label"], size=11, fill=COLORS["muted"])


def _render_mood_grid(svg, sec):
    y = sec["y_start"]
    days = sec.get("days", 31)
    eh = sec.get("entry_height", 20)
    for d in range(days):
        dy = y + d * eh
        _text(svg, MARGIN, dy + 15, f"Day {d + 1}", size=11, fill=COLORS["muted"])
        _line(svg, MARGIN + 55, dy + 16, W - MARGIN, dy + 16)


def _render_day_grid(svg, sec):
    y = sec["y_start"]
    days = sec.get("days", [])
    dh = sec.get("day_height", 100)
    for i, day in enumerate(days):
        dy = y + i * dh
        _rect(svg, MARGIN, dy, W - 2 * MARGIN, dh - 4,
              fill=COLORS["white"], stroke=COLORS["lines"], rx="6")
        _text(svg, MARGIN + 10, dy + 20, day, size=13, fill=COLORS["header"],
              weight="bold")
        # lines inside
        for li in range(2):
            _line(svg, MARGIN + 10, dy + 40 + li * 22, W - MARGIN - 10, dy + 40 + li * 22,
                  color=COLORS["deco"])


def _render_priority_list(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["header"],
          weight="bold")
    items = sec.get("items", 5)
    gap = (sec["height"] - 30) / max(items, 1)
    for i in range(items):
        iy = y + 34 + i * gap
        ET.SubElement(svg, "circle", cx=str(MARGIN + 8), cy=str(iy),
                      r="5", fill=COLORS["accent"])
        _line(svg, MARGIN + 22, iy + 4, W - MARGIN, iy + 4)


def _render_numbered_list(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["header"],
          weight="bold")
    items = sec.get("items", 8)
    gap = (sec["height"] - 30) / max(items, 1)
    for i in range(items):
        iy = y + 38 + i * gap
        _text(svg, MARGIN, iy, f"{i + 1}.", size=13, fill=COLORS["muted"])
        _line(svg, MARGIN + 22, iy + 4, W - MARGIN, iy + 4)


def _render_table(svg, sec):
    y = sec["y_start"]
    cols = sec.get("columns", [])
    rows = sec.get("rows", 10)
    rh = sec.get("row_height", 36)

    # header row
    cx = MARGIN
    for col in cols:
        _text(svg, cx + 6, y + 22, col["label"], size=12, fill=COLORS["header"],
              weight="bold")
        cx += col["width"]
    _line(svg, MARGIN, y + 30, W - MARGIN, y + 30, color=COLORS["header"], width="2")

    # data rows
    for r in range(rows):
        ry = y + 34 + r * rh
        _line(svg, MARGIN, ry + rh - 4, W - MARGIN, ry + rh - 4, color=COLORS["deco"])
        # column dividers
        cx = MARGIN
        for col in cols:
            cx += col["width"]
            if cx < W - MARGIN:
                _line(svg, cx, ry, cx, ry + rh - 4, color=COLORS["deco"])


def _render_checklist_group(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=15, fill=COLORS["header"],
          weight="bold")
    items = sec.get("items", [])
    gap = (sec["height"] - 30) / max(len(items), 1)
    for i, item in enumerate(items):
        iy = y + 36 + i * gap
        _checkbox(svg, MARGIN + 10, iy)
        _text(svg, MARGIN + 34, iy + 13, item, size=13, fill=COLORS["text"])


def _render_inline_field(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["muted"])
    _line(svg, MARGIN + 120, y + 20, W - MARGIN, y + 20)


def _render_tag_area(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 18, sec["label"], size=14, fill=COLORS["header"],
          weight="bold")
    prompts = sec.get("tag_prompts", [])
    gap = 26
    for i, p in enumerate(prompts):
        py_ = y + 38 + i * gap
        _text(svg, MARGIN + 10, py_, p, size=12, fill=COLORS["muted"])
        _line(svg, MARGIN + 80, py_ + 4, W - MARGIN, py_ + 4)


def _render_salutation(svg, sec):
    y = sec["y_start"]
    _text(svg, MARGIN, y + 20, sec["label"], size=16, fill=COLORS["text"],
          weight="bold")


def _render_closing(svg, sec):
    y = sec["y_start"]
    _text(svg, W - MARGIN - 200, y + 20, sec["label"], size=15,
          fill=COLORS["text"])


def _render_seal(svg, sec):
    """Decorative wax-seal-style circle."""
    cx, cy = W // 2, sec["y_start"] + sec["height"] // 2
    r = 30
    # outer scallop
    for a in range(24):
        angle = math.radians(a * 15)
        px = cx + (r + 6) * math.cos(angle)
        py = cy + (r + 6) * math.sin(angle)
        ET.SubElement(svg, "circle", cx=f"{px:.1f}", cy=f"{py:.1f}",
                      r="5", fill=COLORS["header"], opacity="0.5")
    ET.SubElement(svg, "circle", cx=str(cx), cy=str(cy), r=str(r),
                  fill=COLORS["header"])
    _text(svg, cx, cy + 5, "\u2661", size=24, fill=COLORS["white"], anchor="middle")


def _render_notes_line(svg, sec):
    _render_text_area(svg, sec)


# renderer dispatch
RENDERERS = {
    "header": _render_header,
    "date_field": _render_date_field,
    "month_field": _render_month_field,
    "week_field": _render_week_field,
    "lines": _render_lines,
    "todo_list": _render_todo_list,
    "time_slots": _render_time_slots,
    "prompt": _render_prompt,
    "text_area": _render_text_area,
    "text_field": _render_text_field,
    "doodle_area": _render_doodle_area,
    "blank_area": _render_blank_area,
    "habit_grid": _render_habit_grid,
    "mood_legend": _render_mood_legend,
    "mood_grid": _render_mood_grid,
    "day_grid": _render_day_grid,
    "priority_list": _render_priority_list,
    "numbered_list": _render_numbered_list,
    "table": _render_table,
    "checklist_group": _render_checklist_group,
    "inline_field": _render_inline_field,
    "tag_area": _render_tag_area,
    "salutation": _render_salutation,
    "closing": _render_closing,
    "seal": _render_seal,
    "notes_line": _render_notes_line,
}


# ── Main ─────────────────────────────────────────────────────────────────

def generate_page(template):
    svg = _svg_root()
    _add_deco_border(svg)
    for sec in template["sections"]:
        renderer = RENDERERS.get(sec["type"])
        if renderer:
            renderer(svg, sec)
    return svg


def main():
    with open(TEMPLATE_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    for tmpl in data["templates"]:
        svg = generate_page(tmpl)
        out_path = os.path.join(OUTPUT_DIR, f"{tmpl['id']}.svg")
        tree = ET.ElementTree(svg)
        ET.indent(tree, space="  ")
        tree.write(out_path, xml_declaration=True, encoding="utf-8")
        print(f"  \u2713 {tmpl['id']}.svg")

    print(f"\nGenerated {len(data['templates'])} journal pages in {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
