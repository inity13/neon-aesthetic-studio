#!/usr/bin/env python3
"""
Anime Wallpaper Collection Generator
Generates 15 anime-inspired SVG wallpapers for phone and desktop.
Uses Python stdlib only — no external dependencies.

Each wallpaper is a unique, carefully composed SVG scene with:
- Gradients, shapes, and layering for depth
- Anime color palette (#FFB7C5, #87CEEB, #FF7E5F, #6B5B95, #88C9A1, #E8E0F0)
- Proper viewBox for phone (1080x1920) and desktop (1920x1080)
- Original scenes only — no copyrighted characters
"""

import os
from pathlib import Path

BASE = Path(__file__).parent
PHONE_DIR = BASE / "src" / "phone"
DESKTOP_DIR = BASE / "src" / "desktop"

# Anime-inspired palette
SAKURA = "#FFB7C5"
SKY_BLUE = "#87CEEB"
SUNSET = "#FF7E5F"
TWILIGHT = "#6B5B95"
MATCHA = "#88C9A1"
CLOUD = "#E8E0F0"

WALLPAPERS: dict[int, tuple[str, str]] = {
    1: ("cherry-blossom-path", "Cherry Blossom Path: Petals drifting over a stone path at sunset"),
    2: ("neon-alley", "Neon Alley: Rain-soaked alley with glowing shop signs"),
    3: ("cloud-ocean", "Cloud Ocean: Endless clouds lit by golden hour sun"),
    4: ("shrine-steps", "Shrine Steps: Torii gate at the top of mossy stone steps"),
    5: ("rooftop-sunset", "Rooftop Sunset: City skyline from a school rooftop at dusk"),
    6: ("starfall-lake", "Starfall Lake: Shooting stars reflected in still water"),
    7: ("bamboo-forest", "Bamboo Forest: Shafts of light through tall bamboo"),
    8: ("train-window", "Train Window: Countryside blurring past a rainy window"),
    9: ("lantern-festival", "Lantern Festival: Paper lanterns floating into night sky"),
    10: ("moon-bridge", "Moon Bridge: Arched bridge under an enormous full moon"),
    11: ("flower-field", "Flower Field: Endless wildflowers under pastel sky"),
    12: ("rainy-crosswalk", "Rainy Crosswalk: Neon reflections on a wet city crossing"),
    13: ("island-cove", "Island Cove: Turquoise water lapping at a rocky shore"),
    14: ("snow-village", "Snow Village: Warm windows glowing through falling snow"),
    15: ("galaxy-hilltop", "Galaxy Hilltop: Milky Way arching over a grassy hill"),
}


def svg_header(w: int, h: int, title: str) -> str:
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}">\n  <!-- {title} -->\n'


def svg_footer() -> str:
    return "</svg>\n"


# ---------------------------------------------------------------------------
# Scene generators — each returns a complete SVG string for a given w x h
# ---------------------------------------------------------------------------

def gen_cherry_blossom_path(w: int, h: int) -> str:
    """Petals drifting over a stone path at sunset."""
    return svg_header(w, h, WALLPAPERS[1][1]) + f'''  <defs>
    <linearGradient id="sunsetSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#FF9A76"/>
      <stop offset="40%" stop-color="{SAKURA}"/>
      <stop offset="100%" stop-color="{CLOUD}"/>
    </linearGradient>
    <radialGradient id="sunGlow" cx="50%" cy="30%" r="35%">
      <stop offset="0%" stop-color="#FFE4B5" stop-opacity="0.8"/>
      <stop offset="100%" stop-color="#FFE4B5" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#sunsetSky)"/>
  <circle cx="{w*0.5}" cy="{h*0.25}" r="{w*0.25}" fill="url(#sunGlow)"/>
  <!-- Distant hills -->
  <ellipse cx="{w*0.3}" cy="{h*0.5}" rx="{w*0.4}" ry="{h*0.06}" fill="#C4A4D4" opacity="0.4"/>
  <ellipse cx="{w*0.7}" cy="{h*0.52}" rx="{w*0.35}" ry="{h*0.05}" fill="#B494C4" opacity="0.3"/>
  <!-- Ground / path area -->
  <rect x="0" y="{h*0.55}" width="{w}" height="{h*0.45}" fill="{MATCHA}"/>
  <!-- Stone path -->
  <path d="M{w*0.35},{h} L{w*0.42},{h*0.55} L{w*0.58},{h*0.55} L{w*0.65},{h}Z" fill="#D4C4B0" opacity="0.7"/>
  <g fill="#C8B8A4" opacity="0.4">
    <ellipse cx="{w*0.48}" cy="{h*0.6}" rx="{w*0.04}" ry="{h*0.008}"/>
    <ellipse cx="{w*0.52}" cy="{h*0.65}" rx="{w*0.05}" ry="{h*0.009}"/>
    <ellipse cx="{w*0.47}" cy="{h*0.72}" rx="{w*0.05}" ry="{h*0.01}"/>
    <ellipse cx="{w*0.53}" cy="{h*0.8}" rx="{w*0.06}" ry="{h*0.011}"/>
    <ellipse cx="{w*0.49}" cy="{h*0.88}" rx="{w*0.07}" ry="{h*0.012}"/>
  </g>
  <!-- Cherry blossom trees (left) -->
  <g>
    <rect x="{w*0.12}" y="{h*0.35}" width="{w*0.02}" height="{h*0.25}" fill="#6B4E3D" rx="3"/>
    <circle cx="{w*0.13}" cy="{h*0.3}" r="{w*0.1}" fill="{SAKURA}" opacity="0.6"/>
    <circle cx="{w*0.08}" cy="{h*0.28}" r="{w*0.07}" fill="#FFD0DC" opacity="0.5"/>
    <circle cx="{w*0.18}" cy="{h*0.32}" r="{w*0.06}" fill="{SAKURA}" opacity="0.4"/>
  </g>
  <!-- Cherry blossom trees (right) -->
  <g>
    <rect x="{w*0.82}" y="{h*0.38}" width="{w*0.02}" height="{h*0.22}" fill="#6B4E3D" rx="3"/>
    <circle cx="{w*0.83}" cy="{h*0.32}" r="{w*0.09}" fill="{SAKURA}" opacity="0.55"/>
    <circle cx="{w*0.88}" cy="{h*0.3}" r="{w*0.06}" fill="#FFD0DC" opacity="0.45"/>
    <circle cx="{w*0.78}" cy="{h*0.34}" r="{w*0.05}" fill="{SAKURA}" opacity="0.35"/>
  </g>
  <!-- Falling petals -->
  <g fill="{SAKURA}" opacity="0.7">
    <ellipse cx="{w*0.25}" cy="{h*0.2}" rx="5" ry="3" transform="rotate(30,{w*0.25},{h*0.2})"/>
    <ellipse cx="{w*0.4}" cy="{h*0.15}" rx="4" ry="2.5" transform="rotate(-20,{w*0.4},{h*0.15})"/>
    <ellipse cx="{w*0.6}" cy="{h*0.22}" rx="5" ry="3" transform="rotate(45,{w*0.6},{h*0.22})"/>
    <ellipse cx="{w*0.75}" cy="{h*0.18}" rx="4" ry="2" transform="rotate(-35,{w*0.75},{h*0.18})"/>
    <ellipse cx="{w*0.3}" cy="{h*0.35}" rx="5" ry="3" transform="rotate(60,{w*0.3},{h*0.35})"/>
    <ellipse cx="{w*0.55}" cy="{h*0.4}" rx="4" ry="2.5" transform="rotate(-40,{w*0.55},{h*0.4})"/>
    <ellipse cx="{w*0.7}" cy="{h*0.38}" rx="6" ry="3" transform="rotate(25,{w*0.7},{h*0.38})"/>
    <ellipse cx="{w*0.2}" cy="{h*0.48}" rx="5" ry="2.5" transform="rotate(-55,{w*0.2},{h*0.48})"/>
    <ellipse cx="{w*0.85}" cy="{h*0.42}" rx="4" ry="2" transform="rotate(50,{w*0.85},{h*0.42})"/>
    <ellipse cx="{w*0.45}" cy="{h*0.5}" rx="5" ry="3" transform="rotate(-15,{w*0.45},{h*0.5})"/>
  </g>
  <!-- Petal shadows on path -->
  <g fill="#D4A0B0" opacity="0.3">
    <ellipse cx="{w*0.48}" cy="{h*0.68}" rx="4" ry="2" transform="rotate(20)"/>
    <ellipse cx="{w*0.52}" cy="{h*0.75}" rx="3" ry="1.5" transform="rotate(-30)"/>
    <ellipse cx="{w*0.5}" cy="{h*0.82}" rx="4" ry="2" transform="rotate(40)"/>
  </g>
''' + svg_footer()


def gen_neon_alley(w: int, h: int) -> str:
    """Rain-soaked alley with glowing neon shop signs."""
    return svg_header(w, h, WALLPAPERS[2][1]) + f'''  <defs>
    <linearGradient id="nightBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#0A0A1A"/>
      <stop offset="100%" stop-color="#1A1A2E"/>
    </linearGradient>
    <filter id="glow">
      <feGaussianBlur stdDeviation="4" result="blur"/>
      <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#nightBg)"/>
  <!-- Buildings (left wall) -->
  <rect x="0" y="0" width="{w*0.3}" height="{h}" fill="#12121E"/>
  <!-- Buildings (right wall) -->
  <rect x="{w*0.7}" y="0" width="{w*0.3}" height="{h}" fill="#10101C"/>
  <!-- Alley floor (wet) -->
  <rect x="{w*0.3}" y="{h*0.6}" width="{w*0.4}" height="{h*0.4}" fill="#15152A"/>
  <!-- Neon sign 1 (pink) -->
  <g filter="url(#glow)">
    <rect x="{w*0.05}" y="{h*0.15}" width="{w*0.2}" height="{h*0.06}" rx="4" fill="none" stroke="#FF1493" stroke-width="2"/>
    <line x1="{w*0.08}" y1="{h*0.18}" x2="{w*0.22}" y2="{h*0.18}" stroke="#FF1493" stroke-width="2"/>
  </g>
  <!-- Neon sign 2 (cyan) -->
  <g filter="url(#glow)">
    <rect x="{w*0.72}" y="{h*0.25}" width="{w*0.22}" height="{h*0.05}" rx="4" fill="none" stroke="#00FFFF" stroke-width="2"/>
    <line x1="{w*0.75}" y1="{h*0.275}" x2="{w*0.91}" y2="{h*0.275}" stroke="#00FFFF" stroke-width="2"/>
  </g>
  <!-- Neon sign 3 (purple circle) -->
  <g filter="url(#glow)">
    <circle cx="{w*0.15}" cy="{h*0.4}" r="{w*0.05}" fill="none" stroke="{TWILIGHT}" stroke-width="2.5"/>
  </g>
  <!-- Neon sign 4 (orange) -->
  <g filter="url(#glow)">
    <rect x="{w*0.74}" y="{h*0.45}" width="{w*0.18}" height="{h*0.04}" rx="3" fill="none" stroke="{SUNSET}" stroke-width="2"/>
  </g>
  <!-- Wet floor reflections -->
  <g opacity="0.3">
    <rect x="{w*0.32}" y="{h*0.7}" width="{w*0.12}" height="{h*0.25}" fill="#FF1493" opacity="0.15"/>
    <rect x="{w*0.55}" y="{h*0.65}" width="{w*0.1}" height="{h*0.3}" fill="#00FFFF" opacity="0.12"/>
    <rect x="{w*0.42}" y="{h*0.72}" width="{w*0.08}" height="{h*0.2}" fill="{TWILIGHT}" opacity="0.1"/>
  </g>
  <!-- Rain streaks -->
  <g stroke="white" stroke-width="1" opacity="0.15">
    <line x1="{w*0.35}" y1="0" x2="{w*0.34}" y2="{h*0.08}"/>
    <line x1="{w*0.45}" y1="{h*0.05}" x2="{w*0.44}" y2="{h*0.15}"/>
    <line x1="{w*0.55}" y1="{h*0.02}" x2="{w*0.54}" y2="{h*0.1}"/>
    <line x1="{w*0.65}" y1="{h*0.08}" x2="{w*0.64}" y2="{h*0.18}"/>
    <line x1="{w*0.38}" y1="{h*0.2}" x2="{w*0.37}" y2="{h*0.3}"/>
    <line x1="{w*0.5}" y1="{h*0.15}" x2="{w*0.49}" y2="{h*0.25}"/>
    <line x1="{w*0.6}" y1="{h*0.25}" x2="{w*0.59}" y2="{h*0.35}"/>
    <line x1="{w*0.42}" y1="{h*0.35}" x2="{w*0.41}" y2="{h*0.45}"/>
    <line x1="{w*0.58}" y1="{h*0.4}" x2="{w*0.57}" y2="{h*0.5}"/>
    <line x1="{w*0.48}" y1="{h*0.48}" x2="{w*0.47}" y2="{h*0.58}"/>
  </g>
  <!-- Window lights on buildings -->
  <g fill="#FFE4A0" opacity="0.4">
    <rect x="{w*0.05}" y="{h*0.55}" width="{w*0.04}" height="{h*0.03}" rx="1"/>
    <rect x="{w*0.15}" y="{h*0.6}" width="{w*0.04}" height="{h*0.03}" rx="1"/>
    <rect x="{w*0.08}" y="{h*0.7}" width="{w*0.04}" height="{h*0.03}" rx="1"/>
    <rect x="{w*0.78}" y="{h*0.58}" width="{w*0.04}" height="{h*0.03}" rx="1"/>
    <rect x="{w*0.88}" y="{h*0.65}" width="{w*0.04}" height="{h*0.03}" rx="1"/>
    <rect x="{w*0.82}" y="{h*0.75}" width="{w*0.04}" height="{h*0.03}" rx="1"/>
  </g>
  <!-- Puddle highlight -->
  <ellipse cx="{w*0.5}" cy="{h*0.85}" rx="{w*0.12}" ry="{h*0.02}" fill="white" opacity="0.05"/>
''' + svg_footer()


def gen_cloud_ocean(w: int, h: int) -> str:
    """Endless clouds lit by golden hour sunlight."""
    return svg_header(w, h, WALLPAPERS[3][1]) + f'''  <defs>
    <linearGradient id="goldenSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#FFD4A0"/>
      <stop offset="40%" stop-color="{SAKURA}"/>
      <stop offset="80%" stop-color="{SKY_BLUE}" stop-opacity="0.5"/>
      <stop offset="100%" stop-color="{CLOUD}"/>
    </linearGradient>
    <radialGradient id="sunCenter" cx="50%" cy="35%" r="25%">
      <stop offset="0%" stop-color="#FFF5E0" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="#FFF5E0" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#goldenSky)"/>
  <circle cx="{w*0.5}" cy="{h*0.3}" r="{w*0.15}" fill="url(#sunCenter)"/>
  <!-- Cloud layers (back to front, increasingly opaque) -->
  <g fill="white" opacity="0.2">
    <ellipse cx="{w*0.2}" cy="{h*0.25}" rx="{w*0.15}" ry="{h*0.03}"/>
    <ellipse cx="{w*0.6}" cy="{h*0.22}" rx="{w*0.2}" ry="{h*0.035}"/>
    <ellipse cx="{w*0.85}" cy="{h*0.28}" rx="{w*0.12}" ry="{h*0.025}"/>
  </g>
  <g fill="white" opacity="0.35">
    <ellipse cx="{w*0.15}" cy="{h*0.4}" rx="{w*0.18}" ry="{h*0.04}"/>
    <ellipse cx="{w*0.45}" cy="{h*0.38}" rx="{w*0.22}" ry="{h*0.045}"/>
    <ellipse cx="{w*0.8}" cy="{h*0.42}" rx="{w*0.16}" ry="{h*0.035}"/>
  </g>
  <g fill="white" opacity="0.5">
    <ellipse cx="{w*0.1}" cy="{h*0.55}" rx="{w*0.2}" ry="{h*0.05}"/>
    <ellipse cx="{w*0.4}" cy="{h*0.52}" rx="{w*0.25}" ry="{h*0.055}"/>
    <ellipse cx="{w*0.75}" cy="{h*0.57}" rx="{w*0.2}" ry="{h*0.045}"/>
    <ellipse cx="{w*0.95}" cy="{h*0.54}" rx="{w*0.12}" ry="{h*0.04}"/>
  </g>
  <g fill="white" opacity="0.65">
    <ellipse cx="{w*0.05}" cy="{h*0.68}" rx="{w*0.22}" ry="{h*0.06}"/>
    <ellipse cx="{w*0.35}" cy="{h*0.65}" rx="{w*0.28}" ry="{h*0.065}"/>
    <ellipse cx="{w*0.7}" cy="{h*0.7}" rx="{w*0.22}" ry="{h*0.055}"/>
    <ellipse cx="{w*0.95}" cy="{h*0.67}" rx="{w*0.15}" ry="{h*0.05}"/>
  </g>
  <g fill="white" opacity="0.8">
    <ellipse cx="{w*0.15}" cy="{h*0.82}" rx="{w*0.25}" ry="{h*0.07}"/>
    <ellipse cx="{w*0.5}" cy="{h*0.8}" rx="{w*0.3}" ry="{h*0.075}"/>
    <ellipse cx="{w*0.85}" cy="{h*0.84}" rx="{w*0.2}" ry="{h*0.06}"/>
  </g>
  <!-- Cloud shadows (golden tint underneath) -->
  <g fill="#FFD4A0" opacity="0.15">
    <ellipse cx="{w*0.35}" cy="{h*0.68}" rx="{w*0.25}" ry="{h*0.015}"/>
    <ellipse cx="{w*0.7}" cy="{h*0.73}" rx="{w*0.2}" ry="{h*0.012}"/>
  </g>
''' + svg_footer()


def gen_shrine_steps(w: int, h: int) -> str:
    """Torii gate at the top of mossy stone steps."""
    return svg_header(w, h, WALLPAPERS[4][1]) + f'''  <defs>
    <linearGradient id="forestBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#A8D8C8"/>
      <stop offset="40%" stop-color="{MATCHA}"/>
      <stop offset="100%" stop-color="#3A6B4A"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#forestBg)"/>
  <!-- Dense tree canopy overhead -->
  <g fill="#2A5A3A" opacity="0.5">
    <circle cx="{w*0.1}" cy="{h*0.05}" r="{w*0.15}"/>
    <circle cx="{w*0.35}" cy="{h*0.02}" r="{w*0.2}"/>
    <circle cx="{w*0.65}" cy="{h*0.04}" r="{w*0.18}"/>
    <circle cx="{w*0.9}" cy="{h*0.06}" r="{w*0.15}"/>
  </g>
  <!-- Light filtering through -->
  <g fill="#E0FFE0" opacity="0.08">
    <circle cx="{w*0.5}" cy="{h*0.15}" r="{w*0.2}"/>
  </g>
  <!-- Stone steps (perspective, narrowing toward top) -->
  <g fill="#A0A090" stroke="#888878" stroke-width="1">
    <rect x="{w*0.15}" y="{h*0.85}" width="{w*0.7}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.18}" y="{h*0.78}" width="{w*0.64}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.21}" y="{h*0.71}" width="{w*0.58}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.24}" y="{h*0.64}" width="{w*0.52}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.27}" y="{h*0.57}" width="{w*0.46}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.30}" y="{h*0.50}" width="{w*0.40}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.33}" y="{h*0.43}" width="{w*0.34}" height="{h*0.04}" rx="2"/>
    <rect x="{w*0.36}" y="{h*0.36}" width="{w*0.28}" height="{h*0.04}" rx="2"/>
  </g>
  <!-- Moss on steps -->
  <g fill="{MATCHA}" opacity="0.4">
    <circle cx="{w*0.2}" cy="{h*0.84}" r="8"/>
    <circle cx="{w*0.75}" cy="{h*0.77}" r="6"/>
    <circle cx="{w*0.25}" cy="{h*0.7}" r="7"/>
    <circle cx="{w*0.7}" cy="{h*0.63}" r="5"/>
  </g>
  <!-- Torii gate at top of steps -->
  <g fill="#C83030" stroke="#A02020" stroke-width="2">
    <!-- Vertical pillars -->
    <rect x="{w*0.37}" y="{h*0.18}" width="{w*0.025}" height="{h*0.22}" rx="2"/>
    <rect x="{w*0.605}" y="{h*0.18}" width="{w*0.025}" height="{h*0.22}" rx="2"/>
    <!-- Top beam (kasagi) -->
    <rect x="{w*0.34}" y="{h*0.17}" width="{w*0.32}" height="{h*0.025}" rx="3"/>
    <!-- Lower beam (nuki) -->
    <rect x="{w*0.36}" y="{h*0.23}" width="{w*0.28}" height="{h*0.015}" rx="2"/>
  </g>
  <!-- Stone lanterns beside steps -->
  <g fill="#B0B0A0" opacity="0.6">
    <rect x="{w*0.1}" y="{h*0.72}" width="{w*0.04}" height="{h*0.08}" rx="2"/>
    <rect x="{w*0.09}" y="{h*0.70}" width="{w*0.06}" height="{h*0.025}" rx="3"/>
    <rect x="{w*0.86}" y="{h*0.72}" width="{w*0.04}" height="{h*0.08}" rx="2"/>
    <rect x="{w*0.85}" y="{h*0.70}" width="{w*0.06}" height="{h*0.025}" rx="3"/>
  </g>
  <!-- Light particles / pollen -->
  <g fill="#FFE4B5" opacity="0.4">
    <circle cx="{w*0.4}" cy="{h*0.25}" r="2.5"/>
    <circle cx="{w*0.55}" cy="{h*0.3}" r="2"/>
    <circle cx="{w*0.6}" cy="{h*0.2}" r="3"/>
    <circle cx="{w*0.45}" cy="{h*0.35}" r="2"/>
    <circle cx="{w*0.35}" cy="{h*0.4}" r="1.5"/>
    <circle cx="{w*0.65}" cy="{h*0.38}" r="2.5"/>
  </g>
''' + svg_footer()


def gen_rooftop_sunset(w: int, h: int) -> str:
    """City skyline from a school rooftop at dusk."""
    return svg_header(w, h, WALLPAPERS[5][1]) + f'''  <defs>
    <linearGradient id="duskSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="{TWILIGHT}"/>
      <stop offset="30%" stop-color="{SUNSET}"/>
      <stop offset="60%" stop-color="#FFD4A0"/>
      <stop offset="100%" stop-color="{CLOUD}"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#duskSky)"/>
  <!-- Sun near horizon -->
  <circle cx="{w*0.6}" cy="{h*0.48}" r="{w*0.06}" fill="#FFE4B5" opacity="0.8"/>
  <circle cx="{w*0.6}" cy="{h*0.48}" r="{w*0.12}" fill="#FFE4B5" opacity="0.15"/>
  <!-- City skyline silhouette -->
  <g fill="#2A2040">
    <rect x="0" y="{h*0.45}" width="{w*0.06}" height="{h*0.15}"/>
    <rect x="{w*0.05}" y="{h*0.42}" width="{w*0.04}" height="{h*0.18}"/>
    <rect x="{w*0.08}" y="{h*0.38}" width="{w*0.05}" height="{h*0.22}"/>
    <rect x="{w*0.14}" y="{h*0.44}" width="{w*0.04}" height="{h*0.16}"/>
    <rect x="{w*0.19}" y="{h*0.35}" width="{w*0.03}" height="{h*0.25}"/>
    <rect x="{w*0.23}" y="{h*0.4}" width="{w*0.06}" height="{h*0.2}"/>
    <rect x="{w*0.3}" y="{h*0.42}" width="{w*0.04}" height="{h*0.18}"/>
    <rect x="{w*0.72}" y="{h*0.4}" width="{w*0.05}" height="{h*0.2}"/>
    <rect x="{w*0.78}" y="{h*0.36}" width="{w*0.04}" height="{h*0.24}"/>
    <rect x="{w*0.83}" y="{h*0.43}" width="{w*0.06}" height="{h*0.17}"/>
    <rect x="{w*0.9}" y="{h*0.39}" width="{w*0.04}" height="{h*0.21}"/>
    <rect x="{w*0.95}" y="{h*0.44}" width="{w*0.05}" height="{h*0.16}"/>
  </g>
  <!-- Building window lights -->
  <g fill="#FFE4A0" opacity="0.5">
    <rect x="{w*0.015}" y="{h*0.47}" width="4" height="3" rx="0.5"/>
    <rect x="{w*0.035}" y="{h*0.50}" width="4" height="3" rx="0.5"/>
    <rect x="{w*0.09}" y="{h*0.42}" width="4" height="3" rx="0.5"/>
    <rect x="{w*0.1}" y="{h*0.46}" width="4" height="3" rx="0.5"/>
    <rect x="{w*0.2}" y="{h*0.38}" width="3" height="2.5" rx="0.5"/>
    <rect x="{w*0.2}" y="{h*0.42}" width="3" height="2.5" rx="0.5"/>
    <rect x="{w*0.74}" y="{h*0.44}" width="4" height="3" rx="0.5"/>
    <rect x="{w*0.85}" y="{h*0.46}" width="4" height="3" rx="0.5"/>
    <rect x="{w*0.92}" y="{h*0.42}" width="3" height="2.5" rx="0.5"/>
  </g>
  <!-- Rooftop floor -->
  <rect x="0" y="{h*0.6}" width="{w}" height="{h*0.4}" fill="#3A3050"/>
  <!-- Rooftop fence -->
  <g stroke="#555570" stroke-width="2">
    <line x1="0" y1="{h*0.6}" x2="{w}" y2="{h*0.6}"/>
    <line x1="{w*0.05}" y1="{h*0.56}" x2="{w*0.05}" y2="{h*0.6}"/>
    <line x1="{w*0.15}" y1="{h*0.56}" x2="{w*0.15}" y2="{h*0.6}"/>
    <line x1="{w*0.25}" y1="{h*0.56}" x2="{w*0.25}" y2="{h*0.6}"/>
    <line x1="{w*0.35}" y1="{h*0.56}" x2="{w*0.35}" y2="{h*0.6}"/>
    <line x1="0" y1="{h*0.57}" x2="{w*0.4}" y2="{h*0.57}"/>
  </g>
  <!-- Wispy clouds -->
  <g fill="white" opacity="0.15">
    <ellipse cx="{w*0.3}" cy="{h*0.12}" rx="{w*0.15}" ry="{h*0.015}"/>
    <ellipse cx="{w*0.7}" cy="{h*0.08}" rx="{w*0.12}" ry="{h*0.012}"/>
  </g>
  <!-- Contrail line -->
  <line x1="{w*0.15}" y1="{h*0.05}" x2="{w*0.45}" y2="{h*0.15}" stroke="white" stroke-width="1.5" opacity="0.2"/>
''' + svg_footer()


def gen_starfall_lake(w: int, h: int) -> str:
    """Shooting stars reflected in still water."""
    return svg_header(w, h, WALLPAPERS[6][1]) + f'''  <defs>
    <linearGradient id="nightLake" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#0A0A2E"/>
      <stop offset="45%" stop-color="#1A1A4E"/>
      <stop offset="55%" stop-color="#1A1A4E"/>
      <stop offset="100%" stop-color="#0A0A2E"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#nightLake)"/>
  <!-- Stars -->
  <g fill="white">
    <circle cx="{w*0.05}" cy="{h*0.03}" r="1.5" opacity="0.7"/>
    <circle cx="{w*0.15}" cy="{h*0.08}" r="1" opacity="0.5"/>
    <circle cx="{w*0.25}" cy="{h*0.02}" r="2" opacity="0.8"/>
    <circle cx="{w*0.35}" cy="{h*0.1}" r="1" opacity="0.4"/>
    <circle cx="{w*0.45}" cy="{h*0.05}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.55}" cy="{h*0.12}" r="1" opacity="0.5"/>
    <circle cx="{w*0.65}" cy="{h*0.04}" r="2" opacity="0.7"/>
    <circle cx="{w*0.75}" cy="{h*0.09}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.85}" cy="{h*0.02}" r="1" opacity="0.5"/>
    <circle cx="{w*0.95}" cy="{h*0.07}" r="1.5" opacity="0.7"/>
    <circle cx="{w*0.1}" cy="{h*0.18}" r="1" opacity="0.4"/>
    <circle cx="{w*0.3}" cy="{h*0.15}" r="1.5" opacity="0.5"/>
    <circle cx="{w*0.5}" cy="{h*0.2}" r="1" opacity="0.4"/>
    <circle cx="{w*0.7}" cy="{h*0.17}" r="2" opacity="0.6"/>
    <circle cx="{w*0.9}" cy="{h*0.14}" r="1" opacity="0.4"/>
  </g>
  <!-- Shooting stars -->
  <g stroke="white" stroke-width="2" opacity="0.8">
    <line x1="{w*0.2}" y1="{h*0.1}" x2="{w*0.3}" y2="{h*0.15}" stroke-linecap="round"/>
    <line x1="{w*0.6}" y1="{h*0.05}" x2="{w*0.72}" y2="{h*0.12}" stroke-linecap="round"/>
    <line x1="{w*0.8}" y1="{h*0.18}" x2="{w*0.88}" y2="{h*0.22}" stroke-linecap="round" opacity="0.5"/>
  </g>
  <!-- Mountain silhouette on horizon -->
  <path d="M0,{h*0.48} L{w*0.15},{h*0.35} L{w*0.3},{h*0.42} L{w*0.45},{h*0.32} L{w*0.55},{h*0.38} L{w*0.7},{h*0.3} L{w*0.85},{h*0.4} L{w},{h*0.36} L{w},{h*0.5} L0,{h*0.5}Z" fill="#0A0A20"/>
  <!-- Water line -->
  <line x1="0" y1="{h*0.5}" x2="{w}" y2="{h*0.5}" stroke="#2A2A5E" stroke-width="1" opacity="0.5"/>
  <!-- Water reflections of stars (mirrored, blurred) -->
  <g fill="white" opacity="0.15">
    <ellipse cx="{w*0.25}" cy="{h*0.55}" rx="3" ry="1.5"/>
    <ellipse cx="{w*0.45}" cy="{h*0.58}" rx="2" ry="1"/>
    <ellipse cx="{w*0.65}" cy="{h*0.54}" rx="3" ry="1.5"/>
    <ellipse cx="{w*0.85}" cy="{h*0.56}" rx="2" ry="1"/>
    <ellipse cx="{w*0.15}" cy="{h*0.62}" rx="2" ry="1"/>
    <ellipse cx="{w*0.5}" cy="{h*0.65}" rx="3" ry="1"/>
    <ellipse cx="{w*0.75}" cy="{h*0.6}" rx="2.5" ry="1"/>
  </g>
  <!-- Shooting star reflections -->
  <g stroke="white" stroke-width="1.5" opacity="0.2">
    <line x1="{w*0.2}" y1="{h*0.55}" x2="{w*0.3}" y2="{h*0.52}"/>
    <line x1="{w*0.6}" y1="{h*0.53}" x2="{w*0.72}" y2="{h*0.5}"/>
  </g>
  <!-- Ripple rings -->
  <g fill="none" stroke="white" stroke-width="0.5" opacity="0.1">
    <ellipse cx="{w*0.4}" cy="{h*0.7}" rx="30" ry="5"/>
    <ellipse cx="{w*0.6}" cy="{h*0.8}" rx="25" ry="4"/>
  </g>
''' + svg_footer()


def gen_bamboo_forest(w: int, h: int) -> str:
    """Shafts of light through tall bamboo."""
    return svg_header(w, h, WALLPAPERS[7][1]) + f'''  <defs>
    <linearGradient id="bambooBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#C8E8C0"/>
      <stop offset="100%" stop-color="#4A7A4A"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#bambooBg)"/>
  <!-- Light shafts from above -->
  <g fill="#FFFFE0" opacity="0.08">
    <polygon points="{w*0.25},0 {w*0.3},0 {w*0.4},{h} {w*0.32},{h}"/>
    <polygon points="{w*0.55},0 {w*0.6},0 {w*0.65},{h} {w*0.58},{h}"/>
    <polygon points="{w*0.8},0 {w*0.84},0 {w*0.88},{h} {w*0.82},{h}"/>
  </g>
  <!-- Bamboo stalks -->
  <g>
    <rect x="{w*0.08}" y="0" width="{w*0.025}" height="{h}" fill="#5A8A4A" rx="5"/>
    <rect x="{w*0.2}" y="0" width="{w*0.03}" height="{h}" fill="#4A7A3A" rx="5"/>
    <rect x="{w*0.35}" y="0" width="{w*0.025}" height="{h}" fill="#5A9050" rx="5"/>
    <rect x="{w*0.48}" y="0" width="{w*0.03}" height="{h}" fill="#4A7A3A" rx="5"/>
    <rect x="{w*0.6}" y="0" width="{w*0.025}" height="{h}" fill="#5A8A4A" rx="5"/>
    <rect x="{w*0.72}" y="0" width="{w*0.03}" height="{h}" fill="#4A7A3A" rx="5"/>
    <rect x="{w*0.85}" y="0" width="{w*0.025}" height="{h}" fill="#5A9050" rx="5"/>
    <rect x="{w*0.95}" y="0" width="{w*0.02}" height="{h}" fill="#4A7A3A" rx="4"/>
  </g>
  <!-- Bamboo nodes (joint rings) -->
  <g fill="none" stroke="#3A6A30" stroke-width="2" opacity="0.5">
    <line x1="{w*0.08}" y1="{h*0.15}" x2="{w*0.105}" y2="{h*0.15}"/>
    <line x1="{w*0.08}" y1="{h*0.45}" x2="{w*0.105}" y2="{h*0.45}"/>
    <line x1="{w*0.08}" y1="{h*0.75}" x2="{w*0.105}" y2="{h*0.75}"/>
    <line x1="{w*0.2}" y1="{h*0.2}" x2="{w*0.23}" y2="{h*0.2}"/>
    <line x1="{w*0.2}" y1="{h*0.5}" x2="{w*0.23}" y2="{h*0.5}"/>
    <line x1="{w*0.2}" y1="{h*0.8}" x2="{w*0.23}" y2="{h*0.8}"/>
    <line x1="{w*0.35}" y1="{h*0.12}" x2="{w*0.375}" y2="{h*0.12}"/>
    <line x1="{w*0.35}" y1="{h*0.42}" x2="{w*0.375}" y2="{h*0.42}"/>
    <line x1="{w*0.35}" y1="{h*0.72}" x2="{w*0.375}" y2="{h*0.72}"/>
    <line x1="{w*0.48}" y1="{h*0.18}" x2="{w*0.51}" y2="{h*0.18}"/>
    <line x1="{w*0.48}" y1="{h*0.55}" x2="{w*0.51}" y2="{h*0.55}"/>
    <line x1="{w*0.48}" y1="{h*0.85}" x2="{w*0.51}" y2="{h*0.85}"/>
    <line x1="{w*0.6}" y1="{h*0.25}" x2="{w*0.625}" y2="{h*0.25}"/>
    <line x1="{w*0.6}" y1="{h*0.6}" x2="{w*0.625}" y2="{h*0.6}"/>
    <line x1="{w*0.72}" y1="{h*0.1}" x2="{w*0.75}" y2="{h*0.1}"/>
    <line x1="{w*0.72}" y1="{h*0.48}" x2="{w*0.75}" y2="{h*0.48}"/>
    <line x1="{w*0.72}" y1="{h*0.82}" x2="{w*0.75}" y2="{h*0.82}"/>
    <line x1="{w*0.85}" y1="{h*0.22}" x2="{w*0.875}" y2="{h*0.22}"/>
    <line x1="{w*0.85}" y1="{h*0.62}" x2="{w*0.875}" y2="{h*0.62}"/>
  </g>
  <!-- Small bamboo leaves -->
  <g fill="#3A6A30" opacity="0.6">
    <path d="M{w*0.105},{h*0.15} Q{w*0.14},{h*0.12} {w*0.16},{h*0.1} Q{w*0.13},{h*0.13} {w*0.105},{h*0.15}Z"/>
    <path d="M{w*0.23},{h*0.2} Q{w*0.27},{h*0.17} {w*0.29},{h*0.14} Q{w*0.26},{h*0.18} {w*0.23},{h*0.2}Z"/>
    <path d="M{w*0.375},{h*0.42} Q{w*0.41},{h*0.39} {w*0.43},{h*0.36} Q{w*0.40},{h*0.40} {w*0.375},{h*0.42}Z"/>
    <path d="M{w*0.51},{h*0.18} Q{w*0.55},{h*0.15} {w*0.57},{h*0.12} Q{w*0.54},{h*0.16} {w*0.51},{h*0.18}Z"/>
    <path d="M{w*0.625},{h*0.25} Q{w*0.66},{h*0.22} {w*0.68},{h*0.19} Q{w*0.65},{h*0.23} {w*0.625},{h*0.25}Z"/>
    <path d="M{w*0.75},{h*0.48} Q{w*0.79},{h*0.45} {w*0.81},{h*0.42} Q{w*0.78},{h*0.46} {w*0.75},{h*0.48}Z"/>
  </g>
  <!-- Mist at ground level -->
  <g fill="white" opacity="0.12">
    <ellipse cx="{w*0.3}" cy="{h*0.92}" rx="{w*0.25}" ry="{h*0.04}"/>
    <ellipse cx="{w*0.7}" cy="{h*0.9}" rx="{w*0.2}" ry="{h*0.035}"/>
  </g>
  <!-- Floating particles -->
  <g fill="#FFFFE0" opacity="0.3">
    <circle cx="{w*0.28}" cy="{h*0.3}" r="2"/>
    <circle cx="{w*0.55}" cy="{h*0.4}" r="1.5"/>
    <circle cx="{w*0.42}" cy="{h*0.55}" r="2"/>
    <circle cx="{w*0.78}" cy="{h*0.35}" r="1.5"/>
    <circle cx="{w*0.15}" cy="{h*0.6}" r="2"/>
  </g>
''' + svg_footer()


def gen_train_window(w: int, h: int) -> str:
    """Countryside blurring past a rainy train window."""
    return svg_header(w, h, WALLPAPERS[8][1]) + f'''  <defs>
    <linearGradient id="countryside" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#A8B8C8"/>
      <stop offset="50%" stop-color="#90A890"/>
      <stop offset="100%" stop-color="#6A8A5A"/>
    </linearGradient>
    <radialGradient id="rainDrop" cx="35%" cy="30%" r="60%">
      <stop offset="0%" stop-color="white" stop-opacity="0.4"/>
      <stop offset="100%" stop-color="white" stop-opacity="0.08"/>
    </radialGradient>
  </defs>
  <!-- Blurred countryside view -->
  <rect width="{w}" height="{h}" fill="url(#countryside)"/>
  <!-- Blurred hills -->
  <g opacity="0.4">
    <ellipse cx="{w*0.3}" cy="{h*0.45}" rx="{w*0.35}" ry="{h*0.08}" fill="#7A9A6A"/>
    <ellipse cx="{w*0.7}" cy="{h*0.48}" rx="{w*0.3}" ry="{h*0.07}" fill="#6A8A5A"/>
  </g>
  <!-- Blurred green fields -->
  <rect x="0" y="{h*0.52}" width="{w}" height="{h*0.48}" fill="#5A7A4A" opacity="0.6"/>
  <!-- Motion blur streaks (horizontal) -->
  <g stroke="#6A8A5A" stroke-width="2" opacity="0.15">
    <line x1="0" y1="{h*0.55}" x2="{w}" y2="{h*0.55}"/>
    <line x1="0" y1="{h*0.6}" x2="{w}" y2="{h*0.6}"/>
    <line x1="0" y1="{h*0.65}" x2="{w}" y2="{h*0.65}"/>
    <line x1="0" y1="{h*0.7}" x2="{w}" y2="{h*0.7}"/>
    <line x1="0" y1="{h*0.75}" x2="{w}" y2="{h*0.75}"/>
  </g>
  <!-- Glass tint overlay -->
  <rect width="{w}" height="{h}" fill="#B0C0D0" opacity="0.15"/>
  <!-- Raindrops on window -->
  <g>
    <ellipse cx="{w*0.15}" cy="{h*0.08}" rx="9" ry="11" fill="url(#rainDrop)"/>
    <path d="M{w*0.15},{h*0.08} Q{w*0.14},{h*0.2} {w*0.155},{h*0.35}" stroke="white" stroke-opacity="0.12" stroke-width="2" fill="none"/>
    <ellipse cx="{w*0.4}" cy="{h*0.05}" rx="10" ry="12" fill="url(#rainDrop)"/>
    <path d="M{w*0.4},{h*0.05} Q{w*0.39},{h*0.18} {w*0.41},{h*0.35} Q{w*0.405},{h*0.5} {w*0.42},{h*0.6}" stroke="white" stroke-opacity="0.1" stroke-width="2.5" fill="none"/>
    <ellipse cx="{w*0.65}" cy="{h*0.1}" rx="8" ry="10" fill="url(#rainDrop)"/>
    <path d="M{w*0.65},{h*0.1} Q{w*0.64},{h*0.22} {w*0.66},{h*0.38}" stroke="white" stroke-opacity="0.12" stroke-width="2" fill="none"/>
    <ellipse cx="{w*0.85}" cy="{h*0.06}" rx="7" ry="9" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.3}" cy="{h*0.3}" rx="6" ry="8" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.55}" cy="{h*0.25}" rx="7" ry="9" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.75}" cy="{h*0.35}" rx="8" ry="10" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.2}" cy="{h*0.5}" rx="6" ry="8" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.5}" cy="{h*0.55}" rx="9" ry="11" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.8}" cy="{h*0.48}" rx="7" ry="9" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.1}" cy="{h*0.7}" rx="8" ry="10" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.45}" cy="{h*0.72}" rx="6" ry="8" fill="url(#rainDrop)"/>
    <ellipse cx="{w*0.9}" cy="{h*0.65}" rx="7" ry="9" fill="url(#rainDrop)"/>
  </g>
  <!-- Tiny scattered drops -->
  <g fill="white" opacity="0.15">
    <circle cx="{w*0.08}" cy="{h*0.15}" r="2.5"/><circle cx="{w*0.22}" cy="{h*0.12}" r="2"/>
    <circle cx="{w*0.35}" cy="{h*0.18}" r="2.5"/><circle cx="{w*0.48}" cy="{h*0.14}" r="2"/>
    <circle cx="{w*0.58}" cy="{h*0.2}" r="3"/><circle cx="{w*0.72}" cy="{h*0.22}" r="2"/>
    <circle cx="{w*0.88}" cy="{h*0.16}" r="2.5"/><circle cx="{w*0.32}" cy="{h*0.42}" r="2"/>
    <circle cx="{w*0.62}" cy="{h*0.45}" r="2.5"/><circle cx="{w*0.15}" cy="{h*0.6}" r="2"/>
  </g>
  <!-- Window frame edge -->
  <rect x="0" y="{h*0.88}" width="{w}" height="{h*0.12}" fill="#3A3A4A" opacity="0.6"/>
''' + svg_footer()


def gen_lantern_festival(w: int, h: int) -> str:
    """Paper lanterns floating into night sky."""
    return svg_header(w, h, WALLPAPERS[9][1]) + f'''  <defs>
    <linearGradient id="festNight" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#0A0A2E"/>
      <stop offset="60%" stop-color="#1A1A4E"/>
      <stop offset="100%" stop-color="#2A2A3E"/>
    </linearGradient>
    <radialGradient id="lanternGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#FFD4A0" stop-opacity="0.9"/>
      <stop offset="60%" stop-color="#FFA060" stop-opacity="0.3"/>
      <stop offset="100%" stop-color="#FFA060" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#festNight)"/>
  <!-- Stars -->
  <g fill="white">
    <circle cx="{w*0.05}" cy="{h*0.03}" r="1" opacity="0.5"/>
    <circle cx="{w*0.15}" cy="{h*0.06}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.3}" cy="{h*0.02}" r="1" opacity="0.4"/>
    <circle cx="{w*0.5}" cy="{h*0.05}" r="1.5" opacity="0.5"/>
    <circle cx="{w*0.7}" cy="{h*0.03}" r="1" opacity="0.6"/>
    <circle cx="{w*0.85}" cy="{h*0.07}" r="1.5" opacity="0.4"/>
    <circle cx="{w*0.95}" cy="{h*0.04}" r="1" opacity="0.5"/>
  </g>
  <!-- Lanterns (various sizes, getting smaller/fainter as they rise) -->
  <!-- Large close lanterns -->
  <g>
    <circle cx="{w*0.3}" cy="{h*0.65}" r="{w*0.06}" fill="url(#lanternGlow)"/>
    <rect x="{w*0.27}" y="{h*0.62}" width="{w*0.06}" height="{h*0.06}" rx="6" fill="#FFA040" opacity="0.7"/>
  </g>
  <g>
    <circle cx="{w*0.7}" cy="{h*0.6}" r="{w*0.055}" fill="url(#lanternGlow)"/>
    <rect x="{w*0.675}" y="{h*0.575}" width="{w*0.05}" height="{h*0.05}" rx="5" fill="#FFB050" opacity="0.7"/>
  </g>
  <g>
    <circle cx="{w*0.15}" cy="{h*0.72}" r="{w*0.05}" fill="url(#lanternGlow)"/>
    <rect x="{w*0.13}" y="{h*0.70}" width="{w*0.04}" height="{h*0.045}" rx="5" fill="#FFA040" opacity="0.65"/>
  </g>
  <!-- Medium lanterns -->
  <g>
    <circle cx="{w*0.5}" cy="{h*0.45}" r="{w*0.04}" fill="url(#lanternGlow)"/>
    <rect x="{w*0.485}" y="{h*0.435}" width="{w*0.03}" height="{h*0.035}" rx="4" fill="#FFB060" opacity="0.6"/>
  </g>
  <g>
    <circle cx="{w*0.85}" cy="{h*0.5}" r="{w*0.035}" fill="url(#lanternGlow)"/>
    <rect x="{w*0.835}" y="{h*0.485}" width="{w*0.03}" height="{h*0.03}" rx="4" fill="#FFA050" opacity="0.55"/>
  </g>
  <g>
    <circle cx="{w*0.2}" cy="{h*0.48}" r="{w*0.04}" fill="url(#lanternGlow)"/>
    <rect x="{w*0.185}" y="{h*0.465}" width="{w*0.03}" height="{h*0.035}" rx="4" fill="#FFC070" opacity="0.55"/>
  </g>
  <!-- Small distant lanterns -->
  <g opacity="0.5">
    <circle cx="{w*0.4}" cy="{h*0.3}" r="{w*0.025}" fill="url(#lanternGlow)"/>
    <circle cx="{w*0.6}" cy="{h*0.25}" r="{w*0.02}" fill="url(#lanternGlow)"/>
    <circle cx="{w*0.35}" cy="{h*0.2}" r="{w*0.018}" fill="url(#lanternGlow)"/>
    <circle cx="{w*0.75}" cy="{h*0.28}" r="{w*0.022}" fill="url(#lanternGlow)"/>
    <circle cx="{w*0.55}" cy="{h*0.15}" r="{w*0.015}" fill="url(#lanternGlow)"/>
    <circle cx="{w*0.45}" cy="{h*0.1}" r="{w*0.012}" fill="url(#lanternGlow)"/>
  </g>
  <!-- Ground silhouette with people outline -->
  <rect x="0" y="{h*0.82}" width="{w}" height="{h*0.18}" fill="#0A0A1A"/>
  <path d="M0,{h*0.82} Q{w*0.3},{h*0.8} {w*0.5},{h*0.82} Q{w*0.7},{h*0.84} {w},{h*0.82}" fill="#0A0A1A"/>
''' + svg_footer()


def gen_moon_bridge(w: int, h: int) -> str:
    """Arched bridge under an enormous full moon."""
    return svg_header(w, h, WALLPAPERS[10][1]) + f'''  <defs>
    <linearGradient id="moonNight" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#0A1428"/>
      <stop offset="50%" stop-color="#1A2848"/>
      <stop offset="100%" stop-color="#2A3858"/>
    </linearGradient>
    <radialGradient id="bigMoon" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#FFF8E0"/>
      <stop offset="70%" stop-color="#FFE8C0"/>
      <stop offset="100%" stop-color="#E8D0A0" stop-opacity="0.5"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#moonNight)"/>
  <!-- Enormous moon -->
  <circle cx="{w*0.5}" cy="{h*0.3}" r="{w*0.22}" fill="url(#bigMoon)" opacity="0.9"/>
  <!-- Moon surface details -->
  <g fill="#D8C8A0" opacity="0.15">
    <circle cx="{w*0.44}" cy="{h*0.25}" r="{w*0.03}"/>
    <circle cx="{w*0.55}" cy="{h*0.32}" r="{w*0.04}"/>
    <circle cx="{w*0.48}" cy="{h*0.38}" r="{w*0.025}"/>
    <circle cx="{w*0.58}" cy="{h*0.24}" r="{w*0.02}"/>
  </g>
  <!-- Stars -->
  <g fill="white">
    <circle cx="{w*0.05}" cy="{h*0.05}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.12}" cy="{h*0.12}" r="1" opacity="0.4"/>
    <circle cx="{w*0.88}" cy="{h*0.08}" r="1.5" opacity="0.5"/>
    <circle cx="{w*0.92}" cy="{h*0.15}" r="1" opacity="0.4"/>
    <circle cx="{w*0.08}" cy="{h*0.45}" r="1" opacity="0.3"/>
    <circle cx="{w*0.95}" cy="{h*0.42}" r="1.5" opacity="0.3"/>
  </g>
  <!-- Water -->
  <rect x="0" y="{h*0.6}" width="{w}" height="{h*0.4}" fill="#0A1020"/>
  <!-- Moon reflection in water -->
  <ellipse cx="{w*0.5}" cy="{h*0.75}" rx="{w*0.15}" ry="{h*0.08}" fill="#FFF8E0" opacity="0.12"/>
  <!-- Arched bridge silhouette -->
  <path d="M{w*0.15},{h*0.62} Q{w*0.5},{h*0.42} {w*0.85},{h*0.62}" fill="none" stroke="#1A1A2A" stroke-width="{w*0.02}"/>
  <!-- Bridge railings -->
  <g stroke="#1A1A2A" stroke-width="2">
    <line x1="{w*0.25}" y1="{h*0.55}" x2="{w*0.25}" y2="{h*0.59}"/>
    <line x1="{w*0.35}" y1="{h*0.50}" x2="{w*0.35}" y2="{h*0.54}"/>
    <line x1="{w*0.45}" y1="{h*0.47}" x2="{w*0.45}" y2="{h*0.51}"/>
    <line x1="{w*0.55}" y1="{h*0.47}" x2="{w*0.55}" y2="{h*0.51}"/>
    <line x1="{w*0.65}" y1="{h*0.50}" x2="{w*0.65}" y2="{h*0.54}"/>
    <line x1="{w*0.75}" y1="{h*0.55}" x2="{w*0.75}" y2="{h*0.59}"/>
  </g>
  <!-- Bridge railing top bar -->
  <path d="M{w*0.2},{h*0.57} Q{w*0.5},{h*0.40} {w*0.8},{h*0.57}" fill="none" stroke="#1A1A2A" stroke-width="3"/>
  <!-- Water ripples -->
  <g fill="none" stroke="white" stroke-width="0.5" opacity="0.08">
    <ellipse cx="{w*0.5}" cy="{h*0.72}" rx="{w*0.2}" ry="4"/>
    <ellipse cx="{w*0.5}" cy="{h*0.78}" rx="{w*0.25}" ry="5"/>
    <ellipse cx="{w*0.5}" cy="{h*0.85}" rx="{w*0.3}" ry="5"/>
  </g>
''' + svg_footer()


def gen_flower_field(w: int, h: int) -> str:
    """Endless wildflowers under pastel sky."""
    return svg_header(w, h, WALLPAPERS[11][1]) + f'''  <defs>
    <linearGradient id="pastelSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="{CLOUD}"/>
      <stop offset="40%" stop-color="{SKY_BLUE}" stop-opacity="0.6"/>
      <stop offset="100%" stop-color="{SAKURA}" stop-opacity="0.3"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#pastelSky)"/>
  <!-- Fluffy clouds -->
  <g fill="white" opacity="0.6">
    <ellipse cx="{w*0.2}" cy="{h*0.1}" rx="{w*0.1}" ry="{h*0.025}"/>
    <ellipse cx="{w*0.25}" cy="{h*0.09}" rx="{w*0.07}" ry="{h*0.02}"/>
    <ellipse cx="{w*0.7}" cy="{h*0.12}" rx="{w*0.12}" ry="{h*0.03}"/>
    <ellipse cx="{w*0.75}" cy="{h*0.11}" rx="{w*0.08}" ry="{h*0.022}"/>
  </g>
  <!-- Distant hills -->
  <ellipse cx="{w*0.3}" cy="{h*0.45}" rx="{w*0.4}" ry="{h*0.04}" fill="{MATCHA}" opacity="0.3"/>
  <ellipse cx="{w*0.7}" cy="{h*0.47}" rx="{w*0.35}" ry="{h*0.035}" fill="#78B890" opacity="0.25"/>
  <!-- Green field -->
  <rect x="0" y="{h*0.48}" width="{w}" height="{h*0.52}" fill="{MATCHA}"/>
  <rect x="0" y="{h*0.55}" width="{w}" height="{h*0.45}" fill="#6AB080"/>
  <!-- Flowers — scattered across field -->
  <g>
    <!-- Pink flowers -->
    <circle cx="{w*0.1}" cy="{h*0.52}" r="5" fill="{SAKURA}" opacity="0.8"/>
    <circle cx="{w*0.25}" cy="{h*0.55}" r="6" fill="{SAKURA}" opacity="0.7"/>
    <circle cx="{w*0.4}" cy="{h*0.53}" r="5" fill="#FFD0DC" opacity="0.8"/>
    <circle cx="{w*0.6}" cy="{h*0.54}" r="6" fill="{SAKURA}" opacity="0.7"/>
    <circle cx="{w*0.75}" cy="{h*0.52}" r="5" fill="#FFD0DC" opacity="0.8"/>
    <circle cx="{w*0.9}" cy="{h*0.55}" r="6" fill="{SAKURA}" opacity="0.7"/>
    <!-- White flowers -->
    <circle cx="{w*0.15}" cy="{h*0.57}" r="4" fill="white" opacity="0.7"/>
    <circle cx="{w*0.35}" cy="{h*0.59}" r="5" fill="white" opacity="0.6"/>
    <circle cx="{w*0.55}" cy="{h*0.58}" r="4" fill="white" opacity="0.7"/>
    <circle cx="{w*0.7}" cy="{h*0.6}" r="5" fill="white" opacity="0.6"/>
    <circle cx="{w*0.85}" cy="{h*0.57}" r="4" fill="white" opacity="0.7"/>
    <!-- Yellow flowers -->
    <circle cx="{w*0.2}" cy="{h*0.62}" r="5" fill="#FFE080" opacity="0.7"/>
    <circle cx="{w*0.45}" cy="{h*0.63}" r="6" fill="#FFE080" opacity="0.6"/>
    <circle cx="{w*0.65}" cy="{h*0.64}" r="5" fill="#FFE080" opacity="0.7"/>
    <circle cx="{w*0.8}" cy="{h*0.62}" r="6" fill="#FFE080" opacity="0.6"/>
    <!-- Purple flowers (mid) -->
    <circle cx="{w*0.12}" cy="{h*0.68}" r="6" fill="{TWILIGHT}" opacity="0.5"/>
    <circle cx="{w*0.3}" cy="{h*0.7}" r="7" fill="{TWILIGHT}" opacity="0.45"/>
    <circle cx="{w*0.5}" cy="{h*0.69}" r="6" fill="{TWILIGHT}" opacity="0.5"/>
    <circle cx="{w*0.72}" cy="{h*0.71}" r="7" fill="{TWILIGHT}" opacity="0.45"/>
    <circle cx="{w*0.92}" cy="{h*0.68}" r="6" fill="{TWILIGHT}" opacity="0.5"/>
    <!-- Close foreground flowers (larger) -->
    <circle cx="{w*0.08}" cy="{h*0.82}" r="10" fill="{SAKURA}" opacity="0.5"/>
    <circle cx="{w*0.35}" cy="{h*0.85}" r="12" fill="#FFD0DC" opacity="0.4"/>
    <circle cx="{w*0.6}" cy="{h*0.83}" r="10" fill="{SAKURA}" opacity="0.45"/>
    <circle cx="{w*0.88}" cy="{h*0.86}" r="11" fill="#FFD0DC" opacity="0.4"/>
  </g>
  <!-- Butterfly -->
  <g transform="translate({w*0.4},{h*0.4}) scale(0.8)" opacity="0.6">
    <path d="M0,0 Q-15,-12 -12,-25 Q-5,-15 0,-5Z" fill="{SAKURA}"/>
    <path d="M0,0 Q15,-12 12,-25 Q5,-15 0,-5Z" fill="{SAKURA}"/>
  </g>
''' + svg_footer()


def gen_rainy_crosswalk(w: int, h: int) -> str:
    """Neon reflections on a wet city crossing."""
    return svg_header(w, h, WALLPAPERS[12][1]) + f'''  <defs>
    <linearGradient id="urbanNight" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1A1A2E"/>
      <stop offset="100%" stop-color="#15152A"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#urbanNight)"/>
  <!-- Wet road surface -->
  <rect x="0" y="{h*0.4}" width="{w}" height="{h*0.6}" fill="#12121E"/>
  <!-- Crosswalk stripes -->
  <g fill="white" opacity="0.3">
    <rect x="{w*0.2}" y="{h*0.55}" width="{w*0.6}" height="{h*0.02}" rx="1"/>
    <rect x="{w*0.2}" y="{h*0.6}" width="{w*0.6}" height="{h*0.02}" rx="1"/>
    <rect x="{w*0.2}" y="{h*0.65}" width="{w*0.6}" height="{h*0.02}" rx="1"/>
    <rect x="{w*0.2}" y="{h*0.7}" width="{w*0.6}" height="{h*0.02}" rx="1"/>
    <rect x="{w*0.2}" y="{h*0.75}" width="{w*0.6}" height="{h*0.02}" rx="1"/>
  </g>
  <!-- Building silhouettes -->
  <g fill="#0A0A18">
    <rect x="0" y="{h*0.1}" width="{w*0.12}" height="{h*0.3}"/>
    <rect x="{w*0.1}" y="{h*0.05}" width="{w*0.08}" height="{h*0.35}"/>
    <rect x="{w*0.16}" y="{h*0.12}" width="{w*0.1}" height="{h*0.28}"/>
    <rect x="{w*0.8}" y="{h*0.08}" width="{w*0.1}" height="{h*0.32}"/>
    <rect x="{w*0.88}" y="{h*0.15}" width="{w*0.12}" height="{h*0.25}"/>
  </g>
  <!-- Neon signs on buildings -->
  <g>
    <rect x="{w*0.02}" y="{h*0.2}" width="{w*0.08}" height="{h*0.03}" rx="2" fill="#FF1493" opacity="0.6"/>
    <rect x="{w*0.82}" y="{h*0.18}" width="{w*0.06}" height="{h*0.025}" rx="2" fill="#00FFFF" opacity="0.5"/>
    <circle cx="{w*0.15}" cy="{h*0.15}" r="{w*0.02}" fill="{SUNSET}" opacity="0.4"/>
  </g>
  <!-- Traffic light (green) -->
  <g>
    <rect x="{w*0.48}" y="{h*0.3}" width="{w*0.025}" height="{h*0.06}" rx="3" fill="#2A2A3A"/>
    <circle cx="{w*0.4925}" cy="{h*0.35}" r="5" fill="#00FF80" opacity="0.7"/>
    <rect x="{w*0.4875}" y="{h*0.36}" width="{w*0.01}" height="{h*0.08}" fill="#2A2A3A"/>
  </g>
  <!-- Neon reflections on wet ground -->
  <g opacity="0.2">
    <rect x="{w*0.05}" y="{h*0.5}" width="{w*0.1}" height="{h*0.35}" fill="#FF1493" opacity="0.15"/>
    <rect x="{w*0.82}" y="{h*0.48}" width="{w*0.08}" height="{h*0.38}" fill="#00FFFF" opacity="0.12"/>
    <rect x="{w*0.45}" y="{h*0.45}" width="{w*0.06}" height="{h*0.4}" fill="#00FF80" opacity="0.1"/>
  </g>
  <!-- Rain streaks -->
  <g stroke="white" stroke-width="1" opacity="0.12">
    <line x1="{w*0.1}" y1="0" x2="{w*0.09}" y2="{h*0.08}"/>
    <line x1="{w*0.25}" y1="{h*0.05}" x2="{w*0.24}" y2="{h*0.15}"/>
    <line x1="{w*0.4}" y1="{h*0.02}" x2="{w*0.39}" y2="{h*0.1}"/>
    <line x1="{w*0.6}" y1="{h*0.06}" x2="{w*0.59}" y2="{h*0.16}"/>
    <line x1="{w*0.75}" y1="0" x2="{w*0.74}" y2="{h*0.09}"/>
    <line x1="{w*0.9}" y1="{h*0.04}" x2="{w*0.89}" y2="{h*0.12}"/>
    <line x1="{w*0.15}" y1="{h*0.2}" x2="{w*0.14}" y2="{h*0.3}"/>
    <line x1="{w*0.5}" y1="{h*0.18}" x2="{w*0.49}" y2="{h*0.28}"/>
    <line x1="{w*0.85}" y1="{h*0.22}" x2="{w*0.84}" y2="{h*0.32}"/>
  </g>
''' + svg_footer()


def gen_island_cove(w: int, h: int) -> str:
    """Turquoise water lapping at a rocky shore."""
    return svg_header(w, h, WALLPAPERS[13][1]) + f'''  <defs>
    <linearGradient id="tropicSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="{SKY_BLUE}"/>
      <stop offset="100%" stop-color="#B8E8F0"/>
    </linearGradient>
    <linearGradient id="ocean" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#40C8D8"/>
      <stop offset="100%" stop-color="#2090A0"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#tropicSky)"/>
  <!-- Fluffy clouds -->
  <g fill="white" opacity="0.7">
    <ellipse cx="{w*0.2}" cy="{h*0.08}" rx="{w*0.1}" ry="{h*0.025}"/>
    <ellipse cx="{w*0.25}" cy="{h*0.07}" rx="{w*0.06}" ry="{h*0.018}"/>
    <ellipse cx="{w*0.75}" cy="{h*0.1}" rx="{w*0.12}" ry="{h*0.028}"/>
    <ellipse cx="{w*0.8}" cy="{h*0.09}" rx="{w*0.07}" ry="{h*0.02}"/>
  </g>
  <!-- Ocean -->
  <rect x="0" y="{h*0.35}" width="{w}" height="{h*0.35}" fill="url(#ocean)"/>
  <!-- Distant island silhouette -->
  <ellipse cx="{w*0.75}" cy="{h*0.35}" rx="{w*0.1}" ry="{h*0.03}" fill="#5AA080" opacity="0.4"/>
  <!-- Wave lines -->
  <g fill="none" stroke="white" stroke-width="1.5" opacity="0.2">
    <path d="M0,{h*0.42} Q{w*0.15},{h*0.40} {w*0.3},{h*0.42} Q{w*0.45},{h*0.44} {w*0.6},{h*0.42} Q{w*0.75},{h*0.40} {w},{h*0.42}"/>
    <path d="M0,{h*0.48} Q{w*0.2},{h*0.46} {w*0.4},{h*0.48} Q{w*0.6},{h*0.50} {w*0.8},{h*0.48} Q{w*0.9},{h*0.46} {w},{h*0.48}"/>
    <path d="M0,{h*0.55} Q{w*0.1},{h*0.53} {w*0.25},{h*0.55} Q{w*0.4},{h*0.57} {w*0.55},{h*0.55} Q{w*0.7},{h*0.53} {w},{h*0.55}"/>
  </g>
  <!-- Sandy shore -->
  <path d="M0,{h*0.7} Q{w*0.3},{h*0.65} {w*0.5},{h*0.68} Q{w*0.7},{h*0.72} {w},{h*0.66} L{w},{h} L0,{h}Z" fill="#F0E0C0"/>
  <!-- Shallow water over sand -->
  <path d="M0,{h*0.7} Q{w*0.3},{h*0.65} {w*0.5},{h*0.68} Q{w*0.7},{h*0.72} {w},{h*0.66} L{w},{h*0.72} Q{w*0.7},{h*0.76} {w*0.5},{h*0.73} Q{w*0.3},{h*0.70} 0,{h*0.74}Z" fill="#60D8E0" opacity="0.3"/>
  <!-- Rocks -->
  <g fill="#8A8878">
    <ellipse cx="{w*0.15}" cy="{h*0.72}" rx="{w*0.04}" ry="{h*0.02}" opacity="0.7"/>
    <ellipse cx="{w*0.82}" cy="{h*0.7}" rx="{w*0.05}" ry="{h*0.025}" opacity="0.6"/>
    <ellipse cx="{w*0.6}" cy="{h*0.73}" rx="{w*0.03}" ry="{h*0.015}" opacity="0.5"/>
  </g>
  <!-- Foam at shore edge -->
  <g fill="white" opacity="0.4">
    <ellipse cx="{w*0.2}" cy="{h*0.71}" rx="15" ry="3"/>
    <ellipse cx="{w*0.45}" cy="{h*0.69}" rx="20" ry="3"/>
    <ellipse cx="{w*0.7}" cy="{h*0.72}" rx="18" ry="3"/>
    <ellipse cx="{w*0.9}" cy="{h*0.68}" rx="15" ry="3"/>
  </g>
  <!-- Light sparkles on water -->
  <g fill="white" opacity="0.4">
    <circle cx="{w*0.3}" cy="{h*0.4}" r="2"/>
    <circle cx="{w*0.5}" cy="{h*0.45}" r="2.5"/>
    <circle cx="{w*0.65}" cy="{h*0.38}" r="2"/>
    <circle cx="{w*0.85}" cy="{h*0.5}" r="1.5"/>
    <circle cx="{w*0.15}" cy="{h*0.52}" r="2"/>
  </g>
''' + svg_footer()


def gen_snow_village(w: int, h: int) -> str:
    """Warm windows glowing through falling snow."""
    return svg_header(w, h, WALLPAPERS[14][1]) + f'''  <defs>
    <linearGradient id="snowSky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#2A3050"/>
      <stop offset="100%" stop-color="#4A5070"/>
    </linearGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#snowSky)"/>
  <!-- Snow ground -->
  <path d="M0,{h*0.6} Q{w*0.25},{h*0.58} {w*0.5},{h*0.6} Q{w*0.75},{h*0.62} {w},{h*0.58} L{w},{h} L0,{h}Z" fill="#E0E8F0"/>
  <!-- Houses -->
  <!-- House 1 (left) -->
  <g>
    <rect x="{w*0.1}" y="{h*0.45}" width="{w*0.15}" height="{h*0.17}" fill="#4A4050"/>
    <polygon points="{w*0.08},{h*0.45} {w*0.175},{h*0.33} {w*0.27},{h*0.45}" fill="#5A5060"/>
    <!-- Snow on roof -->
    <polygon points="{w*0.08},{h*0.45} {w*0.175},{h*0.33} {w*0.27},{h*0.45}" fill="white" opacity="0.4"/>
    <!-- Warm window -->
    <rect x="{w*0.14}" y="{h*0.5}" width="{w*0.03}" height="{h*0.04}" rx="1" fill="#FFD080" opacity="0.8"/>
    <rect x="{w*0.20}" y="{h*0.5}" width="{w*0.03}" height="{h*0.04}" rx="1" fill="#FFD080" opacity="0.8"/>
    <!-- Window glow -->
    <circle cx="{w*0.155}" cy="{h*0.52}" r="{w*0.03}" fill="#FFD080" opacity="0.1"/>
    <circle cx="{w*0.215}" cy="{h*0.52}" r="{w*0.03}" fill="#FFD080" opacity="0.1"/>
  </g>
  <!-- House 2 (center) -->
  <g>
    <rect x="{w*0.38}" y="{h*0.4}" width="{w*0.2}" height="{h*0.22}" fill="#3A3848"/>
    <polygon points="{w*0.36},{h*0.4} {w*0.48},{h*0.25} {w*0.6},{h*0.4}" fill="#4A4858"/>
    <polygon points="{w*0.36},{h*0.4} {w*0.48},{h*0.25} {w*0.6},{h*0.4}" fill="white" opacity="0.35"/>
    <!-- Door -->
    <rect x="{w*0.46}" y="{h*0.52}" width="{w*0.04}" height="{h*0.1}" rx="2" fill="#3A2828"/>
    <!-- Windows -->
    <rect x="{w*0.40}" y="{h*0.46}" width="{w*0.04}" height="{h*0.04}" rx="1" fill="#FFD080" opacity="0.8"/>
    <rect x="{w*0.52}" y="{h*0.46}" width="{w*0.04}" height="{h*0.04}" rx="1" fill="#FFD080" opacity="0.8"/>
    <circle cx="{w*0.42}" cy="{h*0.48}" r="{w*0.04}" fill="#FFD080" opacity="0.08"/>
    <circle cx="{w*0.54}" cy="{h*0.48}" r="{w*0.04}" fill="#FFD080" opacity="0.08"/>
    <!-- Chimney -->
    <rect x="{w*0.52}" y="{h*0.27}" width="{w*0.025}" height="{h*0.08}" fill="#4A4858"/>
  </g>
  <!-- House 3 (right) -->
  <g>
    <rect x="{w*0.72}" y="{h*0.48}" width="{w*0.13}" height="{h*0.14}" fill="#4A4050"/>
    <polygon points="{w*0.7},{h*0.48} {w*0.785},{h*0.38} {w*0.87},{h*0.48}" fill="#5A5060"/>
    <polygon points="{w*0.7},{h*0.48} {w*0.785},{h*0.38} {w*0.87},{h*0.48}" fill="white" opacity="0.4"/>
    <rect x="{w*0.76}" y="{h*0.52}" width="{w*0.03}" height="{h*0.04}" rx="1" fill="#FFD080" opacity="0.8"/>
    <circle cx="{w*0.775}" cy="{h*0.54}" r="{w*0.03}" fill="#FFD080" opacity="0.1"/>
  </g>
  <!-- Trees -->
  <g fill="#3A5040">
    <polygon points="{w*0.32},{h*0.6} {w*0.34},{h*0.4} {w*0.36},{h*0.6}"/>
    <polygon points="{w*0.66},{h*0.6} {w*0.68},{h*0.42} {w*0.7},{h*0.6}"/>
    <polygon points="{w*0.9},{h*0.6} {w*0.92},{h*0.44} {w*0.94},{h*0.6}"/>
  </g>
  <!-- Snow on trees -->
  <g fill="white" opacity="0.5">
    <ellipse cx="{w*0.34}" cy="{h*0.45}" rx="{w*0.015}" ry="{h*0.01}"/>
    <ellipse cx="{w*0.68}" cy="{h*0.47}" rx="{w*0.015}" ry="{h*0.01}"/>
    <ellipse cx="{w*0.92}" cy="{h*0.49}" rx="{w*0.015}" ry="{h*0.01}"/>
  </g>
  <!-- Falling snow -->
  <g fill="white">
    <circle cx="{w*0.05}" cy="{h*0.05}" r="3" opacity="0.7"/>
    <circle cx="{w*0.15}" cy="{h*0.12}" r="2" opacity="0.5"/>
    <circle cx="{w*0.25}" cy="{h*0.08}" r="2.5" opacity="0.6"/>
    <circle cx="{w*0.35}" cy="{h*0.15}" r="3" opacity="0.5"/>
    <circle cx="{w*0.45}" cy="{h*0.05}" r="2" opacity="0.7"/>
    <circle cx="{w*0.55}" cy="{h*0.18}" r="2.5" opacity="0.5"/>
    <circle cx="{w*0.65}" cy="{h*0.1}" r="3" opacity="0.6"/>
    <circle cx="{w*0.75}" cy="{h*0.07}" r="2" opacity="0.7"/>
    <circle cx="{w*0.85}" cy="{h*0.14}" r="2.5" opacity="0.5"/>
    <circle cx="{w*0.95}" cy="{h*0.06}" r="2" opacity="0.6"/>
    <circle cx="{w*0.1}" cy="{h*0.25}" r="2.5" opacity="0.5"/>
    <circle cx="{w*0.3}" cy="{h*0.28}" r="3" opacity="0.4"/>
    <circle cx="{w*0.5}" cy="{h*0.3}" r="2" opacity="0.6"/>
    <circle cx="{w*0.7}" cy="{h*0.22}" r="2.5" opacity="0.5"/>
    <circle cx="{w*0.9}" cy="{h*0.3}" r="2" opacity="0.4"/>
    <circle cx="{w*0.08}" cy="{h*0.4}" r="2" opacity="0.4"/>
    <circle cx="{w*0.22}" cy="{h*0.42}" r="3" opacity="0.3"/>
    <circle cx="{w*0.42}" cy="{h*0.38}" r="2.5" opacity="0.4"/>
    <circle cx="{w*0.62}" cy="{h*0.35}" r="2" opacity="0.5"/>
    <circle cx="{w*0.82}" cy="{h*0.42}" r="3" opacity="0.3"/>
  </g>
  <!-- Street lamp -->
  <g>
    <rect x="{w*0.03}" y="{h*0.42}" width="{w*0.008}" height="{h*0.2}" fill="#3A3A4A"/>
    <circle cx="{w*0.034}" cy="{h*0.42}" r="6" fill="#FFE080" opacity="0.6"/>
    <circle cx="{w*0.034}" cy="{h*0.42}" r="{w*0.03}" fill="#FFE080" opacity="0.08"/>
  </g>
''' + svg_footer()


def gen_galaxy_hilltop(w: int, h: int) -> str:
    """Milky Way arching over a grassy hill."""
    return svg_header(w, h, WALLPAPERS[15][1]) + f'''  <defs>
    <linearGradient id="galaxySky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#05051A"/>
      <stop offset="50%" stop-color="#0A0A30"/>
      <stop offset="100%" stop-color="#151540"/>
    </linearGradient>
    <radialGradient id="milkyWay" cx="50%" cy="40%" r="45%">
      <stop offset="0%" stop-color="{TWILIGHT}" stop-opacity="0.15"/>
      <stop offset="50%" stop-color="{SKY_BLUE}" stop-opacity="0.05"/>
      <stop offset="100%" stop-color="{TWILIGHT}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#galaxySky)"/>
  <!-- Milky Way band (diagonal) -->
  <g transform="rotate(-30,{w*0.5},{h*0.4})">
    <ellipse cx="{w*0.5}" cy="{h*0.4}" rx="{w*0.6}" ry="{h*0.12}" fill="url(#milkyWay)"/>
    <ellipse cx="{w*0.5}" cy="{h*0.4}" rx="{w*0.5}" ry="{h*0.06}" fill="white" opacity="0.03"/>
  </g>
  <!-- Dense star field -->
  <g fill="white">
    <!-- Bright stars -->
    <circle cx="{w*0.08}" cy="{h*0.05}" r="2" opacity="0.8"/>
    <circle cx="{w*0.22}" cy="{h*0.12}" r="2.5" opacity="0.9"/>
    <circle cx="{w*0.45}" cy="{h*0.08}" r="2" opacity="0.7"/>
    <circle cx="{w*0.62}" cy="{h*0.15}" r="3" opacity="0.9"/>
    <circle cx="{w*0.78}" cy="{h*0.05}" r="2" opacity="0.8"/>
    <circle cx="{w*0.92}" cy="{h*0.1}" r="2.5" opacity="0.7"/>
    <circle cx="{w*0.35}" cy="{h*0.25}" r="2" opacity="0.8"/>
    <circle cx="{w*0.55}" cy="{h*0.3}" r="2.5" opacity="0.7"/>
    <circle cx="{w*0.7}" cy="{h*0.22}" r="2" opacity="0.9"/>
    <circle cx="{w*0.15}" cy="{h*0.35}" r="2.5" opacity="0.6"/>
    <circle cx="{w*0.85}" cy="{h*0.32}" r="2" opacity="0.7"/>
    <!-- Medium stars -->
    <circle cx="{w*0.12}" cy="{h*0.18}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.3}" cy="{h*0.06}" r="1.5" opacity="0.5"/>
    <circle cx="{w*0.5}" cy="{h*0.2}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.68}" cy="{h*0.08}" r="1.5" opacity="0.5"/>
    <circle cx="{w*0.82}" cy="{h*0.18}" r="1.5" opacity="0.6"/>
    <circle cx="{w*0.4}" cy="{h*0.35}" r="1.5" opacity="0.5"/>
    <circle cx="{w*0.6}" cy="{h*0.4}" r="1.5" opacity="0.4"/>
    <circle cx="{w*0.25}" cy="{h*0.42}" r="1.5" opacity="0.5"/>
    <circle cx="{w*0.75}" cy="{h*0.38}" r="1.5" opacity="0.4"/>
    <!-- Small dim stars -->
    <circle cx="{w*0.05}" cy="{h*0.15}" r="1" opacity="0.4"/>
    <circle cx="{w*0.18}" cy="{h*0.28}" r="1" opacity="0.3"/>
    <circle cx="{w*0.38}" cy="{h*0.15}" r="1" opacity="0.4"/>
    <circle cx="{w*0.52}" cy="{h*0.38}" r="1" opacity="0.3"/>
    <circle cx="{w*0.72}" cy="{h*0.28}" r="1" opacity="0.4"/>
    <circle cx="{w*0.88}" cy="{h*0.25}" r="1" opacity="0.3"/>
    <circle cx="{w*0.95}" cy="{h*0.38}" r="1" opacity="0.4"/>
    <circle cx="{w*0.42}" cy="{h*0.45}" r="1" opacity="0.3"/>
  </g>
  <!-- Shooting star -->
  <line x1="{w*0.3}" y1="{h*0.1}" x2="{w*0.42}" y2="{h*0.16}" stroke="white" stroke-width="2" opacity="0.7" stroke-linecap="round"/>
  <!-- Grassy hill silhouette -->
  <path d="M0,{h*0.65} Q{w*0.25},{h*0.55} {w*0.5},{h*0.52} Q{w*0.75},{h*0.55} {w},{h*0.6} L{w},{h} L0,{h}Z" fill="#0A0A15"/>
  <!-- Grass tufts on hill edge -->
  <g fill="#0A0A15">
    <path d="M{w*0.3},{h*0.56} L{w*0.305},{h*0.53} L{w*0.31},{h*0.56}Z"/>
    <path d="M{w*0.45},{h*0.53} L{w*0.455},{h*0.50} L{w*0.46},{h*0.53}Z"/>
    <path d="M{w*0.55},{h*0.53} L{w*0.555},{h*0.50} L{w*0.56},{h*0.53}Z"/>
    <path d="M{w*0.65},{h*0.54} L{w*0.655},{h*0.51} L{w*0.66},{h*0.54}Z"/>
    <path d="M{w*0.8},{h*0.57} L{w*0.805},{h*0.54} L{w*0.81},{h*0.57}Z"/>
  </g>
  <!-- Tiny figure silhouette on hilltop -->
  <g fill="#0A0A15" transform="translate({w*0.5},{h*0.50})">
    <circle cx="0" cy="-8" r="4"/>
    <rect x="-3" y="-4" width="6" height="10" rx="2"/>
  </g>
''' + svg_footer()


# Map number to generator function
GENERATORS: dict[int, callable] = {
    1: gen_cherry_blossom_path,
    2: gen_neon_alley,
    3: gen_cloud_ocean,
    4: gen_shrine_steps,
    5: gen_rooftop_sunset,
    6: gen_starfall_lake,
    7: gen_bamboo_forest,
    8: gen_train_window,
    9: gen_lantern_festival,
    10: gen_moon_bridge,
    11: gen_flower_field,
    12: gen_rainy_crosswalk,
    13: gen_island_cove,
    14: gen_snow_village,
    15: gen_galaxy_hilltop,
}


def main() -> None:
    """Generate all anime-inspired wallpapers for phone and desktop."""
    PHONE_DIR.mkdir(parents=True, exist_ok=True)
    DESKTOP_DIR.mkdir(parents=True, exist_ok=True)

    for num, (slug, title) in WALLPAPERS.items():
        gen_func = GENERATORS[num]

        # Phone version (1080x1920)
        phone_svg = gen_func(1080, 1920)
        phone_path = PHONE_DIR / f"{num:02d}-{slug}.svg"
        phone_path.write_text(phone_svg)
        print(f"  Created: src/phone/{phone_path.name}")

        # Desktop version (1920x1080)
        desktop_svg = gen_func(1920, 1080)
        desktop_path = DESKTOP_DIR / f"{num:02d}-{slug}.svg"
        desktop_path.write_text(desktop_svg)
        print(f"  Created: src/desktop/{desktop_path.name}")

    print(f"\nDone! Generated {len(WALLPAPERS)} wallpaper pairs (phone + desktop)")
    print(f"Total files: {len(WALLPAPERS) * 2}")


if __name__ == "__main__":
    main()
