#!/usr/bin/env python3
"""
Grunge Aesthetic Pack — SVG Texture Generator
Generates 8 grunge textures using rect/line elements.
Neon Bazaar / Aesthetic Studio — stdlib only.
"""

import json
import os
import random
import xml.etree.ElementTree as ET

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(SCRIPT_DIR, "texture_data.json")
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "..", "output")

SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)

CANVAS_W = 400
CANVAS_H = 400


def load_data():
    with open(DATA_FILE, "r") as f:
        return json.load(f)


def make_svg_root(w=CANVAS_W, h=CANVAS_H):
    svg = ET.Element("svg", {
        "xmlns": SVG_NS,
        "viewBox": f"0 0 {w} {h}",
        "width": str(w),
        "height": str(h),
    })
    # transparent background
    ET.SubElement(svg, "rect", {
        "width": str(w),
        "height": str(h),
        "fill": "transparent",
    })
    return svg


def rand_range(lo, hi):
    return lo + random.random() * (hi - lo)


def rand_opacity(r):
    return round(rand_range(r[0], r[1]), 3)


# ── Texture generators ──────────────────────────────────────────────

def generate_noise_fine(svg, tex):
    """Dense micro-rectangles for film noise."""
    g = ET.SubElement(svg, "g", {"id": tex["id"]})
    for _ in range(tex["density"]):
        sz = rand_range(*tex["size_range"])
        ET.SubElement(g, "rect", {
            "x": str(round(random.random() * CANVAS_W, 2)),
            "y": str(round(random.random() * CANVAS_H, 2)),
            "width": str(round(sz, 2)),
            "height": str(round(sz, 2)),
            "fill": random.choice(tex["colors"]),
            "opacity": str(rand_opacity(tex["opacity_range"])),
        })


def generate_grain_heavy(svg, tex):
    """Coarse photographic grain."""
    g = ET.SubElement(svg, "g", {"id": tex["id"]})
    for _ in range(tex["density"]):
        sz = rand_range(*tex["size_range"])
        ET.SubElement(g, "rect", {
            "x": str(round(random.random() * CANVAS_W, 2)),
            "y": str(round(random.random() * CANVAS_H, 2)),
            "width": str(round(sz, 2)),
            "height": str(round(sz * rand_range(0.6, 1.4), 2)),
            "fill": random.choice(tex["colors"]),
            "opacity": str(rand_opacity(tex["opacity_range"])),
        })


def generate_scratches_vertical(svg, tex):
    """Vertical film scratches."""
    g = ET.SubElement(svg, "g", {"id": tex["id"]})
    for _ in range(tex["density"]):
        x = round(random.random() * CANVAS_W, 2)
        y1 = round(random.random() * CANVAS_H * 0.3, 2)
        y2 = round(y1 + random.random() * CANVAS_H * 0.7, 2)
        ET.SubElement(g, "line", {
            "x1": str(x), "y1": str(y1),
            "x2": str(round(x + rand_range(-2, 2), 2)), "y2": str(y2),
            "stroke": random.choice(tex["colors"]),
            "stroke-width": str(round(rand_range(*tex["stroke_width_range"]), 2)),
            "opacity": str(rand_opacity(tex["opacity_range"])),
        })


def generate_scratches_random(svg, tex):
    """Random diagonal scratches."""
    g = ET.SubElement(svg, "g", {"id": tex["id"]})
    for _ in range(tex["density"]):
        x1 = round(random.random() * CANVAS_W, 2)
        y1 = round(random.random() * CANVAS_H, 2)
        length = rand_range(20, 120)
        angle = rand_range(0, 3.14159)
        import math
        x2 = round(x1 + length * math.cos(angle), 2)
        y2 = round(y1 + length * math.sin(angle), 2)
        ET.SubElement(g, "line", {
            "x1": str(x1), "y1": str(y1),
            "x2": str(x2), "y2": str(y2),
            "stroke": random.choice(tex["colors"]),
            "stroke-width": str(round(rand_range(*tex["stroke_width_range"]), 2)),
            "opacity": str(rand_opacity(tex["opacity_range"])),
        })


def generate_halftone_dots(svg, tex):
    """Classic halftone dot grid."""
    g = ET.SubElement(svg, "g", {"id": tex["id"]})
    grid = tex["grid_size"]
    for row in range(0, CANVAS_H, grid):
        for col in range(0, CANVAS_W, grid):
            sz = rand_range(*tex["size_range"])
            ET.SubElement(g, "rect", {
                "x": str(col + (grid - sz) / 2),
                "y": str(row + (grid - sz) / 2),
                "width": str(round(sz, 2)),
                "height": str(round(sz, 2)),
                "rx": str(round(sz / 2, 2)),
                "fill": random.choice(tex["colors"]),
                "opacity": str(rand_opacity(tex["opacity_range"])),
            })


def generate_halftone_lines(svg, tex):
    """Horizontal halftone lines."""
    g = ET.SubElement(svg, "g", {"id": tex["id"]})
    spacing = CANVAS_H / tex["line_count"]
    for i in range(tex["line_count"]):
        y = round(i * spacing, 2)
        ET.SubElement(g, "line", {
            "x1": "0", "y1": str(y),
            "x2": str(CANVAS_W), "y2": str(y),
            "stroke": random.choice(tex["colors"]),
            "stroke-width": str(round(rand_range(*tex["stroke_width_range"]), 2)),
            "opacity": str(rand_opacity(tex["opacity_range"])),
        })


def generate_ink_splatter(svg, tex):
    """Ink splatter clusters."""
    g = ET.SubElement(svg, "g", {"id": tex["id"]})
    for _ in range(tex["cluster_count"]):
        cx = random.random() * CANVAS_W
        cy = random.random() * CANVAS_H
        drops = random.randint(5, 20)
        for _ in range(drops):
            sz = rand_range(*tex["size_range"])
            ET.SubElement(g, "rect", {
                "x": str(round(cx + rand_range(-30, 30), 2)),
                "y": str(round(cy + rand_range(-30, 30), 2)),
                "width": str(round(sz, 2)),
                "height": str(round(sz * rand_range(0.5, 1.5), 2)),
                "rx": str(round(sz * 0.3, 2)),
                "fill": random.choice(tex["colors"]),
                "opacity": str(rand_opacity(tex["opacity_range"])),
            })


def generate_distress_mesh(svg, tex):
    """Worn mesh of overlapping thin lines."""
    g = ET.SubElement(svg, "g", {"id": tex["id"]})
    for _ in range(tex["density"]):
        horizontal = random.random() > 0.5
        if horizontal:
            y = round(random.random() * CANVAS_H, 2)
            x1 = round(random.random() * CANVAS_W * 0.3, 2)
            x2 = round(x1 + random.random() * CANVAS_W * 0.7, 2)
            ET.SubElement(g, "line", {
                "x1": str(x1), "y1": str(y),
                "x2": str(x2), "y2": str(round(y + rand_range(-3, 3), 2)),
                "stroke": random.choice(tex["colors"]),
                "stroke-width": str(round(rand_range(*tex["stroke_width_range"]), 2)),
                "opacity": str(rand_opacity(tex["opacity_range"])),
            })
        else:
            x = round(random.random() * CANVAS_W, 2)
            y1 = round(random.random() * CANVAS_H * 0.3, 2)
            y2 = round(y1 + random.random() * CANVAS_H * 0.7, 2)
            ET.SubElement(g, "line", {
                "x1": str(x), "y1": str(y1),
                "x2": str(round(x + rand_range(-3, 3), 2)), "y2": str(y2),
                "stroke": random.choice(tex["colors"]),
                "stroke-width": str(round(rand_range(*tex["stroke_width_range"]), 2)),
                "opacity": str(rand_opacity(tex["opacity_range"])),
            })


GENERATORS = {
    "noise_fine": generate_noise_fine,
    "grain_heavy": generate_grain_heavy,
    "scratches_vertical": generate_scratches_vertical,
    "scratches_random": generate_scratches_random,
    "halftone_dots": generate_halftone_dots,
    "halftone_lines": generate_halftone_lines,
    "ink_splatter": generate_ink_splatter,
    "distress_mesh": generate_distress_mesh,
}


def main():
    random.seed(42)
    data = load_data()
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    for tex in data["textures"]:
        svg = make_svg_root()
        gen_fn = GENERATORS.get(tex["id"])
        if gen_fn:
            gen_fn(svg, tex)
        else:
            print(f"  [skip] No generator for {tex['id']}")
            continue

        tree = ET.ElementTree(svg)
        path = os.path.join(OUTPUT_DIR, f"{tex['id']}.svg")
        ET.indent(tree, space="  ")
        tree.write(path, xml_declaration=True, encoding="utf-8")
        print(f"  [ok] {path}")

    print(f"\nDone — {len(data['textures'])} textures written to {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
