# Cottagecore Wallpaper Pack 🌿

**20 handcrafted SVG wallpapers in the cottagecore aesthetic**

Transform your phone and desktop into a cozy countryside escape. Each wallpaper features
warm earth tones, delicate florals, whimsical mushrooms, fluttering butterflies, and
gentle vine motifs — all rendered as crisp, scalable SVG art that looks perfect on any
screen resolution.

## What's Inside

| # | Wallpaper | Description | Mood |
|---|-----------|-------------|------|
| 1 | Meadow Morning | Wildflowers swaying in golden morning light | Warm, hopeful |
| 2 | Mushroom Hollow | Cluster of toadstools under dappled canopy | Whimsical, earthy |
| 3 | Butterfly Garden | Butterflies dancing among lavender stems | Dreamy, gentle |
| 4 | Vine Trellis | Climbing vines on a rustic wooden lattice | Cozy, structured |
| 5 | Tea & Roses | Steaming teacup surrounded by rose blooms | Comforting, elegant |
| 6 | Forest Floor | Moss, ferns, and tiny wildflowers | Grounded, peaceful |
| 7 | Cottage Window | View through a window with lace curtains | Nostalgic, inviting |
| 8 | Herb Garden | Rosemary, lavender, sage in terracotta pots | Fresh, aromatic |
| 9 | Autumn Harvest | Pumpkins, wheat, and warm falling leaves | Cozy, seasonal |
| 10 | Pressed Flowers | Botanical specimens on aged paper | Vintage, scholarly |
| 11 | Honeybee Path | Bees hovering over clover and wildflowers | Sweet, alive |
| 12 | Rainy Window | Raindrops on glass, garden blur beyond | Contemplative, calm |
| 13 | Woven Basket | Wicker texture with dried flowers overflowing | Handmade, organic |
| 14 | Sunset Meadow | Pink-gold sunset over rolling green hills | Romantic, vast |
| 15 | Fairy Ring | Circle of mushrooms in moonlit clearing | Magical, mysterious |
| 16 | Lavender Fields | Rows of purple stretching to horizon | Serene, fragrant |
| 17 | Berry Picking | Blackberry brambles heavy with fruit | Abundant, sweet |
| 18 | Morning Dew | Close-up dewdrops on petals and leaves | Fresh, delicate |
| 19 | Cottage Door | Arched wooden door with climbing roses | Welcoming, charming |
| 20 | Starlit Garden | Night garden with fireflies and moonflowers | Magical, peaceful |

## Color Palette

```
┌──────────┬──────────┬──────────┬──────────┬──────────┬──────────┐
│ Walnut   │ Wheat    │ Cream    │ Sage     │ Terracotta│ Linen   │
│ #8B7355  │ #C5A880  │ #E8D5B7  │ #97B07A  │ #D4956A  │ #F5E6CC │
└──────────┴──────────┴──────────┴──────────┴──────────┴──────────┘
```

## File Structure

```
src/
├── phone/              # 1080x2340 (9:19.5 aspect ratio)
│   ├── 01-meadow-morning.svg
│   ├── 02-mushroom-hollow.svg
│   ├── ... (20 files)
│   └── 20-starlit-garden.svg
└── desktop/            # 1920x1080 (16:9 aspect ratio)
    ├── 01-meadow-morning.svg
    ├── 02-mushroom-hollow.svg
    ├── ... (20 files)
    └── 20-starlit-garden.svg

preview/
└── gallery.html        # Visual gallery of all wallpapers

demo/
└── phone-mockup.html   # See wallpapers on a realistic phone frame
```

## How to Use

1. **Phone wallpaper**: Open any SVG from `src/phone/` and screenshot or save as PNG at your phone's resolution
2. **Desktop wallpaper**: Open any SVG from `src/desktop/` and save/screenshot at your monitor's resolution
3. **Custom resolution**: SVG files scale to ANY size — edit the `viewBox` or resize in any image editor
4. **Preview all**: Open `preview/gallery.html` in your browser to see every wallpaper at a glance

## Tips

- SVG files can be opened in any modern browser (Chrome, Safari, Firefox, Edge)
- To convert to PNG: open the SVG in your browser, right-click → "Save image as..."
- For the crispest results, set your phone/desktop resolution as the export size
- Colors can be customized by editing the SVG in any text editor — hex values are clearly labeled

## License

MIT License — use these wallpapers on your own devices, share with friends, or use as
inspiration for your own art. See LICENSE file for full terms.
