# Y2K Widget Theme

**15 retro-futuristic widget designs for phone customization**

Chrome gradients, holographic glows, pixel fonts, and bubble shapes — straight
from the early 2000s internet. Includes clock widgets, weather widgets, music
players, battery indicators, and more. All in SVG for crisp scaling.

## What's Inside

| Category | Count | Widgets |
|----------|-------|---------|
| Time & Date | 3 | Digital clock, analog clock, calendar widget |
| Info | 3 | Weather widget, battery indicator, steps counter |
| Media | 3 | Music player, playlist card, podcast widget |
| Social | 3 | Quote of the day, affirmation card, countdown timer |
| Utility | 3 | Quick notes, shortcut grid, search bar |

## Color Palette

```
+-----------+-----------+-----------+-----------+-----------+-----------+
| Hot Pink  | Chrome    | Lilac     | Aqua      | Cyber Lime| Holo      |
| #FF69B4   | #C0C0C0   | #DDA0DD   | #00CED1   | #ADFF2F   | #E6E6FA   |
+-----------+-----------+-----------+-----------+-----------+-----------+
```

## File Structure

```
src/
├── widget_data.json        # Widget metadata (names, types, sizes)
└── generate_widgets.py     # Generate all 15 SVG widget designs

demo/
└── index.html              # Phone screen mockup with widgets placed

preview/
└── index.html              # Grid gallery of all widget designs
```

## How to Use

1. **Preview all**: Open `preview/index.html` to see all 15 widget designs
2. **Phone mockup**: Open `demo/index.html` to see widgets on a simulated home screen
3. **Generate SVGs**: Run `python3 src/generate_widgets.py` to create individual SVGs
4. **Customize**: Use as inspiration for Widgetsmith, KWGT, or custom widgets

## Tips

- These are design templates — use as visual reference for widget customization apps
- Pair with the Neon Glow Icon Set for a complete Y2K phone setup
- Edit SVG colors to match your own Y2K palette
- Works great as lock screen widgets on iOS 16+ or Android KWGT

## License

MIT License — use these widget designs for your phone, projects, or inspiration.
See LICENSE file for full terms.
