#!/usr/bin/env python3
"""
Neon Glow Icon Set — SVG Icon Generator
Generates 30 SVG icons with feGaussianBlur glow filters.
Neon Bazaar / Aesthetic Studio — stdlib only.
"""

import json
import os
import xml.etree.ElementTree as ET

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(SCRIPT_DIR, "icon_data.json")
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "..", "output")

SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)


def load_data():
    with open(DATA_FILE, "r") as f:
        return json.load(f)


def create_glow_filter(svg, filter_id, color, blur=6, opacity=0.8):
    """Create an SVG filter with feGaussianBlur for neon glow."""
    defs = ET.SubElement(svg, "defs")
    filt = ET.SubElement(defs, "filter", {
        "id": filter_id,
        "x": "-50%", "y": "-50%",
        "width": "200%", "height": "200%",
    })
    # Colored flood for glow
    ET.SubElement(filt, "feFlood", {
        "flood-color": color,
        "flood-opacity": str(opacity),
        "result": "flood",
    })
    # Composite with source graphic to get shape
    ET.SubElement(filt, "feComposite", {
        "in": "flood",
        "in2": "SourceGraphic",
        "operator": "in",
        "result": "colored",
    })
    # Blur the colored shape
    ET.SubElement(filt, "feGaussianBlur", {
        "in": "colored",
        "stdDeviation": str(blur),
        "result": "blur",
    })
    # Outer glow (larger blur)
    ET.SubElement(filt, "feGaussianBlur", {
        "in": "colored",
        "stdDeviation": str(blur * 2),
        "result": "blur_outer",
    })
    # Merge: outer glow + inner glow + original
    merge = ET.SubElement(filt, "feMerge")
    ET.SubElement(merge, "feMergeNode", {"in": "blur_outer"})
    ET.SubElement(merge, "feMergeNode", {"in": "blur"})
    ET.SubElement(merge, "feMergeNode", {"in": "SourceGraphic"})
    return filter_id


def generate_icon_svg(icon, color, size=120, blur=6):
    """Generate a single icon SVG with neon glow."""
    svg = ET.Element("svg", {
        "xmlns": SVG_NS,
        "viewBox": f"0 0 {size} {size}",
        "width": str(size),
        "height": str(size),
    })

    filter_id = f"glow-{icon['id']}"
    create_glow_filter(svg, filter_id, color, blur)

    # Dark background
    ET.SubElement(svg, "rect", {
        "width": str(size),
        "height": str(size),
        "fill": "#0a0a12",
        "rx": "12",
    })

    # Icon path with glow
    ET.SubElement(svg, "path", {
        "d": icon["path"],
        "fill": "none",
        "stroke": color,
        "stroke-width": "2.5",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "filter": f"url(#{filter_id})",
    })

    return svg


def main():
    data = load_data()
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    total = 0
    for cat in data["categories"]:
        color = cat["color"]
        cat_dir = os.path.join(OUTPUT_DIR, cat["name"].lower())
        os.makedirs(cat_dir, exist_ok=True)

        for icon in cat["icons"]:
            svg = generate_icon_svg(
                icon, color,
                size=data.get("icon_size", 120),
                blur=data.get("glow_blur", 6),
            )
            tree = ET.ElementTree(svg)
            path = os.path.join(cat_dir, f"{icon['id']}.svg")
            ET.indent(tree, space="  ")
            tree.write(path, xml_declaration=True, encoding="utf-8")
            total += 1
            print(f"  [ok] {cat['name']}/{icon['id']}.svg")

    print(f"\nDone — {total} neon icons written to {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
