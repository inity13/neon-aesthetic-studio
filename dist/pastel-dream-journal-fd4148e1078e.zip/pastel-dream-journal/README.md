# Pastel Dream Journal

**12 printable/digital journal page templates in pastel aesthetics**

Soft pinks, lavenders, mints, and buttercreams — each page is a calming canvas
for your thoughts. Includes daily planners, gratitude logs, habit trackers, mood
charts, and freewrite pages. SVG format for crisp printing at any size.

## What's Inside

| # | Page Template | Type | Description |
|---|---------------|------|-------------|
| 1 | Daily Planner | Planner | Time-blocked daily schedule with priorities |
| 2 | Gratitude Log | Journal | 3 things grateful for + daily affirmation |
| 3 | Habit Tracker | Tracker | 30-day grid for up to 10 habits |
| 4 | Mood Chart | Tracker | Monthly mood tracking with color legend |
| 5 | Brain Dump | Freewrite | Unstructured thought capture page |
| 6 | Goal Setter | Planner | Monthly goals with milestones |
| 7 | Weekly Overview | Planner | Week-at-a-glance with notes section |
| 8 | Reading List | Tracker | Book tracker with rating and review |
| 9 | Self Care Checklist | Wellness | Daily self-care activities to check off |
| 10 | Dream Log | Journal | Space to record and reflect on dreams |
| 11 | Letter to Future Me | Journal | Prompted letter to your future self |
| 12 | Monthly Reflection | Journal | Month-end review with highs, lows, lessons |

## Color Palette

```
+-----------+-----------+-----------+-----------+-----------+-----------+
| Rose      | Lavender  | Mint      | Butter    | Cloud     | Pearl     |
| #F4B4C6   | #C8B8DB   | #B8E0D2   | #F6E4B8   | #E8E0F0   | #F5F0EB   |
+-----------+-----------+-----------+-----------+-----------+-----------+
```

## File Structure

```
src/
├── templates.json          # Page template metadata and configurations
└── generate_pages.py       # Generate all 12 SVG journal pages

demo/
└── index.html              # Interactive page viewer with "fill in" preview

preview/
└── index.html              # Gallery of all page templates
```

## How to Use

1. **Preview all**: Open `preview/index.html` to see all 12 templates
2. **Interactive demo**: Open `demo/index.html` to preview with sample content
3. **Generate SVGs**: Run `python3 src/generate_pages.py` to create individual SVG pages
4. **Print**: Open SVGs in browser, use Ctrl+P / Cmd+P, set to "fit to page"
5. **Digital use**: Import SVGs into GoodNotes, Notability, or any PDF annotation app

## Tips

- Print on good paper (120gsm+) for the best feel
- Use in digital planners by importing SVG as image layers
- Edit colors in the SVG to match your own pastel palette
- A5 and A4 sizes both work — SVGs scale to fit

## License

MIT License — print, use digitally, or share with friends.
See LICENSE file for full terms.
