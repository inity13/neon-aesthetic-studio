#!/usr/bin/env python3
"""
Aesthetic Color Palettes — Swatch Generator
Generates SVG swatch cards for each palette defined in palettes.json.
Uses Python stdlib only — no external dependencies.
"""

import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

BASE = Path(__file__).parent
PALETTES_FILE = BASE / "palettes.json"
OUTPUT_DIR = BASE / "swatches"


def load_palettes():
    with open(PALETTES_FILE, "r") as f:
        return json.load(f)["palettes"]


def generate_swatch_svg(palette):
    """Generate an SVG swatch card for a single palette."""
    colors = palette["colors"]
    n = len(colors)
    swatch_w = 80
    swatch_h = 80
    gap = 10
    padding = 20
    header_h = 50

    total_w = padding * 2 + n * swatch_w + (n - 1) * gap
    total_h = header_h + padding * 2 + swatch_h + 40  # 40 for labels

    svg = ET.Element("svg", xmlns="http://www.w3.org/2000/svg",
                     viewBox=f"0 0 {total_w} {total_h}")

    # Background
    ET.SubElement(svg, "rect", width=str(total_w), height=str(total_h),
                  rx="12", fill="#1a1a2e")

    # Title
    title = ET.SubElement(svg, "text", x=str(padding), y="35",
                          fill="#E8E0F0")
    title.set("font-family", "sans-serif")
    title.set("font-size", "20")
    title.set("font-weight", "bold")
    title.text = palette["name"]

    # Description
    desc = ET.SubElement(svg, "text", x=str(total_w - padding), y="35",
                         fill="#888")
    desc.set("font-family", "sans-serif")
    desc.set("font-size", "12")
    desc.set("text-anchor", "end")
    desc.text = palette["description"]

    # Color swatches
    for i, color in enumerate(colors):
        x = padding + i * (swatch_w + gap)
        y = header_h + padding

        # Swatch rectangle
        ET.SubElement(svg, "rect", x=str(x), y=str(y),
                      width=str(swatch_w), height=str(swatch_h),
                      rx="8", fill=color["hex"])

        # Color name
        label = ET.SubElement(svg, "text",
                              x=str(x + swatch_w // 2),
                              y=str(y + swatch_h + 16),
                              fill="#ccc")
        label.set("font-family", "sans-serif")
        label.set("font-size", "10")
        label.set("text-anchor", "middle")
        label.text = color["name"]

        # Hex value
        hexlabel = ET.SubElement(svg, "text",
                                 x=str(x + swatch_w // 2),
                                 y=str(y + swatch_h + 30),
                                 fill="#888")
        hexlabel.set("font-family", "monospace")
        hexlabel.set("font-size", "9")
        hexlabel.set("text-anchor", "middle")
        hexlabel.text = color["hex"]

    return ET.tostring(svg, encoding="unicode", xml_declaration=False)


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    palettes = load_palettes()

    for palette in palettes:
        slug = palette["name"].lower().replace(" ", "-")
        filename = f"{palette['id']:02d}-{slug}.svg"
        filepath = OUTPUT_DIR / filename

        svg_content = '<?xml version="1.0" encoding="UTF-8"?>\n'
        svg_content += generate_swatch_svg(palette)

        with open(filepath, "w") as f:
            f.write(svg_content)

        print(f"  Generated: {filename} ({len(palette['colors'])} colors)")

    print(f"\nDone! {len(palettes)} swatch cards saved to {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
