# Grunge Aesthetic Pack

**20 grunge textures, overlays, and backgrounds in SVG**

Distressed paper, ink splatter, torn edges, noise grain, and gritty patterns —
all rendered as scalable SVG for clean grunge that doesn't pixelate. Layer these
over photos, use as phone wallpapers, or add raw texture to your digital art.

## What's Inside

| Category | Count | Examples |
|----------|-------|----------|
| Paper Textures | 5 | Crumpled, stained, torn edge, aged, newsprint |
| Splatter & Ink | 5 | Paint splatter, ink drip, brush stroke, spray, bleed |
| Noise & Grain | 5 | Film grain, static, halftone dots, cross-hatch, distress |
| Patterns | 5 | Checkerboard fade, stripe decay, mesh tear, crack web, rust |

## Color Palette

```
+-----------+-----------+-----------+-----------+-----------+-----------+
| Charcoal  | Rust      | Army      | Cream     | Blood     | Storm     |
| #2C2C2C   | #8B4513   | #556B2F   | #D4C5A9   | #8B0000   | #4A4A5A   |
+-----------+-----------+-----------+-----------+-----------+-----------+
```

## File Structure

```
src/
├── texture_data.json       # Texture metadata (names, categories, descriptions)
└── generate_textures.py    # Generate all 20 SVG textures

demo/
└── index.html              # Layer preview — stack textures over sample images

preview/
└── index.html              # Grid gallery of all textures
```

## How to Use

1. **Preview all**: Open `preview/index.html` to browse all textures
2. **Layer demo**: Open `demo/index.html` to see textures layered over sample content
3. **Generate SVGs**: Run `python3 src/generate_textures.py` to create individual SVGs
4. **Mix & layer**: Use multiply or overlay blend modes for best results

## Tips

- Set SVG opacity to 20-50% when layering for subtle grunge effects
- Combine multiple textures for unique distressed looks
- Works great as Instagram story backgrounds or phone wallpapers
- Edit the SVG directly to change colors or intensity

## License

MIT License — use these textures freely in your projects and art.
See LICENSE file for full terms.
