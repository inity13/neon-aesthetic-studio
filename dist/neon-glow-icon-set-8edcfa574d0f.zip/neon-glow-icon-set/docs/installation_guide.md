# Neon Glow Icon Set — Installation Guide

How to use these SVG icons as custom app icons on your phone, tablet, or desktop.

## iOS (iPhone / iPad)

### Using the Shortcuts App

1. Open the **Shortcuts** app (built into iOS)
2. Tap **+** to create a new shortcut
3. Tap **Add Action** → search for **Open App** → select the app
4. Tap the **name** at the top → **Add to Home Screen**
5. Tap the icon preview → **Choose File**
6. Navigate to the saved SVG icon (or screenshot/PNG export)
7. Name your shortcut (e.g., "Instagram") → tap **Add**

### Tips for iOS

- iOS works best with PNG icons (180x180px or larger)
- To convert SVG to PNG: Open the SVG in Safari, take a screenshot, crop
- Alternatively, use the free app **Icon Themer** for batch conversion
- The original app icon will still appear in App Library

---

## Android

### Using KWGT / Nova Launcher

1. Install **Nova Launcher** (free) + **KWGT Widget Maker** (free)
2. Long-press home screen → **Widgets** → add a KWGT widget
3. In KWGT editor, add an **Image** element → load the SVG
4. Save and resize the widget to icon size

### Using Icon Pack Studio

1. Install **Icon Pack Studio** from Play Store
2. Create a new icon pack → import SVG files
3. Apply via your launcher's icon settings

### Direct Method (Most Launchers)

1. Long-press any app icon → **Edit** (or app info)
2. Tap the icon → **Gallery** → select saved icon image
3. Most launchers (Nova, Lawnchair, Action Launcher) support this

### Tips for Android

- Android launchers handle SVGs differently — PNG may be more reliable
- Recommended PNG size: 192x192px
- Use **Tasker** + **AutoTools** for automated icon theming

---

## Desktop

### macOS

1. Open the SVG in Preview or any image viewer
2. Export/save as PNG (512x512px recommended)
3. Right-click the app in Finder → **Get Info**
4. Drag the PNG onto the icon in the top-left of the Info window

### Windows

1. Convert SVG to ICO using an online converter or GIMP
2. Right-click the shortcut → **Properties** → **Change Icon**
3. Browse to the .ico file → **Apply**

### Linux

1. Save SVG icons to `~/.local/share/icons/neon-glow/`
2. Edit the `.desktop` file for the app:
   ```
   Icon=/home/user/.local/share/icons/neon-glow/icon-name.svg
   ```
3. Most Linux DEs (GNOME, KDE) support SVG icons directly

---

## Batch Export to PNG

If you need PNG versions of all icons, run the generator first, then use
ImageMagick (or rsvg-convert) to batch convert:

```bash
# Generate all SVGs
python3 src/generate_neon_icons.py

# Convert to PNG with ImageMagick
for f in output/**/*.svg; do
  convert -background none -resize 180x180 "$f" "${f%.svg}.png"
done
```

Or use `rsvg-convert`:

```bash
for f in output/**/*.svg; do
  rsvg-convert -w 180 -h 180 "$f" -o "${f%.svg}.png"
done
```

---

## Color Matching

Each category uses a different neon color. When setting up your home screen,
try grouping apps by color for a cohesive look:

| Category   | Color      | Best For                        |
|------------|------------|---------------------------------|
| Social     | `#FF1493`  | Instagram, TikTok, Snapchat     |
| Tech       | `#00FFFF`  | Settings, Files, Calculator     |
| Nature     | `#8B00FF`  | Weather, Health, Meditation     |
| Symbols    | `#39FF14`  | Utilities, Reminders, Clock     |
| Lifestyle  | `#FF6600`  | Shopping, Music, Food apps      |

---

*Neon Bazaar / Aesthetic Studio*
