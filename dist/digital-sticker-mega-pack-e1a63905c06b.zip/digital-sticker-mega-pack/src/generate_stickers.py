#!/usr/bin/env python3
"""
Digital Sticker Mega Pack Generator
Generates 52 kawaii-style SVG stickers.
Uses Python stdlib only — no external dependencies.

Each sticker is 200x200 with rounded kawaii style, soft pastel colors.
"""

import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

BASE = Path(__file__).parent
STICKER_DATA = BASE / "sticker_data.json"
OUTPUT_DIR = BASE / "stickers"

# Palette
BLUSH = "#FFB5C5"
LAVENDER = "#C5A3D9"
MINT = "#A8E6CF"
BUTTER = "#FFE5A0"
PEACH = "#FFCBA4"
SKY = "#B5D8F7"

S = 200  # sticker size


def svg_root():
    return ET.Element("svg", xmlns="http://www.w3.org/2000/svg",
                      viewBox=f"0 0 {S} {S}", width=str(S), height=str(S))


def to_string(svg):
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(svg, encoding="unicode")


def kawaii_face(g, cx, cy, size=1.0):
    """Add a cute kawaii face (eyes + blush + smile)."""
    s = size
    # Eyes
    ET.SubElement(g, "ellipse", cx=str(cx - 12 * s), cy=str(cy), rx=str(4 * s), ry=str(5 * s), fill="#333")
    ET.SubElement(g, "ellipse", cx=str(cx + 12 * s), cy=str(cy), rx=str(4 * s), ry=str(5 * s), fill="#333")
    # Eye highlights
    ET.SubElement(g, "circle", cx=str(cx - 10 * s), cy=str(cy - 2 * s), r=str(1.5 * s), fill="white")
    ET.SubElement(g, "circle", cx=str(cx + 14 * s), cy=str(cy - 2 * s), r=str(1.5 * s), fill="white")
    # Blush
    ET.SubElement(g, "ellipse", cx=str(cx - 20 * s), cy=str(cy + 8 * s), rx=str(6 * s), ry=str(3 * s), fill="#FFB5C5", opacity="0.5")
    ET.SubElement(g, "ellipse", cx=str(cx + 20 * s), cy=str(cy + 8 * s), rx=str(6 * s), ry=str(3 * s), fill="#FFB5C5", opacity="0.5")
    # Smile
    ET.SubElement(g, "path", d=f"M{cx - 8 * s},{cy + 10 * s} Q{cx},{cy + 18 * s} {cx + 8 * s},{cy + 10 * s}",
                  fill="none", stroke="#333", **{"stroke-width": str(1.5 * s), "stroke-linecap": "round"})


def gen_kawaii_animal(slug, color):
    """Generate a kawaii animal sticker."""
    svg = svg_root()
    g = ET.SubElement(svg, "g")

    shapes = {
        "bear": lambda: [
            ET.SubElement(g, "circle", cx="100", cy="110", r="60", fill=color),
            ET.SubElement(g, "circle", cx="65", cy="60", r="20", fill=color),
            ET.SubElement(g, "circle", cx="135", cy="60", r="20", fill=color),
            ET.SubElement(g, "circle", cx="65", cy="60", r="12", fill="#fff", opacity="0.5"),
            ET.SubElement(g, "circle", cx="135", cy="60", r="12", fill="#fff", opacity="0.5"),
            kawaii_face(g, 100, 105)
        ],
        "bunny": lambda: [
            ET.SubElement(g, "ellipse", cx="100", cy="120", rx="50", ry="55", fill=color),
            ET.SubElement(g, "ellipse", cx="80", cy="40", rx="14", ry="40", fill=color),
            ET.SubElement(g, "ellipse", cx="120", cy="40", rx="14", ry="40", fill=color),
            ET.SubElement(g, "ellipse", cx="80", cy="40", rx="8", ry="30", fill="#fff", opacity="0.4"),
            ET.SubElement(g, "ellipse", cx="120", cy="40", rx="8", ry="30", fill="#fff", opacity="0.4"),
            kawaii_face(g, 100, 115)
        ],
        "cat": lambda: [
            ET.SubElement(g, "circle", cx="100", cy="110", r="55", fill=color),
            ET.SubElement(g, "path", d="M60,75 L55,35 L85,65 Z", fill=color),
            ET.SubElement(g, "path", d="M140,75 L145,35 L115,65 Z", fill=color),
            kawaii_face(g, 100, 108),
            ET.SubElement(g, "path", d="M93,120 L100,125 L107,120", fill="none", stroke="#333", **{"stroke-width": "1.5"})
        ],
    }

    # Default round shape for animals without specific shapes
    default = lambda: [
        ET.SubElement(g, "circle", cx="100", cy="110", r="60", fill=color),
        kawaii_face(g, 100, 108)
    ]

    gen = shapes.get(slug, default)
    gen()
    return to_string(svg)


def gen_celestial(slug, color):
    """Generate a celestial sticker."""
    svg = svg_root()
    g = ET.SubElement(svg, "g")

    if slug == "crescent-moon":
        ET.SubElement(g, "circle", cx="100", cy="100", r="60", fill=color)
        ET.SubElement(g, "circle", cx="120", cy="80", r="50", fill="#0a0a12")
        kawaii_face(g, 85, 105, 0.8)
    elif slug == "sparkle-star":
        ET.SubElement(g, "path", d="M100,20 L115,80 L180,100 L115,120 L100,180 L85,120 L20,100 L85,80 Z", fill=color)
        kawaii_face(g, 100, 100, 0.8)
    elif slug == "happy-cloud":
        ET.SubElement(g, "ellipse", cx="100", cy="110", rx="70", ry="40", fill=color)
        ET.SubElement(g, "circle", cx="70", cy="90", r="30", fill=color)
        ET.SubElement(g, "circle", cx="110", cy="80", r="35", fill=color)
        ET.SubElement(g, "circle", cx="140", cy="95", r="25", fill=color)
        kawaii_face(g, 100, 110, 0.8)
    elif slug == "rainbow":
        for i, c in enumerate(["#FFB5C5", "#FFE5A0", "#A8E6CF", "#B5D8F7", "#C5A3D9"]):
            r = 70 - i * 12
            ET.SubElement(g, "path", d=f"M{100 - r},140 A{r},{r} 0 0 1 {100 + r},140",
                          fill="none", stroke=c, **{"stroke-width": "10"})
    elif slug == "sunshine":
        ET.SubElement(g, "circle", cx="100", cy="100", r="40", fill=color)
        for i in range(8):
            import math
            angle = math.radians(i * 45)
            x1, y1 = 100 + 50 * math.cos(angle), 100 + 50 * math.sin(angle)
            x2, y2 = 100 + 70 * math.cos(angle), 100 + 70 * math.sin(angle)
            ET.SubElement(g, "line", x1=f"{x1:.0f}", y1=f"{y1:.0f}", x2=f"{x2:.0f}", y2=f"{y2:.0f}",
                          stroke=color, **{"stroke-width": "6", "stroke-linecap": "round"})
        kawaii_face(g, 100, 100, 0.7)
    else:
        ET.SubElement(g, "circle", cx="100", cy="100", r="50", fill=color)
        kawaii_face(g, 100, 100, 0.7)

    return to_string(svg)


def gen_food(slug, color):
    """Generate a food/drink sticker."""
    svg = svg_root()
    g = ET.SubElement(svg, "g")

    if slug == "boba-tea":
        ET.SubElement(g, "rect", x="55", y="50", width="90", height="120", rx="15", fill=color, opacity="0.7")
        ET.SubElement(g, "rect", x="55", y="50", width="90", height="30", rx="15", fill=color)
        ET.SubElement(g, "rect", x="93", y="20", width="14", height="35", rx="7", fill="#ccc")
        # Boba pearls
        for bx, by in [(75, 140), (90, 150), (105, 145), (120, 140), (85, 130), (110, 135)]:
            ET.SubElement(g, "circle", cx=str(bx), cy=str(by), r="6", fill="#5C4033")
        kawaii_face(g, 100, 95, 0.7)
    elif slug == "cupcake":
        ET.SubElement(g, "path", d="M60,110 L75,170 L125,170 L140,110 Z", fill=PEACH)
        ET.SubElement(g, "ellipse", cx="100", cy="100", rx="50", ry="30", fill=color)
        ET.SubElement(g, "circle", cx="100", cy="75", r="8", fill="#FF6B6B")
        kawaii_face(g, 100, 100, 0.6)
    elif slug == "strawberry":
        ET.SubElement(g, "path", d="M100,170 Q60,120 70,80 Q80,50 100,45 Q120,50 130,80 Q140,120 100,170 Z", fill=color)
        ET.SubElement(g, "path", d="M85,50 L100,35 L115,50 Z", fill=MINT)
        kawaii_face(g, 100, 100, 0.6)
    else:
        ET.SubElement(g, "circle", cx="100", cy="100", r="55", fill=color)
        kawaii_face(g, 100, 100, 0.7)

    return to_string(svg)


def gen_quote(slug, name, color):
    """Generate a quote/label sticker."""
    svg = svg_root()
    g = ET.SubElement(svg, "g")

    ET.SubElement(g, "rect", x="15", y="60", width="170", height="80", rx="40", fill=color)

    text = ET.SubElement(g, "text", x="100", y="108", fill="#333")
    text.set("font-family", "sans-serif")
    text.set("font-size", "18")
    text.set("font-weight", "bold")
    text.set("text-anchor", "middle")
    text.text = name

    return to_string(svg)


def gen_frame(slug, color):
    """Generate a frame/border sticker."""
    svg = svg_root()
    g = ET.SubElement(svg, "g")

    if slug == "heart-frame":
        ET.SubElement(g, "path",
                      d="M100,160 Q40,120 40,80 Q40,40 70,40 Q100,40 100,70 Q100,40 130,40 Q160,40 160,80 Q160,120 100,160 Z",
                      fill="none", stroke=color, **{"stroke-width": "6"})
    elif slug == "cloud-frame":
        ET.SubElement(g, "ellipse", cx="100", cy="100", rx="80", ry="50", fill="none", stroke=color, **{"stroke-width": "6"})
        ET.SubElement(g, "circle", cx="50", cy="90", r="25", fill="none", stroke=color, **{"stroke-width": "6"})
        ET.SubElement(g, "circle", cx="90", cy="60", r="30", fill="none", stroke=color, **{"stroke-width": "6"})
        ET.SubElement(g, "circle", cx="130", cy="70", r="25", fill="none", stroke=color, **{"stroke-width": "6"})
    elif slug == "star-frame":
        ET.SubElement(g, "path",
                      d="M100,15 L120,75 L185,75 L130,110 L150,170 L100,135 L50,170 L70,110 L15,75 L80,75 Z",
                      fill="none", stroke=color, **{"stroke-width": "5"})
    elif slug == "ribbon-banner":
        ET.SubElement(g, "path", d="M20,80 L35,70 L35,130 L20,120 Z", fill=color, opacity="0.7")
        ET.SubElement(g, "rect", x="35", y="70", width="130", height="60", rx="5", fill=color)
        ET.SubElement(g, "path", d="M180,80 L165,70 L165,130 L180,120 Z", fill=color, opacity="0.7")
    else:
        ET.SubElement(g, "rect", x="20", y="20", width="160", height="160", rx="20",
                      fill="none", stroke=color, **{"stroke-width": "5"})

    return to_string(svg)


def gen_decorative(slug, color):
    """Generate a decorative sticker."""
    svg = svg_root()
    g = ET.SubElement(svg, "g")

    if slug == "sparkles":
        for sx, sy, sr in [(60, 50, 15), (140, 40, 10), (100, 100, 20), (50, 140, 12), (150, 130, 14)]:
            ET.SubElement(g, "path",
                          d=f"M{sx},{sy - sr} L{sx + sr * 0.3},{sy} L{sx},{sy + sr} L{sx - sr * 0.3},{sy} Z",
                          fill=color)
    elif slug == "hearts":
        for hx, hy, hs in [(60, 60, 0.5), (140, 50, 0.4), (100, 110, 0.7), (50, 150, 0.35), (150, 140, 0.45)]:
            ET.SubElement(g, "path",
                          d=f"M{hx},{hy + 15 * hs} Q{hx - 20 * hs},{hy - 5 * hs} {hx},{hy - 10 * hs} Q{hx + 20 * hs},{hy - 5 * hs} {hx},{hy + 15 * hs} Z",
                          fill=color)
    elif slug == "bow":
        ET.SubElement(g, "path", d="M100,100 Q60,60 40,80 Q20,100 60,100 Z", fill=color)
        ET.SubElement(g, "path", d="M100,100 Q140,60 160,80 Q180,100 140,100 Z", fill=color)
        ET.SubElement(g, "circle", cx="100", cy="100", r="12", fill=color)
        ET.SubElement(g, "path", d="M90,110 Q95,150 90,170", fill="none", stroke=color, **{"stroke-width": "4"})
        ET.SubElement(g, "path", d="M110,110 Q105,150 110,170", fill="none", stroke=color, **{"stroke-width": "4"})
    else:
        ET.SubElement(g, "circle", cx="100", cy="100", r="50", fill=color, opacity="0.6")
        ET.SubElement(g, "circle", cx="100", cy="100", r="35", fill=color, opacity="0.4")

    return to_string(svg)


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    with open(STICKER_DATA, "r") as f:
        data = json.load(f)

    count = 0
    for category in data["categories"]:
        cat_name = category["name"]
        for sticker in category["stickers"]:
            sid = sticker["id"]
            slug = sticker["slug"]
            name = sticker["name"]
            color = sticker["color"]
            filename = f"{sid:02d}-{slug}.svg"

            if cat_name == "Kawaii Animals":
                svg = gen_kawaii_animal(slug, color)
            elif cat_name == "Celestial":
                svg = gen_celestial(slug, color)
            elif cat_name == "Food & Drinks":
                svg = gen_food(slug, color)
            elif cat_name == "Quotes & Labels":
                svg = gen_quote(slug, name, color)
            elif cat_name == "Frames & Borders":
                svg = gen_frame(slug, color)
            elif cat_name == "Decorative":
                svg = gen_decorative(slug, color)
            else:
                continue

            with open(OUTPUT_DIR / filename, "w") as f:
                f.write(svg)

            count += 1
            print(f"  Generated: {filename} — {name}")

    print(f"\nDone! {count} stickers saved to {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
