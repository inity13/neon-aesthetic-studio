# Included Products

## Aesthetic Starter Bundle — 3 Products

1. **Aesthetic Color Palettes** ($1)
   - 10 curated color palettes for every aesthetic
   - Cottagecore, Dark Academia, Y2K, Pastel, Neon, Grunge, and more
   - JSON data + SVG swatch generator + interactive preview

2. **Neon Glow Icon Set** ($3)
   - 30 SVG icons with neon glow filter effects
   - Social, Tech, Nature, Symbols, Lifestyle categories
   - Hot Pink, Cyan, Violet, Lime, Orange, Ice Blue color options

3. **Pastel Dream Journal** ($3)
   - 12 printable/digital journal page templates
   - Daily planner, gratitude log, habit tracker, mood chart, and more
   - SVG format for crisp printing at any size

---

**Total individual value: $7**
**Bundle price: $9** (premium bundle with all extras)
