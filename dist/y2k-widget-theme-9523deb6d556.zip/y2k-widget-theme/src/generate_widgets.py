#!/usr/bin/env python3
"""Y2K Widget Theme — SVG Widget Mockup Generator

Reads widget_data.json and generates one SVG file per widget.
Uses only stdlib (xml.etree.ElementTree).

Y2K aesthetic: chrome gradients, glitter dots, butterfly silhouettes,
star decorations, holographic rainbow effect, metallic glow filters.
"""

import json
import math
import os
import random
import xml.etree.ElementTree as ET

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(SCRIPT_DIR, "widget_data.json")
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "widgets")

NS = "http://www.w3.org/2000/svg"

# Seed for reproducible glitter placement
random.seed(2000)


# ── SVG helpers ──────────────────────────────────────────────────────────

def _svg_root(w, h):
    svg = ET.Element("svg", xmlns=NS, width=str(w), height=str(h),
                     viewBox=f"0 0 {w} {h}")
    return svg


def _add_defs(svg, widget):
    """Add reusable gradient/filter definitions based on widget's y2k_elements."""
    defs = ET.SubElement(svg, "defs")

    # Chrome gradient (silver metallic)
    if "chrome" in widget["y2k_elements"]:
        lg = ET.SubElement(defs, "linearGradient", id="chrome",
                           x1="0%", y1="0%", x2="100%", y2="100%")
        for offset, color in [("0%", "#F8F8FF"), ("25%", "#C0C0D0"),
                               ("50%", "#FFFFFF"), ("75%", "#A0A0B8"),
                               ("100%", "#E8E8F0")]:
            stop = ET.SubElement(lg, "stop", offset=offset)
            stop.set("stop-color", color)

    # Holographic gradient
    if "holographic" in widget["y2k_elements"]:
        lg = ET.SubElement(defs, "linearGradient", id="holographic",
                           x1="0%", y1="0%", x2="100%", y2="100%")
        holo_colors = ["#FF69B4", "#87CEEB", "#DDA0DD", "#98FB98", "#FFD700", "#FF69B4"]
        for i, c in enumerate(holo_colors):
            stop = ET.SubElement(lg, "stop", offset=f"{i * 20}%")
            stop.set("stop-color", c)
            stop.set("stop-opacity", "0.7")

    # Glow filter
    filt = ET.SubElement(defs, "filter", id="glow")
    filt.set("x", "-20%"); filt.set("y", "-20%")
    filt.set("width", "140%"); filt.set("height", "140%")
    blur = ET.SubElement(filt, "feGaussianBlur")
    blur.set("stdDeviation", "3")
    blur.set("result", "blur")
    merge = ET.SubElement(filt, "feMerge")
    ET.SubElement(merge, "feMergeNode").set("in", "blur")
    ET.SubElement(merge, "feMergeNode").set("in", "SourceGraphic")

    # Chrome bevel filter
    filt2 = ET.SubElement(defs, "filter", id="bevel")
    filt2.set("x", "-5%"); filt2.set("y", "-5%")
    filt2.set("width", "110%"); filt2.set("height", "110%")
    spec = ET.SubElement(filt2, "feSpecularLighting")
    spec.set("result", "specOut"); spec.set("specularExponent", "20")
    spec.set("lighting-color", "#FFFFFF")
    light = ET.SubElement(spec, "fePointLight")
    light.set("x", "50"); light.set("y", "30"); light.set("z", "100")
    comp = ET.SubElement(filt2, "feComposite")
    comp.set("in", "specOut"); comp.set("in2", "SourceAlpha")
    comp.set("operator", "in"); comp.set("result", "specOut2")
    comp2 = ET.SubElement(filt2, "feComposite")
    comp2.set("in", "SourceGraphic"); comp2.set("in2", "specOut2")
    comp2.set("operator", "arithmetic")
    comp2.set("k1", "0"); comp2.set("k2", "1"); comp2.set("k3", "1"); comp2.set("k4", "0")

    return defs


def _draw_background(svg, w, h, cs):
    """Dark gradient background for the widget."""
    # Parse the linear-gradient colors
    bg = cs.get("background", "")
    colors = ["#1a0a2a", "#0a0a2a"]
    if "linear-gradient" in bg:
        import re
        found = re.findall(r'#[0-9a-fA-F]{6}', bg)
        if len(found) >= 2:
            colors = found[:2]

    defs = svg.find(f"{{{NS}}}defs") or ET.SubElement(svg, "defs")
    lg = ET.SubElement(defs, "linearGradient", id="bgGrad",
                       x1="0%", y1="0%", x2="100%", y2="100%")
    ET.SubElement(lg, "stop", offset="0%").set("stop-color", colors[0])
    ET.SubElement(lg, "stop", offset="100%").set("stop-color", colors[1])

    # Rounded widget body
    ET.SubElement(svg, "rect", x="0", y="0", width=str(w), height=str(h),
                  rx="18", fill="url(#bgGrad)", stroke="url(#chrome)",
                  **{"stroke-width": "2"})


def _add_glitter(svg, w, h, count=30):
    """Scattered small circles simulating glitter."""
    g = ET.SubElement(svg, "g", opacity="0.6")
    g.set("class", "glitter")
    for _ in range(count):
        cx = random.randint(8, w - 8)
        cy = random.randint(8, h - 8)
        r = random.choice([1, 1.5, 2])
        color = random.choice(["#FFFFFF", "#FFD700", "#FF69B4", "#87CEEB"])
        ET.SubElement(g, "circle", cx=str(cx), cy=str(cy), r=str(r),
                      fill=color, opacity=str(random.uniform(0.3, 0.9)))


def _butterfly(parent, cx, cy, scale=1.0, color="#FF69B4"):
    """Butterfly silhouette using path elements."""
    g = ET.SubElement(parent, "g",
                      transform=f"translate({cx},{cy}) scale({scale})")
    # Left wing
    ET.SubElement(g, "path",
                  d="M0 0 C-12 -14, -22 -10, -18 0 C-22 10, -12 14, 0 0Z",
                  fill=color, opacity="0.7")
    # Right wing
    ET.SubElement(g, "path",
                  d="M0 0 C12 -14, 22 -10, 18 0 C22 10, 12 14, 0 0Z",
                  fill=color, opacity="0.7")
    # Body
    ET.SubElement(g, "ellipse", cx="0", cy="0", rx="1.5", ry="6",
                  fill="#333")


def _star(parent, cx, cy, r=10, color="#FFD700", points=5):
    """Decorative star."""
    pts = []
    for i in range(points * 2):
        a = math.radians(i * 360 / (points * 2) - 90)
        cr = r if i % 2 == 0 else r * 0.4
        pts.append(f"{cx + cr * math.cos(a):.1f},{cy + cr * math.sin(a):.1f}")
    ET.SubElement(parent, "polygon", points=" ".join(pts), fill=color,
                  filter="url(#glow)")


def _heart(parent, cx, cy, size=12, color="#FF69B4"):
    s = size / 12
    g = ET.SubElement(parent, "g",
                      transform=f"translate({cx},{cy}) scale({s})")
    ET.SubElement(g, "path",
                  d="M0 4 C0 -4, -12 -4, -12 2 C-12 10, 0 16, 0 16 C0 16, 12 10, 12 2 C12 -4, 0 -4, 0 4Z",
                  fill=color, opacity="0.8")


def _chrome_text(parent, x, y, text, size=14, anchor="middle"):
    t = ET.SubElement(parent, "text", x=str(x), y=str(y))
    t.set("font-family", "'Segoe UI', system-ui, sans-serif")
    t.set("font-size", str(size))
    t.set("fill", "url(#chrome)")
    t.set("font-weight", "bold")
    t.set("text-anchor", anchor)
    t.set("filter", "url(#bevel)")
    t.text = text


def _text(parent, x, y, text, size=12, fill="#E0E0F0", anchor="middle", weight="normal"):
    t = ET.SubElement(parent, "text", x=str(x), y=str(y))
    t.set("font-family", "'Segoe UI', system-ui, sans-serif")
    t.set("font-size", str(size))
    t.set("fill", fill)
    t.set("font-weight", weight)
    t.set("text-anchor", anchor)
    t.text = text


# ── Y2K decoration layer ────────────────────────────────────────────────

def _add_y2k_decorations(svg, w, h, elements, primary_color):
    """Add Y2K elements based on widget config."""
    if "glitter" in elements:
        _add_glitter(svg, w, h, count=max(15, w * h // 600))

    if "butterfly" in elements:
        _butterfly(svg, w - 28, 28, 0.7, primary_color)
        if h > 200:
            _butterfly(svg, 25, h - 30, 0.5, "#DDA0DD")

    if "star" in elements:
        _star(svg, 22, 22, 8, "#FFD700")
        _star(svg, w - 24, h - 24, 6, primary_color)
        if w > 200:
            _star(svg, w // 2 + 40, 18, 5, "#FFFFFF")

    if "heart" in elements:
        _heart(svg, w - 30, h - 25, 10, primary_color)
        if w > 200:
            _heart(svg, 28, h - 28, 8, "#DDA0DD")

    if "holographic" in elements:
        # Subtle holographic stripe
        g = ET.SubElement(svg, "g", opacity="0.15")
        ET.SubElement(g, "rect", x="0", y=str(h // 2 - 4),
                      width=str(w), height="8", rx="4",
                      fill="url(#holographic)")


# ── Widget content renderers ─────────────────────────────────────────────

def _render_digital_clock(svg, w, h, widget):
    _chrome_text(svg, w // 2, h // 2 - 10, "12:00", size=42)
    _text(svg, w // 2, h // 2 + 20, "TUE MAR 12", size=11, fill=widget["color_scheme"]["primary"])


def _render_analog_clock(svg, w, h, widget):
    cx, cy, r = w // 2, h // 2, min(w, h) // 2 - 24
    ET.SubElement(svg, "circle", cx=str(cx), cy=str(cy), r=str(r),
                  fill="none", stroke="url(#chrome)", **{"stroke-width": "3"})
    ET.SubElement(svg, "circle", cx=str(cx), cy=str(cy), r=str(r - 6),
                  fill="none", stroke=widget["color_scheme"]["primary"],
                  **{"stroke-width": "0.5"}, opacity="0.4")
    # Hour marks
    for i in range(12):
        a = math.radians(i * 30 - 90)
        x1 = cx + (r - 8) * math.cos(a)
        y1 = cy + (r - 8) * math.sin(a)
        x2 = cx + (r - 14) * math.cos(a)
        y2 = cy + (r - 14) * math.sin(a)
        ET.SubElement(svg, "line", x1=f"{x1:.1f}", y1=f"{y1:.1f}",
                      x2=f"{x2:.1f}", y2=f"{y2:.1f}",
                      stroke="url(#chrome)", **{"stroke-width": "2"})
    # Hands
    for angle, length, width in [(60, r * 0.5, 3), (180, r * 0.7, 2), (276, r * 0.75, 1)]:
        a = math.radians(angle - 90)
        ET.SubElement(svg, "line", x1=str(cx), y1=str(cy),
                      x2=f"{cx + length * math.cos(a):.1f}",
                      y2=f"{cy + length * math.sin(a):.1f}",
                      stroke="url(#chrome)", **{"stroke-width": str(width)})
    ET.SubElement(svg, "circle", cx=str(cx), cy=str(cy), r="4",
                  fill=widget["color_scheme"]["primary"])


def _render_countdown_timer(svg, w, h, widget):
    _chrome_text(svg, w // 2, h // 2 - 12, "07 : 14 : 32 : 08", size=28)
    _text(svg, w // 2, h // 2 + 14, "DAYS    HRS    MIN    SEC", size=9, fill="#A0A0B8")
    _text(svg, w // 2, h // 2 + 36, "Until Launch Day", size=12,
          fill=widget["color_scheme"]["primary"])


def _render_weather_widget(svg, w, h, widget):
    # Sun icon
    cx_sun = 60
    cy_sun = h // 2 - 10
    ET.SubElement(svg, "circle", cx=str(cx_sun), cy=str(cy_sun), r="18",
                  fill="#FFD700", filter="url(#glow)")
    for i in range(8):
        a = math.radians(i * 45)
        ET.SubElement(svg, "line",
                      x1=f"{cx_sun + 24 * math.cos(a):.0f}",
                      y1=f"{cy_sun + 24 * math.sin(a):.0f}",
                      x2=f"{cx_sun + 30 * math.cos(a):.0f}",
                      y2=f"{cy_sun + 30 * math.sin(a):.0f}",
                      stroke="#FFD700", **{"stroke-width": "2"})
    _chrome_text(svg, 160, h // 2 - 10, "22°C", size=32)
    _text(svg, 160, h // 2 + 16, "Partly Cloudy", size=11, fill=widget["color_scheme"]["primary"])
    # Forecast
    for i, (d, t) in enumerate([("THU", "19°"), ("FRI", "21°"), ("SAT", "24°")]):
        fx = 240 + i * 38
        _text(svg, fx, h // 2 - 10, d, size=8, fill="#A0A0B8")
        _text(svg, fx, h // 2 + 8, t, size=10, fill="#E0E0F0")


def _render_calendar_widget(svg, w, h, widget):
    _chrome_text(svg, w // 2, 36, "MARCH 2026", size=14)
    days = ["M", "T", "W", "T", "F", "S", "S"]
    start_x = 30
    cell_w = (w - 60) // 7
    for i, d in enumerate(days):
        _text(svg, start_x + i * cell_w + cell_w // 2, 58, d, size=9, fill="#A0A0B8")
    # Day numbers (March 2026 starts on Sunday)
    day_num = 1
    for row in range(5):
        for col in range(7):
            if row == 0 and col < 6:
                continue
            if day_num > 31:
                break
            dx = start_x + col * cell_w + cell_w // 2
            dy = 78 + row * 20
            is_today = day_num == 12
            if is_today:
                ET.SubElement(svg, "circle", cx=str(dx), cy=str(dy - 4),
                              r="10", fill=widget["color_scheme"]["primary"],
                              opacity="0.5")
            _text(svg, dx, dy, str(day_num), size=10,
                  fill="#FFFFFF" if is_today else "#E0E0F0")
            day_num += 1


def _render_battery_widget(svg, w, h, widget):
    cx, cy, r = w // 2, h // 2, 50
    ET.SubElement(svg, "circle", cx=str(cx), cy=str(cy), r=str(r),
                  fill="none", stroke="#2a2a3a", **{"stroke-width": "8"})
    # Arc for 78%
    arc_len = 2 * math.pi * r * 0.78
    full_len = 2 * math.pi * r
    c = ET.SubElement(svg, "circle", cx=str(cx), cy=str(cy), r=str(r),
                      fill="none", stroke=widget["color_scheme"]["primary"],
                      **{"stroke-width": "8", "stroke-linecap": "round"})
    c.set("stroke-dasharray", f"{arc_len:.1f} {full_len:.1f}")
    c.set("transform", f"rotate(-90 {cx} {cy})")
    c.set("filter", "url(#glow)")
    _chrome_text(svg, cx, cy + 6, "78%", size=24)


def _render_music_player(svg, w, h, widget):
    # Album art placeholder
    ET.SubElement(svg, "rect", x="18", y="25", width="60", height="60",
                  rx="8", fill=widget["color_scheme"]["primary"], opacity="0.3")
    ET.SubElement(svg, "circle", cx="48", cy="55", r="15", fill="none",
                  stroke="url(#chrome)", **{"stroke-width": "1.5"})
    ET.SubElement(svg, "circle", cx="48", cy="55", r="4", fill="url(#chrome)")
    # Track info
    _chrome_text(svg, 200, 44, "Starlight Dreams", size=13, anchor="middle")
    _text(svg, 200, 62, "Cosmic Butterfly", size=10, fill=widget["color_scheme"]["primary"])
    # Progress bar
    ET.SubElement(svg, "rect", x="100", y="80", width="230", height="4",
                  rx="2", fill="#2a2a3a")
    ET.SubElement(svg, "rect", x="100", y="80", width="140", height="4",
                  rx="2", fill="url(#chrome)")
    _text(svg, 100, 96, "2:34", size=9, fill="#A0A0B8", anchor="start")
    _text(svg, 330, 96, "4:12", size=9, fill="#A0A0B8", anchor="end")
    # Controls
    for i, sym in enumerate(["\u23EE", "\u25B6", "\u23ED"]):
        _text(svg, 170 + i * 40, h - 28, sym, size=18, fill="url(#chrome)")


def _render_photo_frame(svg, w, h, widget):
    bw = 12
    # Ornate chrome border
    ET.SubElement(svg, "rect", x=str(bw), y=str(bw),
                  width=str(w - 2 * bw), height=str(h - 2 * bw),
                  rx="10", fill="none", stroke="url(#chrome)",
                  **{"stroke-width": "4"})
    ET.SubElement(svg, "rect", x=str(bw + 6), y=str(bw + 6),
                  width=str(w - 2 * bw - 12), height=str(h - 2 * bw - 12),
                  rx="6", fill=widget["color_scheme"]["primary"], opacity="0.15")
    # Placeholder image area
    _text(svg, w // 2, h // 2, "\U0001F5BC", size=48)
    _text(svg, w // 2, h // 2 + 40, "Your Photo Here", size=11, fill="#A0A0B8")


def _render_video_thumbnail(svg, w, h, widget):
    ET.SubElement(svg, "rect", x="16", y="20", width=str(w - 32), height=str(h - 55),
                  rx="8", fill=widget["color_scheme"]["primary"], opacity="0.15")
    # Play button
    cx, cy = w // 2, h // 2 - 8
    ET.SubElement(svg, "circle", cx=str(cx), cy=str(cy), r="22",
                  fill="rgba(0,0,0,0.5)", stroke="url(#chrome)",
                  **{"stroke-width": "2"})
    ET.SubElement(svg, "polygon",
                  points=f"{cx - 6},{cy - 10} {cx - 6},{cy + 10} {cx + 10},{cy}",
                  fill="url(#chrome)")
    _text(svg, w - 30, h - 22, "3:42", size=10, fill="#A0A0B8")


def _render_notification_badge(svg, w, h, widget):
    cx, cy = w // 2, h // 2
    # Bell shape
    ET.SubElement(svg, "path",
                  d=f"M{cx} {cy - 35} L{cx - 22} {cy + 5} Q{cx - 22} {cy + 15} {cx - 10} {cy + 15} L{cx + 10} {cy + 15} Q{cx + 22} {cy + 15} {cx + 22} {cy + 5}Z",
                  fill="url(#chrome)", filter="url(#glow)")
    ET.SubElement(svg, "circle", cx=str(cx), cy=str(cy + 20), r="5",
                  fill="url(#chrome)")
    # Badge count
    ET.SubElement(svg, "circle", cx=str(cx + 22), cy=str(cy - 28), r="14",
                  fill=widget["color_scheme"]["primary"], filter="url(#glow)")
    _text(svg, cx + 22, cy - 24, "7", size=14, fill="#FFFFFF", weight="bold")


def _render_status_widget(svg, w, h, widget):
    # Avatar circle
    ET.SubElement(svg, "circle", cx="55", cy=str(h // 2), r="28",
                  fill="url(#chrome)", opacity="0.3")
    ET.SubElement(svg, "circle", cx="55", cy=str(h // 2), r="26",
                  fill=widget["color_scheme"]["primary"], opacity="0.2")
    _text(svg, 55, h // 2 + 5, "\U0001F31F", size=24)
    # Status online dot
    ET.SubElement(svg, "circle", cx="75", cy=str(h // 2 + 18), r="6",
                  fill="#98FB98", stroke="#0a0a12", **{"stroke-width": "2"})
    # Status text
    _chrome_text(svg, 180, h // 2 - 8, "cosmicButterfly", size=14, anchor="middle")
    _text(svg, 180, h // 2 + 14, "vibing in the digital cosmos", size=10,
          fill=widget["color_scheme"]["primary"])
    _text(svg, 180, h // 2 + 34, "Online", size=9, fill="#98FB98")


def _render_chat_bubble(svg, w, h, widget):
    # Avatar
    ET.SubElement(svg, "circle", cx="35", cy="50", r="18",
                  fill=widget["color_scheme"]["primary"], opacity="0.3")
    _text(svg, 35, 55, "\U0001F98B", size=16)
    # Bubble
    ET.SubElement(svg, "rect", x="65", y="30", width="260", height="50",
                  rx="20", fill=widget["color_scheme"]["primary"], opacity="0.2",
                  stroke="url(#chrome)", **{"stroke-width": "1"})
    _text(svg, 195, 60, "hey!! check out this vibe", size=12,
          fill="#E0E0F0")
    # Typing indicator
    for i in range(3):
        ET.SubElement(svg, "circle", cx=str(90 + i * 14), cy=str(h - 35),
                      r="4", fill="url(#chrome)", opacity=str(0.4 + i * 0.2))
    _text(svg, 145, h - 30, "typing...", size=9, fill="#A0A0B8", anchor="start")


def _render_notes_widget(svg, w, h, widget):
    _chrome_text(svg, w // 2, 42, "Quick Notes", size=15)
    # Lines
    for i in range(10):
        ly = 65 + i * 26
        ET.SubElement(svg, "line", x1="24", y1=str(ly), x2=str(w - 24), y2=str(ly),
                      stroke=widget["color_scheme"]["primary"], opacity="0.2",
                      **{"stroke-width": "1"})
    # Sample text
    _text(svg, 30, 82, "remember to back up files", size=11,
          fill="#C0C0D0", anchor="start")
    _text(svg, 30, 108, "new idea: holographic UI", size=11,
          fill="#C0C0D0", anchor="start")


def _render_search_bar(svg, w, h, widget):
    # Search field
    cy = h // 2
    ET.SubElement(svg, "rect", x="24", y=str(cy - 22), width=str(w - 48), height="44",
                  rx="22", fill="rgba(255,255,255,0.06)",
                  stroke="url(#chrome)", **{"stroke-width": "1.5"})
    # Magnifying glass icon
    ET.SubElement(svg, "circle", cx="52", cy=str(cy), r="10",
                  fill="none", stroke="url(#chrome)", **{"stroke-width": "2"})
    ET.SubElement(svg, "line", x1="60", y1=str(cy + 8), x2="66", y2=str(cy + 14),
                  stroke="url(#chrome)", **{"stroke-width": "2"})
    _text(svg, 80, cy + 5, "Search the cosmos...", size=13,
          fill="#6a6a8a", anchor="start")
    # Suggestion chips
    for i, txt in enumerate(["images", "music", "links"]):
        cx = 80 + i * 90
        ET.SubElement(svg, "rect", x=str(cx), y=str(cy + 28), width="72", height="22",
                      rx="11", fill=widget["color_scheme"]["primary"], opacity="0.15",
                      stroke=widget["color_scheme"]["primary"],
                      **{"stroke-width": "0.5"})
        _text(svg, cx + 36, cy + 43, txt, size=9, fill=widget["color_scheme"]["primary"])


def _render_quick_links(svg, w, h, widget):
    _chrome_text(svg, w // 2, 38, "Quick Links", size=14)
    icons = ["\U0001F310", "\U0001F4F1", "\U0001F3B5", "\U0001F4F8", "\U0001F4AC",
             "\u2699\uFE0F", "\U0001F4C1", "\U0001F512", "\U0001F680"]
    labels = ["Web", "Phone", "Music", "Photo", "Chat", "Settings", "Files", "Lock", "Launch"]
    for i in range(9):
        row, col = divmod(i, 3)
        cx = 60 + col * 120
        cy = 75 + row * 95
        ET.SubElement(svg, "rect", x=str(cx - 35), y=str(cy - 25), width="70", height="60",
                      rx="12", fill=widget["color_scheme"]["primary"], opacity="0.08",
                      stroke="url(#chrome)", **{"stroke-width": "0.5"})
        _text(svg, cx, cy + 4, icons[i], size=22)
        _text(svg, cx, cy + 25, labels[i], size=9, fill="#A0A0B8")


# Renderer dispatch
RENDERERS = {
    "digital_clock": _render_digital_clock,
    "analog_clock": _render_analog_clock,
    "countdown_timer": _render_countdown_timer,
    "weather_widget": _render_weather_widget,
    "calendar_widget": _render_calendar_widget,
    "battery_widget": _render_battery_widget,
    "music_player": _render_music_player,
    "photo_frame": _render_photo_frame,
    "video_thumbnail": _render_video_thumbnail,
    "notification_badge": _render_notification_badge,
    "status_widget": _render_status_widget,
    "chat_bubble": _render_chat_bubble,
    "notes_widget": _render_notes_widget,
    "search_bar": _render_search_bar,
    "quick_links": _render_quick_links,
}


# ── Main ─────────────────────────────────────────────────────────────────

def generate_widget(widget):
    dims = widget["dimensions"]
    w, h = dims["width"], dims["height"]
    svg = _svg_root(w, h)
    _add_defs(svg, widget)
    _draw_background(svg, w, h, widget["color_scheme"])

    renderer = RENDERERS.get(widget["id"])
    if renderer:
        renderer(svg, w, h, widget)

    _add_y2k_decorations(svg, w, h, widget["y2k_elements"],
                         widget["color_scheme"]["primary"])
    return svg


def main():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    for widget in data["widgets"]:
        svg = generate_widget(widget)
        out_path = os.path.join(OUTPUT_DIR, f"{widget['id']}.svg")
        tree = ET.ElementTree(svg)
        ET.indent(tree, space="  ")
        tree.write(out_path, xml_declaration=True, encoding="utf-8")
        size = widget["size"]
        dims = widget["dimensions"]
        print(f"  \u2713 {widget['id']}.svg ({dims['width']}x{dims['height']}, {size})")

    print(f"\nGenerated {len(data['widgets'])} widget mockups in {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
