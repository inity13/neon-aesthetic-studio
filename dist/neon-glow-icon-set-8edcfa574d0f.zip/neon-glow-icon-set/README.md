# Neon Glow Icon Set

**30 SVG icons with neon glow effects**

Glowing outlines, electric colors, and soft blur halos — these icons look like
they're powered by neon light. Perfect for dark-themed phone customization,
cyberpunk aesthetics, or adding that late-night-city-vibes energy to your setup.

## What's Inside

| Category | Icons | Examples |
|----------|-------|----------|
| Social | 6 | Heart, chat bubble, music note, camera, star, lightning bolt |
| Tech | 6 | Phone, laptop, headphones, gamepad, wifi, battery |
| Nature | 6 | Moon, sun, cloud, flower, leaf, flame |
| Symbols | 6 | Arrow, check, cross, plus, diamond, infinity |
| Lifestyle | 6 | Coffee cup, shopping bag, crown, palette, rocket, globe |

## Color Palette

```
+-----------+-----------+-----------+-----------+-----------+-----------+
| Hot Pink  | Cyan      | Violet    | Lime      | Orange    | Ice Blue  |
| #FF1493   | #00FFFF   | #8B00FF   | #39FF14   | #FF6600   | #7DF9FF   |
+-----------+-----------+-----------+-----------+-----------+-----------+
```

## File Structure

```
src/
├── icon_data.json          # Icon metadata (names, categories, glow colors)
└── generate_neon_icons.py  # Generate all 30 SVG icons with glow filters

demo/
└── index.html              # Interactive icon browser on dark background

preview/
└── index.html              # Neon gallery grid of all icons

docs/
└── installation_guide.md   # How to use as app icons on iOS, Android, desktop
```

## How to Use

1. **Preview all**: Open `preview/index.html` to see the full neon collection
2. **Browse & search**: Open `demo/index.html` for an interactive dark-mode browser
3. **Generate SVGs**: Run `python3 src/generate_neon_icons.py` to create individual SVGs
4. **Install on phone**: See `docs/installation_guide.md` for platform-specific guides

## Tips

- These icons look best on dark backgrounds (#0a0a12 or pure black)
- Each icon has an SVG `<filter>` for the glow — you can adjust blur radius
- Use as iOS Shortcuts custom icons or Android widget icons
- Pair with the Y2K Widget Theme for a complete neon setup

## License

MIT License — use these icons freely on your devices and in your projects.
See LICENSE file for full terms.
