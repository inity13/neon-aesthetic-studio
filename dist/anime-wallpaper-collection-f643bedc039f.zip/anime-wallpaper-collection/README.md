# Anime Wallpaper Collection

**15 anime-inspired SVG wallpapers for phone & desktop**

Dreamy pastel skies, glowing cherry blossoms, neon-lit cityscapes, and serene
moonlit scenes — all rendered as crisp, scalable SVG art. These are original
anime-inspired *scenes*, not character art — perfect for wallpapers that set the
mood without copyright worries.

## What's Inside

| # | Wallpaper | Description | Mood |
|---|-----------|-------------|------|
| 1 | Cherry Blossom Path | Petals drifting over a stone path at sunset | Romantic, wistful |
| 2 | Neon Alley | Rain-soaked alley with glowing shop signs | Cyberpunk, moody |
| 3 | Cloud Ocean | Endless clouds lit by golden hour sun | Vast, dreamy |
| 4 | Shrine Steps | Torii gate at the top of mossy stone steps | Spiritual, quiet |
| 5 | Rooftop Sunset | City skyline from a school rooftop at dusk | Nostalgic, warm |
| 6 | Starfall Lake | Shooting stars reflected in still water | Magical, peaceful |
| 7 | Bamboo Forest | Shafts of light through tall bamboo | Zen, mysterious |
| 8 | Train Window | Countryside blurring past a rainy train window | Contemplative |
| 9 | Lantern Festival | Paper lanterns floating into night sky | Festive, hopeful |
| 10 | Moon Bridge | Arched bridge under an enormous full moon | Ethereal, bold |
| 11 | Flower Field | Endless wildflowers under pastel sky | Joyful, free |
| 12 | Rainy Crosswalk | Neon reflections on a wet city crossing | Urban, electric |
| 13 | Island Cove | Turquoise water lapping at a rocky shore | Tropical, calm |
| 14 | Snow Village | Warm windows glowing through falling snow | Cozy, quiet |
| 15 | Galaxy Hilltop | Milky Way arching over a grassy hill | Infinite, awe |

## Color Palette

```
┌──────────┬──────────┬──────────┬──────────┬──────────┬──────────┐
│ Sakura   │ Sky Blue │ Sunset   │ Twilight │ Matcha   │ Cloud    │
│ #FFB7C5  │ #87CEEB  │ #FF7E5F  │ #6B5B95  │ #88C9A1  │ #E8E0F0 │
└──────────┴──────────┴──────────┴──────────┴──────────┴──────────┘
```

## File Structure

```
src/
├── phone/              # 1080x1920 (9:16 aspect ratio)
│   ├── 01-cherry-blossom-path.svg
│   ├── 02-neon-alley.svg
│   ├── ... (15 files)
│   └── 15-galaxy-hilltop.svg
└── desktop/            # 1920x1080 (16:9 aspect ratio)
    ├── 01-cherry-blossom-path.svg
    ├── 02-neon-alley.svg
    ├── ... (15 files)
    └── 15-galaxy-hilltop.svg

preview/
└── gallery.html        # Visual gallery of all wallpapers

demo/
└── phone-mockup.html   # See wallpapers on a phone frame
```

## How to Use

1. **Phone wallpaper**: Open any SVG from `src/phone/` and screenshot or save as PNG
2. **Desktop wallpaper**: Open any SVG from `src/desktop/` and screenshot at your monitor's resolution
3. **Custom resolution**: SVGs scale to ANY size — edit the `viewBox` or resize in any image editor
4. **Preview all**: Open `preview/gallery.html` in your browser to see every wallpaper at a glance

## Tips

- SVG files can be opened in any modern browser (Chrome, Safari, Firefox, Edge)
- To convert to PNG: open the SVG in your browser, right-click → "Save image as..."
- For the crispest results, set your phone/desktop resolution as the export size
- Colors can be customized by editing the SVG in any text editor — hex values are clearly labeled

## Regenerate

Run `python3 generate.py` to regenerate all SVG wallpapers from source. Requires Python 3.10+
and no external packages.

## License

MIT License — use these wallpapers on your own devices, share with friends, or use as
inspiration for your own art. See LICENSE file for full terms.
