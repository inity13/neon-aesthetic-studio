# Included Products

## Aesthetic Ultimate Bundle — All 10 Products

### Wallpapers
1. **Cottagecore Wallpaper Pack** ($3) — 20 handcrafted SVG wallpapers in warm earth tones
2. **Anime Wallpaper Collection** ($3) — 15 anime-inspired SVG scenes (cherry blossoms, neon alleys, galaxy hilltops)

### Icons
3. **Dark Academia Icon Set** ($3) — 30 scholarly icons (books, quills, columns, candelabras)
4. **Neon Glow Icon Set** ($3) — 30 neon-glow icons (hearts, music, moons, rockets)

### Stickers & Textures
5. **Digital Sticker Mega Pack** ($5) — 50+ kawaii stickers (animals, celestial, food, quotes)
6. **Grunge Aesthetic Pack** ($3) — 20 gritty textures and overlays

### Tools & Templates
7. **Aesthetic Color Palettes** ($1) — 10 curated palettes for every aesthetic
8. **Mood Board Creator Kit** ($5) — 3 interactive drag-and-drop mood board templates
9. **Pastel Dream Journal** ($3) — 12 printable/digital journal page templates
10. **Y2K Widget Theme** ($3) — 15 retro-futuristic widget designs

---

**Total individual value: $32**
**Bundle price: $19** (save $13 — 41% off)
