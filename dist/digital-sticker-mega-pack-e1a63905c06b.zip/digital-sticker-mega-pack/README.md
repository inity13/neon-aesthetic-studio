# Digital Sticker Mega Pack

**50+ kawaii-style digital stickers for journals, planners & social media**

Cute bears, sparkly stars, rainbow clouds, motivational quotes, and aesthetic
frames — all in SVG format so they stay crisp at any size. Drag and drop in your
favorite note app, planner, or design tool.

## What's Inside

| Category | Count | Examples |
|----------|-------|----------|
| Kawaii Animals | 10 | Bear, bunny, cat, puppy, penguin, frog, duck, hamster, fox, panda |
| Celestial | 8 | Moon, star, cloud, rainbow, sun, planet, shooting star, constellation |
| Food & Drinks | 8 | Boba tea, cupcake, strawberry, ice cream, cookie, donut, lollipop, matcha |
| Quotes & Labels | 10 | "You got this!", "Main character energy", "Vibe check", etc. |
| Frames & Borders | 8 | Heart frame, cloud frame, star frame, ribbon banner, etc. |
| Decorative | 8 | Sparkles, hearts, flowers, butterflies, music notes, gems, bow, washi tape |

## Color Palette

```
+-----------+-----------+-----------+-----------+-----------+-----------+
| Blush     | Lavender  | Mint      | Butter    | Peach     | Sky       |
| #FFB5C5   | #C5A3D9   | #A8E6CF   | #FFE5A0   | #FFCBA4   | #B5D8F7   |
+-----------+-----------+-----------+-----------+-----------+-----------+
```

## File Structure

```
src/
├── sticker_data.json       # Sticker metadata (names, categories, colors)
└── generate_stickers.py    # Generate all 52 SVG stickers

demo/
└── index.html              # Drag-and-drop sticker canvas

preview/
└── index.html              # Grid gallery of all stickers by category
```

## How to Use

1. **Preview all**: Open `preview/index.html` in your browser to see every sticker
2. **Try the canvas**: Open `demo/index.html` for a drag-and-drop playground
3. **Generate SVGs**: Run `python3 src/generate_stickers.py` to create individual SVG files
4. **Use in apps**: Import SVGs into GoodNotes, Notability, Canva, or any design tool

## Tips

- SVGs scale infinitely — zoom to any size without blur
- Works great in digital planners (GoodNotes, Notability, Samsung Notes)
- Right-click any sticker in the preview to save as individual SVG
- Customize colors by editing hex values in the SVG files

## License

MIT License — use these stickers in your journals, planners, and projects.
See LICENSE file for full terms.
