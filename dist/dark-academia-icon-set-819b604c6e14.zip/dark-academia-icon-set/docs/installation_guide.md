# Installation Guide — Dark Academia Icon Set

## iOS (iPhone / iPad)

### Using Shortcuts App
1. Open the **Shortcuts** app
2. Create a new shortcut → tap "Add Action" → search "Open App"
3. Choose the app you want to customize
4. Tap the shortcut name at top → "Add to Home Screen"
5. Tap the icon → "Choose File" → select the SVG icon from this pack
6. Name it and tap "Add"

### Tips
- Convert SVGs to PNG first for best results (open in browser → screenshot or right-click save)
- Use a 180x180 or larger PNG for crisp icons
- Recommended: use the **Themify** or **Icon Themer** apps for batch icon changing

## Android

### Using KWGT / Nova Launcher
1. Install **Nova Launcher** (or any launcher that supports custom icons)
2. Long-press an app icon → tap "Edit"
3. Tap the icon image → "Gallery apps" or "Files"
4. Select the SVG icon from this pack
5. Resize if needed and confirm

### Using Icon Pack Studio
1. Open **Icon Pack Studio**
2. Import SVG icons from this pack
3. Apply as system-wide icon pack

## Desktop (macOS / Windows / Linux)

### macOS
1. Open the SVG in Preview or a browser
2. Export/screenshot as PNG (512x512 recommended)
3. Right-click any app in Finder → "Get Info"
4. Drag the PNG onto the icon in the top-left of the Info window

### Windows
1. Convert SVG to ICO using an online converter or image editor
2. Right-click desktop shortcut → Properties → Change Icon
3. Browse to the .ico file

### Linux
1. Most Linux desktops support SVG icons directly
2. Right-click app launcher → Properties → Click icon → Browse to SVG
3. Or place SVGs in `~/.local/share/icons/` for system-wide use

## Tips for All Platforms

- **SVG to PNG**: Open any SVG in Chrome/Firefox, right-click → "Save image as..." for auto-conversion
- **Batch convert**: Use ImageMagick: `convert icon.svg -resize 512x512 icon.png`
- **Color customization**: Open SVG in a text editor, find hex codes (#3C2415, #C5A55A, etc.) and replace
- **Best on dark backgrounds**: These icons use the dark academia palette and look best on dark wallpapers
